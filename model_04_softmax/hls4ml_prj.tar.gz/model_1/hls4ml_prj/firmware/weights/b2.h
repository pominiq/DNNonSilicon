//Numpy array shape [4]
//Min -1.043945312500
//Max 1.993164062500
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
conv2d_bias_t b2[4];
#else
conv2d_bias_t b2[4] = {1.9931640625, -1.0439453125, -0.8715820312, 0.2912597656};
#endif

#endif
