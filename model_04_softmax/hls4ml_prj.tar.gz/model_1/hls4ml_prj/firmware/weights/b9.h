//Numpy array shape [10]
//Min -0.158081054688
//Max 0.384033203125
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
dense_bias_t b9[10];
#else
dense_bias_t b9[10] = {-0.0232543945, -0.0027103424, -0.0077133179, -0.0405273438, -0.1065063477, 0.0868530273, -0.1170043945, -0.0900268555, 0.3840332031, -0.1580810547};
#endif

#endif
