# ==============================================================
# Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
# Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
# ==============================================================

/home/pominiq/Vivado/2020.1/bin/vivado  -notrace -mode batch -source ipi_example.tcl -tclargs xcu280-fsvh2892-2L-e ../xilinx_com_hls_myproject_1_0.zip
