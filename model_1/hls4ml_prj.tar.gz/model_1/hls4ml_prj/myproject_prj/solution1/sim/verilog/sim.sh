#!/bin/sh
# ==============================================================
# Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
# Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
# ==============================================================
# The next line restarts using autoesl tclsh \
    exec /home/pominiq/Vivado/2020.1/bin/vivado_hls run_sim.tcl
