// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern void AESL_WRAP_myproject (
hls::stream<struct nnet::array<ap_fixed<16, 6, (ap_q_mode) 5, (ap_o_mode)3, 0>, 1 > > (&input_layer),
hls::stream<struct nnet::array<ap_fixed<16, 6, (ap_q_mode) 5, (ap_o_mode)3, 0>, 12 > > (&layer7_out));
