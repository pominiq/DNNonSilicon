//Numpy array shape [8]
//Min -0.584472656250
//Max 0.522460937500
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {-0.1922607422, 0.5224609375, 0.4372558594, -0.0431823730, -0.2592773438, 0.2307128906, 0.1539306641, -0.5844726562};
#endif

#endif
