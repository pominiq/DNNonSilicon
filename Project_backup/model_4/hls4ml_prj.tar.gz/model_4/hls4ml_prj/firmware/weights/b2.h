//Numpy array shape [4]
//Min -0.110534667969
//Max -0.001996994019
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {-0.1105346680, -0.0078887939, -0.0208435059, -0.0019969940};
#endif

#endif
