//Numpy array shape [10]
//Min -0.283447265625
//Max 0.660156250000
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
model_default_t b9[10];
#else
model_default_t b9[10] = {0.1665039062, 0.6601562500, -0.2834472656, 0.0490112305, -0.1387939453, 0.0166473389, 0.1333007812, 0.0540466309, -0.1524658203, -0.0122833252};
#endif

#endif
