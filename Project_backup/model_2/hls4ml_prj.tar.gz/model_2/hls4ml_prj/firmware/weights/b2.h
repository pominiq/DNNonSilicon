//Numpy array shape [4]
//Min -0.606933593750
//Max 0.058624267578
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
conv2d_bias_t b2[4];
#else
conv2d_bias_t b2[4] = {-0.2120361328, -0.0652465820, -0.6069335938, 0.0586242676};
#endif

#endif
