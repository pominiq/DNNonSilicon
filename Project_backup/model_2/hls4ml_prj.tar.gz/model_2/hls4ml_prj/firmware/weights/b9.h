//Numpy array shape [10]
//Min -0.383300781250
//Max 0.308837890625
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
dense_bias_t b9[10];
#else
dense_bias_t b9[10] = {-0.1066284180, 0.2561035156, 0.0946655273, 0.1466064453, -0.1348876953, 0.3088378906, -0.0613403320, 0.1437988281, -0.3833007812, -0.1447753906};
#endif

#endif
