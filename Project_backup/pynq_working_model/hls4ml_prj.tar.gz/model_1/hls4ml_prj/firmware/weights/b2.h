//Numpy array shape [4]
//Min -0.306615769863
//Max 0.276778727770
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
conv2d_bias_t b2[4];
#else
conv2d_bias_t b2[4] = {-0.03939596, 0.12166639, 0.27677873, -0.30661577};
#endif

#endif
