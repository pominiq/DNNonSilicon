#include "dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_413_fu_25413_p3() {
    select_ln56_413_fu_25413_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_405_fu_25349_p3.read(): select_ln56_406_fu_25357_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_414_fu_25421_p3() {
    select_ln56_414_fu_25421_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_407_fu_25365_p3.read(): select_ln56_408_fu_25373_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_415_fu_25429_p3() {
    select_ln56_415_fu_25429_p3 = (!or_ln56_4_fu_21837_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_21837_p2.read()[0].to_bool())? select_ln56_409_fu_25381_p3.read(): select_ln56_410_fu_25389_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_416_fu_25437_p3() {
    select_ln56_416_fu_25437_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_411_fu_25397_p3.read(): select_ln56_412_fu_25405_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_417_fu_25445_p3() {
    select_ln56_417_fu_25445_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_413_fu_25413_p3.read(): select_ln56_414_fu_25421_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_418_fu_25453_p3() {
    select_ln56_418_fu_25453_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_415_fu_25429_p3.read(): select_ln56_416_fu_25437_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_419_fu_25461_p3() {
    select_ln56_419_fu_25461_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_417_fu_25445_p3.read(): select_ln56_418_fu_25453_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_41_fu_22187_p3() {
    select_ln56_41_fu_22187_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_36_fu_22147_p3.read(): select_ln56_37_fu_22155_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_420_fu_25479_p3() {
    select_ln56_420_fu_25479_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_478_V_read508_phi_phi_fu_20284_p4.read(): ap_phi_mux_data_477_V_read507_phi_phi_fu_20272_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_421_fu_25487_p3() {
    select_ln56_421_fu_25487_p3 = (!icmp_ln56_12_fu_21755_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_21755_p2.read()[0].to_bool())? ap_phi_mux_data_476_V_read506_phi_phi_fu_20260_p4.read(): ap_phi_mux_data_475_V_read505_phi_phi_fu_20248_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_422_fu_25495_p3() {
    select_ln56_422_fu_25495_p3 = (!icmp_ln56_10_fu_21743_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_21743_p2.read()[0].to_bool())? ap_phi_mux_data_474_V_read504_phi_phi_fu_20236_p4.read(): ap_phi_mux_data_473_V_read503_phi_phi_fu_20224_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_423_fu_25503_p3() {
    select_ln56_423_fu_25503_p3 = (!icmp_ln56_8_fu_21731_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_21731_p2.read()[0].to_bool())? ap_phi_mux_data_472_V_read502_phi_phi_fu_20212_p4.read(): ap_phi_mux_data_471_V_read501_phi_phi_fu_20200_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_424_fu_25511_p3() {
    select_ln56_424_fu_25511_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_470_V_read500_phi_phi_fu_20188_p4.read(): ap_phi_mux_data_469_V_read499_phi_phi_fu_20176_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_425_fu_25519_p3() {
    select_ln56_425_fu_25519_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_468_V_read498_phi_phi_fu_20164_p4.read(): ap_phi_mux_data_467_V_read497_phi_phi_fu_20152_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_426_fu_25527_p3() {
    select_ln56_426_fu_25527_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_466_V_read496_phi_phi_fu_20140_p4.read(): ap_phi_mux_data_465_V_read495_phi_phi_fu_20128_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_427_fu_25535_p3() {
    select_ln56_427_fu_25535_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_464_V_read494_phi_phi_fu_20116_p4.read(): ap_phi_mux_data_479_V_read509_phi_phi_fu_20296_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_428_fu_25543_p3() {
    select_ln56_428_fu_25543_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_420_fu_25479_p3.read(): select_ln56_421_fu_25487_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_429_fu_25551_p3() {
    select_ln56_429_fu_25551_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_422_fu_25495_p3.read(): select_ln56_423_fu_25503_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_42_fu_22195_p3() {
    select_ln56_42_fu_22195_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_38_fu_22163_p3.read(): select_ln56_39_fu_22171_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_430_fu_25559_p3() {
    select_ln56_430_fu_25559_p3 = (!or_ln56_4_fu_21837_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_21837_p2.read()[0].to_bool())? select_ln56_424_fu_25511_p3.read(): select_ln56_425_fu_25519_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_431_fu_25567_p3() {
    select_ln56_431_fu_25567_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_426_fu_25527_p3.read(): select_ln56_427_fu_25535_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_432_fu_25575_p3() {
    select_ln56_432_fu_25575_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_428_fu_25543_p3.read(): select_ln56_429_fu_25551_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_433_fu_25583_p3() {
    select_ln56_433_fu_25583_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_430_fu_25559_p3.read(): select_ln56_431_fu_25567_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_434_fu_25591_p3() {
    select_ln56_434_fu_25591_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_432_fu_25575_p3.read(): select_ln56_433_fu_25583_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_435_fu_25609_p3() {
    select_ln56_435_fu_25609_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_494_V_read524_phi_phi_fu_20476_p4.read(): ap_phi_mux_data_493_V_read523_phi_phi_fu_20464_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_436_fu_25617_p3() {
    select_ln56_436_fu_25617_p3 = (!icmp_ln56_12_fu_21755_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_21755_p2.read()[0].to_bool())? ap_phi_mux_data_492_V_read522_phi_phi_fu_20452_p4.read(): ap_phi_mux_data_491_V_read521_phi_phi_fu_20440_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_437_fu_25625_p3() {
    select_ln56_437_fu_25625_p3 = (!icmp_ln56_10_fu_21743_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_21743_p2.read()[0].to_bool())? ap_phi_mux_data_490_V_read520_phi_phi_fu_20428_p4.read(): ap_phi_mux_data_489_V_read519_phi_phi_fu_20416_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_438_fu_25633_p3() {
    select_ln56_438_fu_25633_p3 = (!icmp_ln56_8_fu_21731_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_21731_p2.read()[0].to_bool())? ap_phi_mux_data_488_V_read518_phi_phi_fu_20404_p4.read(): ap_phi_mux_data_487_V_read517_phi_phi_fu_20392_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_439_fu_25641_p3() {
    select_ln56_439_fu_25641_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_486_V_read516_phi_phi_fu_20380_p4.read(): ap_phi_mux_data_485_V_read515_phi_phi_fu_20368_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_43_fu_22203_p3() {
    select_ln56_43_fu_22203_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_40_fu_22179_p3.read(): select_ln56_41_fu_22187_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_440_fu_25649_p3() {
    select_ln56_440_fu_25649_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_484_V_read514_phi_phi_fu_20356_p4.read(): ap_phi_mux_data_483_V_read513_phi_phi_fu_20344_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_441_fu_25657_p3() {
    select_ln56_441_fu_25657_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_482_V_read512_phi_phi_fu_20332_p4.read(): ap_phi_mux_data_481_V_read511_phi_phi_fu_20320_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_442_fu_25665_p3() {
    select_ln56_442_fu_25665_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_480_V_read510_phi_phi_fu_20308_p4.read(): ap_phi_mux_data_495_V_read525_phi_phi_fu_20488_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_443_fu_25673_p3() {
    select_ln56_443_fu_25673_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_435_fu_25609_p3.read(): select_ln56_436_fu_25617_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_444_fu_25681_p3() {
    select_ln56_444_fu_25681_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_437_fu_25625_p3.read(): select_ln56_438_fu_25633_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_445_fu_25689_p3() {
    select_ln56_445_fu_25689_p3 = (!or_ln56_4_fu_21837_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_21837_p2.read()[0].to_bool())? select_ln56_439_fu_25641_p3.read(): select_ln56_440_fu_25649_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_446_fu_25697_p3() {
    select_ln56_446_fu_25697_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_441_fu_25657_p3.read(): select_ln56_442_fu_25665_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_447_fu_25705_p3() {
    select_ln56_447_fu_25705_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_443_fu_25673_p3.read(): select_ln56_444_fu_25681_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_448_fu_25713_p3() {
    select_ln56_448_fu_25713_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_445_fu_25689_p3.read(): select_ln56_446_fu_25697_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_449_fu_25721_p3() {
    select_ln56_449_fu_25721_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_447_fu_25705_p3.read(): select_ln56_448_fu_25713_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_44_fu_22211_p3() {
    select_ln56_44_fu_22211_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_42_fu_22195_p3.read(): select_ln56_43_fu_22203_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_450_fu_25739_p3() {
    select_ln56_450_fu_25739_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_510_V_read540_phi_phi_fu_20668_p4.read(): ap_phi_mux_data_509_V_read539_phi_phi_fu_20656_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_451_fu_25747_p3() {
    select_ln56_451_fu_25747_p3 = (!icmp_ln56_12_fu_21755_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_21755_p2.read()[0].to_bool())? ap_phi_mux_data_508_V_read538_phi_phi_fu_20644_p4.read(): ap_phi_mux_data_507_V_read537_phi_phi_fu_20632_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_452_fu_25755_p3() {
    select_ln56_452_fu_25755_p3 = (!icmp_ln56_10_fu_21743_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_21743_p2.read()[0].to_bool())? ap_phi_mux_data_506_V_read536_phi_phi_fu_20620_p4.read(): ap_phi_mux_data_505_V_read535_phi_phi_fu_20608_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_453_fu_25763_p3() {
    select_ln56_453_fu_25763_p3 = (!icmp_ln56_8_fu_21731_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_21731_p2.read()[0].to_bool())? ap_phi_mux_data_504_V_read534_phi_phi_fu_20596_p4.read(): ap_phi_mux_data_503_V_read533_phi_phi_fu_20584_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_454_fu_25771_p3() {
    select_ln56_454_fu_25771_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_502_V_read532_phi_phi_fu_20572_p4.read(): ap_phi_mux_data_501_V_read531_phi_phi_fu_20560_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_455_fu_25779_p3() {
    select_ln56_455_fu_25779_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_500_V_read530_phi_phi_fu_20548_p4.read(): ap_phi_mux_data_499_V_read529_phi_phi_fu_20536_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_456_fu_25787_p3() {
    select_ln56_456_fu_25787_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_498_V_read528_phi_phi_fu_20524_p4.read(): ap_phi_mux_data_497_V_read527_phi_phi_fu_20512_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_457_fu_25795_p3() {
    select_ln56_457_fu_25795_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_496_V_read526_phi_phi_fu_20500_p4.read(): ap_phi_mux_data_511_V_read541_phi_phi_fu_20680_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_458_fu_25803_p3() {
    select_ln56_458_fu_25803_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_450_fu_25739_p3.read(): select_ln56_451_fu_25747_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_459_fu_25811_p3() {
    select_ln56_459_fu_25811_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_452_fu_25755_p3.read(): select_ln56_453_fu_25763_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_45_fu_22229_p3() {
    select_ln56_45_fu_22229_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_78_V_read108_phi_phi_fu_15484_p4.read(): ap_phi_mux_data_77_V_read107_phi_phi_fu_15472_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_460_fu_25819_p3() {
    select_ln56_460_fu_25819_p3 = (!or_ln56_4_fu_21837_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_21837_p2.read()[0].to_bool())? select_ln56_454_fu_25771_p3.read(): select_ln56_455_fu_25779_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_461_fu_25827_p3() {
    select_ln56_461_fu_25827_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_456_fu_25787_p3.read(): select_ln56_457_fu_25795_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_462_fu_25835_p3() {
    select_ln56_462_fu_25835_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_458_fu_25803_p3.read(): select_ln56_459_fu_25811_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_463_fu_25843_p3() {
    select_ln56_463_fu_25843_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_460_fu_25819_p3.read(): select_ln56_461_fu_25827_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_464_fu_25851_p3() {
    select_ln56_464_fu_25851_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_462_fu_25835_p3.read(): select_ln56_463_fu_25843_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_465_fu_25869_p3() {
    select_ln56_465_fu_25869_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_526_V_read556_phi_phi_fu_20860_p4.read(): ap_phi_mux_data_525_V_read555_phi_phi_fu_20848_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_466_fu_25877_p3() {
    select_ln56_466_fu_25877_p3 = (!icmp_ln56_12_fu_21755_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_21755_p2.read()[0].to_bool())? ap_phi_mux_data_524_V_read554_phi_phi_fu_20836_p4.read(): ap_phi_mux_data_523_V_read553_phi_phi_fu_20824_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_467_fu_25885_p3() {
    select_ln56_467_fu_25885_p3 = (!icmp_ln56_10_fu_21743_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_21743_p2.read()[0].to_bool())? ap_phi_mux_data_522_V_read552_phi_phi_fu_20812_p4.read(): ap_phi_mux_data_521_V_read551_phi_phi_fu_20800_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_468_fu_25893_p3() {
    select_ln56_468_fu_25893_p3 = (!icmp_ln56_8_fu_21731_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_21731_p2.read()[0].to_bool())? ap_phi_mux_data_520_V_read550_phi_phi_fu_20788_p4.read(): ap_phi_mux_data_519_V_read549_phi_phi_fu_20776_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_469_fu_25901_p3() {
    select_ln56_469_fu_25901_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_518_V_read548_phi_phi_fu_20764_p4.read(): ap_phi_mux_data_517_V_read547_phi_phi_fu_20752_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_46_fu_22237_p3() {
    select_ln56_46_fu_22237_p3 = (!icmp_ln56_12_fu_21755_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_21755_p2.read()[0].to_bool())? ap_phi_mux_data_76_V_read106_phi_phi_fu_15460_p4.read(): ap_phi_mux_data_75_V_read105_phi_phi_fu_15448_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_470_fu_25909_p3() {
    select_ln56_470_fu_25909_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_516_V_read546_phi_phi_fu_20740_p4.read(): ap_phi_mux_data_515_V_read545_phi_phi_fu_20728_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_471_fu_25917_p3() {
    select_ln56_471_fu_25917_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_514_V_read544_phi_phi_fu_20716_p4.read(): ap_phi_mux_data_513_V_read543_phi_phi_fu_20704_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_472_fu_25925_p3() {
    select_ln56_472_fu_25925_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_512_V_read542_phi_phi_fu_20692_p4.read(): ap_phi_mux_data_527_V_read557_phi_phi_fu_20872_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_473_fu_25933_p3() {
    select_ln56_473_fu_25933_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_465_fu_25869_p3.read(): select_ln56_466_fu_25877_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_474_fu_25941_p3() {
    select_ln56_474_fu_25941_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_467_fu_25885_p3.read(): select_ln56_468_fu_25893_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_475_fu_25949_p3() {
    select_ln56_475_fu_25949_p3 = (!or_ln56_4_fu_21837_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_21837_p2.read()[0].to_bool())? select_ln56_469_fu_25901_p3.read(): select_ln56_470_fu_25909_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_476_fu_25957_p3() {
    select_ln56_476_fu_25957_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_471_fu_25917_p3.read(): select_ln56_472_fu_25925_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_477_fu_25965_p3() {
    select_ln56_477_fu_25965_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_473_fu_25933_p3.read(): select_ln56_474_fu_25941_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_478_fu_25973_p3() {
    select_ln56_478_fu_25973_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_475_fu_25949_p3.read(): select_ln56_476_fu_25957_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_479_fu_25981_p3() {
    select_ln56_479_fu_25981_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_477_fu_25965_p3.read(): select_ln56_478_fu_25973_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_47_fu_22245_p3() {
    select_ln56_47_fu_22245_p3 = (!icmp_ln56_10_fu_21743_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_21743_p2.read()[0].to_bool())? ap_phi_mux_data_74_V_read104_phi_phi_fu_15436_p4.read(): ap_phi_mux_data_73_V_read103_phi_phi_fu_15424_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_480_fu_25999_p3() {
    select_ln56_480_fu_25999_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_542_V_read572_phi_phi_fu_21052_p4.read(): ap_phi_mux_data_541_V_read571_phi_phi_fu_21040_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_481_fu_26007_p3() {
    select_ln56_481_fu_26007_p3 = (!icmp_ln56_12_fu_21755_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_21755_p2.read()[0].to_bool())? ap_phi_mux_data_540_V_read570_phi_phi_fu_21028_p4.read(): ap_phi_mux_data_539_V_read569_phi_phi_fu_21016_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_482_fu_26015_p3() {
    select_ln56_482_fu_26015_p3 = (!icmp_ln56_10_fu_21743_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_21743_p2.read()[0].to_bool())? ap_phi_mux_data_538_V_read568_phi_phi_fu_21004_p4.read(): ap_phi_mux_data_537_V_read567_phi_phi_fu_20992_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_483_fu_26023_p3() {
    select_ln56_483_fu_26023_p3 = (!icmp_ln56_8_fu_21731_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_21731_p2.read()[0].to_bool())? ap_phi_mux_data_536_V_read566_phi_phi_fu_20980_p4.read(): ap_phi_mux_data_535_V_read565_phi_phi_fu_20968_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_484_fu_26031_p3() {
    select_ln56_484_fu_26031_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_534_V_read564_phi_phi_fu_20956_p4.read(): ap_phi_mux_data_533_V_read563_phi_phi_fu_20944_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_485_fu_26039_p3() {
    select_ln56_485_fu_26039_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_532_V_read562_phi_phi_fu_20932_p4.read(): ap_phi_mux_data_531_V_read561_phi_phi_fu_20920_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_486_fu_26047_p3() {
    select_ln56_486_fu_26047_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_530_V_read560_phi_phi_fu_20908_p4.read(): ap_phi_mux_data_529_V_read559_phi_phi_fu_20896_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_487_fu_26055_p3() {
    select_ln56_487_fu_26055_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_528_V_read558_phi_phi_fu_20884_p4.read(): ap_phi_mux_data_543_V_read573_phi_phi_fu_21064_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_488_fu_26063_p3() {
    select_ln56_488_fu_26063_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_480_fu_25999_p3.read(): select_ln56_481_fu_26007_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_489_fu_26071_p3() {
    select_ln56_489_fu_26071_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_482_fu_26015_p3.read(): select_ln56_483_fu_26023_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_48_fu_22253_p3() {
    select_ln56_48_fu_22253_p3 = (!icmp_ln56_8_fu_21731_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_21731_p2.read()[0].to_bool())? ap_phi_mux_data_72_V_read102_phi_phi_fu_15412_p4.read(): ap_phi_mux_data_71_V_read101_phi_phi_fu_15400_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_490_fu_26079_p3() {
    select_ln56_490_fu_26079_p3 = (!or_ln56_4_fu_21837_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_21837_p2.read()[0].to_bool())? select_ln56_484_fu_26031_p3.read(): select_ln56_485_fu_26039_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_491_fu_26087_p3() {
    select_ln56_491_fu_26087_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_486_fu_26047_p3.read(): select_ln56_487_fu_26055_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_492_fu_26095_p3() {
    select_ln56_492_fu_26095_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_488_fu_26063_p3.read(): select_ln56_489_fu_26071_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_493_fu_26103_p3() {
    select_ln56_493_fu_26103_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_490_fu_26079_p3.read(): select_ln56_491_fu_26087_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_494_fu_26111_p3() {
    select_ln56_494_fu_26111_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_492_fu_26095_p3.read(): select_ln56_493_fu_26103_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_495_fu_26129_p3() {
    select_ln56_495_fu_26129_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_558_V_read588_phi_phi_fu_21244_p4.read(): ap_phi_mux_data_557_V_read587_phi_phi_fu_21232_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_496_fu_26137_p3() {
    select_ln56_496_fu_26137_p3 = (!icmp_ln56_12_fu_21755_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_21755_p2.read()[0].to_bool())? ap_phi_mux_data_556_V_read586_phi_phi_fu_21220_p4.read(): ap_phi_mux_data_555_V_read585_phi_phi_fu_21208_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_497_fu_26145_p3() {
    select_ln56_497_fu_26145_p3 = (!icmp_ln56_10_fu_21743_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_21743_p2.read()[0].to_bool())? ap_phi_mux_data_554_V_read584_phi_phi_fu_21196_p4.read(): ap_phi_mux_data_553_V_read583_phi_phi_fu_21184_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_498_fu_26153_p3() {
    select_ln56_498_fu_26153_p3 = (!icmp_ln56_8_fu_21731_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_21731_p2.read()[0].to_bool())? ap_phi_mux_data_552_V_read582_phi_phi_fu_21172_p4.read(): ap_phi_mux_data_551_V_read581_phi_phi_fu_21160_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_499_fu_26161_p3() {
    select_ln56_499_fu_26161_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_550_V_read580_phi_phi_fu_21148_p4.read(): ap_phi_mux_data_549_V_read579_phi_phi_fu_21136_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_49_fu_22261_p3() {
    select_ln56_49_fu_22261_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_70_V_read100_phi_phi_fu_15388_p4.read(): ap_phi_mux_data_69_V_read99_phi_phi_fu_15376_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_4_fu_21829_p3() {
    select_ln56_4_fu_21829_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_22_V_read52_phi_phi_fu_14812_p4.read(): ap_phi_mux_data_21_V_read51_phi_phi_fu_14800_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_500_fu_26169_p3() {
    select_ln56_500_fu_26169_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_548_V_read578_phi_phi_fu_21124_p4.read(): ap_phi_mux_data_547_V_read577_phi_phi_fu_21112_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_501_fu_26177_p3() {
    select_ln56_501_fu_26177_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_546_V_read576_phi_phi_fu_21100_p4.read(): ap_phi_mux_data_545_V_read575_phi_phi_fu_21088_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_502_fu_26185_p3() {
    select_ln56_502_fu_26185_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_544_V_read574_phi_phi_fu_21076_p4.read(): ap_phi_mux_data_559_V_read589_phi_phi_fu_21256_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_503_fu_26193_p3() {
    select_ln56_503_fu_26193_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_495_fu_26129_p3.read(): select_ln56_496_fu_26137_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_504_fu_26201_p3() {
    select_ln56_504_fu_26201_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_497_fu_26145_p3.read(): select_ln56_498_fu_26153_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_505_fu_26209_p3() {
    select_ln56_505_fu_26209_p3 = (!or_ln56_4_fu_21837_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_21837_p2.read()[0].to_bool())? select_ln56_499_fu_26161_p3.read(): select_ln56_500_fu_26169_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_506_fu_26217_p3() {
    select_ln56_506_fu_26217_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_501_fu_26177_p3.read(): select_ln56_502_fu_26185_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_507_fu_26225_p3() {
    select_ln56_507_fu_26225_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_503_fu_26193_p3.read(): select_ln56_504_fu_26201_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_508_fu_26233_p3() {
    select_ln56_508_fu_26233_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_505_fu_26209_p3.read(): select_ln56_506_fu_26217_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_509_fu_26241_p3() {
    select_ln56_509_fu_26241_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_507_fu_26225_p3.read(): select_ln56_508_fu_26233_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_50_fu_22269_p3() {
    select_ln56_50_fu_22269_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_68_V_read98_phi_phi_fu_15364_p4.read(): ap_phi_mux_data_67_V_read97_phi_phi_fu_15352_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_510_fu_26259_p3() {
    select_ln56_510_fu_26259_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_574_V_read604_phi_phi_fu_21436_p4.read(): ap_phi_mux_data_573_V_read603_phi_phi_fu_21424_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_511_fu_26267_p3() {
    select_ln56_511_fu_26267_p3 = (!icmp_ln56_12_fu_21755_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_21755_p2.read()[0].to_bool())? ap_phi_mux_data_572_V_read602_phi_phi_fu_21412_p4.read(): ap_phi_mux_data_571_V_read601_phi_phi_fu_21400_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_512_fu_26275_p3() {
    select_ln56_512_fu_26275_p3 = (!icmp_ln56_10_fu_21743_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_21743_p2.read()[0].to_bool())? ap_phi_mux_data_570_V_read600_phi_phi_fu_21388_p4.read(): ap_phi_mux_data_569_V_read599_phi_phi_fu_21376_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_513_fu_26283_p3() {
    select_ln56_513_fu_26283_p3 = (!icmp_ln56_8_fu_21731_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_21731_p2.read()[0].to_bool())? ap_phi_mux_data_568_V_read598_phi_phi_fu_21364_p4.read(): ap_phi_mux_data_567_V_read597_phi_phi_fu_21352_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_514_fu_26291_p3() {
    select_ln56_514_fu_26291_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_566_V_read596_phi_phi_fu_21340_p4.read(): ap_phi_mux_data_565_V_read595_phi_phi_fu_21328_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_515_fu_26299_p3() {
    select_ln56_515_fu_26299_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_564_V_read594_phi_phi_fu_21316_p4.read(): ap_phi_mux_data_563_V_read593_phi_phi_fu_21304_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_516_fu_26307_p3() {
    select_ln56_516_fu_26307_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_562_V_read592_phi_phi_fu_21292_p4.read(): ap_phi_mux_data_561_V_read591_phi_phi_fu_21280_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_517_fu_26315_p3() {
    select_ln56_517_fu_26315_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_560_V_read590_phi_phi_fu_21268_p4.read(): ap_phi_mux_data_575_V_read605_phi_phi_fu_21448_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_518_fu_26323_p3() {
    select_ln56_518_fu_26323_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_510_fu_26259_p3.read(): select_ln56_511_fu_26267_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_519_fu_26331_p3() {
    select_ln56_519_fu_26331_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_512_fu_26275_p3.read(): select_ln56_513_fu_26283_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_51_fu_22277_p3() {
    select_ln56_51_fu_22277_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_66_V_read96_phi_phi_fu_15340_p4.read(): ap_phi_mux_data_65_V_read95_phi_phi_fu_15328_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_520_fu_26339_p3() {
    select_ln56_520_fu_26339_p3 = (!or_ln56_4_fu_21837_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_21837_p2.read()[0].to_bool())? select_ln56_514_fu_26291_p3.read(): select_ln56_515_fu_26299_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_521_fu_26347_p3() {
    select_ln56_521_fu_26347_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_516_fu_26307_p3.read(): select_ln56_517_fu_26315_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_522_fu_26355_p3() {
    select_ln56_522_fu_26355_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_518_fu_26323_p3.read(): select_ln56_519_fu_26331_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_523_fu_26363_p3() {
    select_ln56_523_fu_26363_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_520_fu_26339_p3.read(): select_ln56_521_fu_26347_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_524_fu_26371_p3() {
    select_ln56_524_fu_26371_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_522_fu_26355_p3.read(): select_ln56_523_fu_26363_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_525_fu_26389_p3() {
    select_ln56_525_fu_26389_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_14_V_read44_phi_phi_fu_14716_p4.read(): ap_phi_mux_data_13_V_read43_phi_phi_fu_14704_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_526_fu_26397_p3() {
    select_ln56_526_fu_26397_p3 = (!icmp_ln56_12_fu_21755_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_21755_p2.read()[0].to_bool())? ap_phi_mux_data_12_V_read42_phi_phi_fu_14692_p4.read(): ap_phi_mux_data_11_V_read41_phi_phi_fu_14680_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_527_fu_26405_p3() {
    select_ln56_527_fu_26405_p3 = (!icmp_ln56_10_fu_21743_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_21743_p2.read()[0].to_bool())? ap_phi_mux_data_10_V_read40_phi_phi_fu_14668_p4.read(): ap_phi_mux_data_9_V_read39_phi_phi_fu_14656_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_528_fu_26413_p3() {
    select_ln56_528_fu_26413_p3 = (!icmp_ln56_8_fu_21731_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_21731_p2.read()[0].to_bool())? ap_phi_mux_data_8_V_read38_phi_phi_fu_14644_p4.read(): ap_phi_mux_data_7_V_read37_phi_phi_fu_14632_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_529_fu_26421_p3() {
    select_ln56_529_fu_26421_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_6_V_read36_phi_phi_fu_14620_p4.read(): ap_phi_mux_data_5_V_read35_phi_phi_fu_14608_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_52_fu_22285_p3() {
    select_ln56_52_fu_22285_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_64_V_read94_phi_phi_fu_15316_p4.read(): ap_phi_mux_data_79_V_read109_phi_phi_fu_15496_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_530_fu_26429_p3() {
    select_ln56_530_fu_26429_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_4_V_read34_phi_phi_fu_14596_p4.read(): ap_phi_mux_data_3_V_read33_phi_phi_fu_14584_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_531_fu_26437_p3() {
    select_ln56_531_fu_26437_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_2_V_read32_phi_phi_fu_14572_p4.read(): ap_phi_mux_data_1_V_read31_phi_phi_fu_14560_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_532_fu_26445_p3() {
    select_ln56_532_fu_26445_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_0_V_read30_phi_phi_fu_14548_p4.read(): ap_phi_mux_data_15_V_read45_phi_phi_fu_14728_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_533_fu_26453_p3() {
    select_ln56_533_fu_26453_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_525_fu_26389_p3.read(): select_ln56_526_fu_26397_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_534_fu_26461_p3() {
    select_ln56_534_fu_26461_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_527_fu_26405_p3.read(): select_ln56_528_fu_26413_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_535_fu_26469_p3() {
    select_ln56_535_fu_26469_p3 = (!or_ln56_4_fu_21837_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_21837_p2.read()[0].to_bool())? select_ln56_529_fu_26421_p3.read(): select_ln56_530_fu_26429_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_536_fu_26477_p3() {
    select_ln56_536_fu_26477_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_531_fu_26437_p3.read(): select_ln56_532_fu_26445_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_537_fu_26485_p3() {
    select_ln56_537_fu_26485_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_533_fu_26453_p3.read(): select_ln56_534_fu_26461_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_538_fu_26493_p3() {
    select_ln56_538_fu_26493_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_535_fu_26469_p3.read(): select_ln56_536_fu_26477_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_539_fu_26501_p3() {
    select_ln56_539_fu_26501_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_537_fu_26485_p3.read(): select_ln56_538_fu_26493_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_53_fu_22293_p3() {
    select_ln56_53_fu_22293_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_45_fu_22229_p3.read(): select_ln56_46_fu_22237_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_54_fu_22301_p3() {
    select_ln56_54_fu_22301_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_47_fu_22245_p3.read(): select_ln56_48_fu_22253_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_55_fu_22309_p3() {
    select_ln56_55_fu_22309_p3 = (!or_ln56_4_fu_21837_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_21837_p2.read()[0].to_bool())? select_ln56_49_fu_22261_p3.read(): select_ln56_50_fu_22269_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_56_fu_22317_p3() {
    select_ln56_56_fu_22317_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_51_fu_22277_p3.read(): select_ln56_52_fu_22285_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_57_fu_22325_p3() {
    select_ln56_57_fu_22325_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_53_fu_22293_p3.read(): select_ln56_54_fu_22301_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_58_fu_22333_p3() {
    select_ln56_58_fu_22333_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_55_fu_22309_p3.read(): select_ln56_56_fu_22317_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_59_fu_22341_p3() {
    select_ln56_59_fu_22341_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_57_fu_22325_p3.read(): select_ln56_58_fu_22333_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_5_fu_21843_p3() {
    select_ln56_5_fu_21843_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_20_V_read50_phi_phi_fu_14788_p4.read(): ap_phi_mux_data_19_V_read49_phi_phi_fu_14776_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_60_fu_22359_p3() {
    select_ln56_60_fu_22359_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_94_V_read124_phi_phi_fu_15676_p4.read(): ap_phi_mux_data_93_V_read123_phi_phi_fu_15664_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_61_fu_22367_p3() {
    select_ln56_61_fu_22367_p3 = (!icmp_ln56_12_fu_21755_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_21755_p2.read()[0].to_bool())? ap_phi_mux_data_92_V_read122_phi_phi_fu_15652_p4.read(): ap_phi_mux_data_91_V_read121_phi_phi_fu_15640_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_62_fu_22375_p3() {
    select_ln56_62_fu_22375_p3 = (!icmp_ln56_10_fu_21743_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_21743_p2.read()[0].to_bool())? ap_phi_mux_data_90_V_read120_phi_phi_fu_15628_p4.read(): ap_phi_mux_data_89_V_read119_phi_phi_fu_15616_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_63_fu_22383_p3() {
    select_ln56_63_fu_22383_p3 = (!icmp_ln56_8_fu_21731_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_21731_p2.read()[0].to_bool())? ap_phi_mux_data_88_V_read118_phi_phi_fu_15604_p4.read(): ap_phi_mux_data_87_V_read117_phi_phi_fu_15592_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_64_fu_22391_p3() {
    select_ln56_64_fu_22391_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_86_V_read116_phi_phi_fu_15580_p4.read(): ap_phi_mux_data_85_V_read115_phi_phi_fu_15568_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_65_fu_22399_p3() {
    select_ln56_65_fu_22399_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_84_V_read114_phi_phi_fu_15556_p4.read(): ap_phi_mux_data_83_V_read113_phi_phi_fu_15544_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_66_fu_22407_p3() {
    select_ln56_66_fu_22407_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_82_V_read112_phi_phi_fu_15532_p4.read(): ap_phi_mux_data_81_V_read111_phi_phi_fu_15520_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_67_fu_22415_p3() {
    select_ln56_67_fu_22415_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_80_V_read110_phi_phi_fu_15508_p4.read(): ap_phi_mux_data_95_V_read125_phi_phi_fu_15688_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_68_fu_22423_p3() {
    select_ln56_68_fu_22423_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_60_fu_22359_p3.read(): select_ln56_61_fu_22367_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_69_fu_22431_p3() {
    select_ln56_69_fu_22431_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_62_fu_22375_p3.read(): select_ln56_63_fu_22383_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_6_fu_21857_p3() {
    select_ln56_6_fu_21857_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_18_V_read48_phi_phi_fu_14764_p4.read(): ap_phi_mux_data_17_V_read47_phi_phi_fu_14752_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_70_fu_22439_p3() {
    select_ln56_70_fu_22439_p3 = (!or_ln56_4_fu_21837_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_21837_p2.read()[0].to_bool())? select_ln56_64_fu_22391_p3.read(): select_ln56_65_fu_22399_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_71_fu_22447_p3() {
    select_ln56_71_fu_22447_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_66_fu_22407_p3.read(): select_ln56_67_fu_22415_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_72_fu_22455_p3() {
    select_ln56_72_fu_22455_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_68_fu_22423_p3.read(): select_ln56_69_fu_22431_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_73_fu_22463_p3() {
    select_ln56_73_fu_22463_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_70_fu_22439_p3.read(): select_ln56_71_fu_22447_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_74_fu_22471_p3() {
    select_ln56_74_fu_22471_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_72_fu_22455_p3.read(): select_ln56_73_fu_22463_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_75_fu_22489_p3() {
    select_ln56_75_fu_22489_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_110_V_read140_phi_phi_fu_15868_p4.read(): ap_phi_mux_data_109_V_read139_phi_phi_fu_15856_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_76_fu_22497_p3() {
    select_ln56_76_fu_22497_p3 = (!icmp_ln56_12_fu_21755_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_21755_p2.read()[0].to_bool())? ap_phi_mux_data_108_V_read138_phi_phi_fu_15844_p4.read(): ap_phi_mux_data_107_V_read137_phi_phi_fu_15832_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_77_fu_22505_p3() {
    select_ln56_77_fu_22505_p3 = (!icmp_ln56_10_fu_21743_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_21743_p2.read()[0].to_bool())? ap_phi_mux_data_106_V_read136_phi_phi_fu_15820_p4.read(): ap_phi_mux_data_105_V_read135_phi_phi_fu_15808_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_78_fu_22513_p3() {
    select_ln56_78_fu_22513_p3 = (!icmp_ln56_8_fu_21731_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_21731_p2.read()[0].to_bool())? ap_phi_mux_data_104_V_read134_phi_phi_fu_15796_p4.read(): ap_phi_mux_data_103_V_read133_phi_phi_fu_15784_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_79_fu_22521_p3() {
    select_ln56_79_fu_22521_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_102_V_read132_phi_phi_fu_15772_p4.read(): ap_phi_mux_data_101_V_read131_phi_phi_fu_15760_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_7_fu_21871_p3() {
    select_ln56_7_fu_21871_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_16_V_read46_phi_phi_fu_14740_p4.read(): ap_phi_mux_data_31_V_read61_phi_phi_fu_14920_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_80_fu_22529_p3() {
    select_ln56_80_fu_22529_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_100_V_read130_phi_phi_fu_15748_p4.read(): ap_phi_mux_data_99_V_read129_phi_phi_fu_15736_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_81_fu_22537_p3() {
    select_ln56_81_fu_22537_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_98_V_read128_phi_phi_fu_15724_p4.read(): ap_phi_mux_data_97_V_read127_phi_phi_fu_15712_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_82_fu_22545_p3() {
    select_ln56_82_fu_22545_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_96_V_read126_phi_phi_fu_15700_p4.read(): ap_phi_mux_data_111_V_read141_phi_phi_fu_15880_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_83_fu_22553_p3() {
    select_ln56_83_fu_22553_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_75_fu_22489_p3.read(): select_ln56_76_fu_22497_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_84_fu_22561_p3() {
    select_ln56_84_fu_22561_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_77_fu_22505_p3.read(): select_ln56_78_fu_22513_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_85_fu_22569_p3() {
    select_ln56_85_fu_22569_p3 = (!or_ln56_4_fu_21837_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_4_fu_21837_p2.read()[0].to_bool())? select_ln56_79_fu_22521_p3.read(): select_ln56_80_fu_22529_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_86_fu_22577_p3() {
    select_ln56_86_fu_22577_p3 = (!or_ln56_6_fu_21865_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_6_fu_21865_p2.read()[0].to_bool())? select_ln56_81_fu_22537_p3.read(): select_ln56_82_fu_22545_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_87_fu_22585_p3() {
    select_ln56_87_fu_22585_p3 = (!or_ln56_7_fu_21887_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_7_fu_21887_p2.read()[0].to_bool())? select_ln56_83_fu_22553_p3.read(): select_ln56_84_fu_22561_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_88_fu_22593_p3() {
    select_ln56_88_fu_22593_p3 = (!or_ln56_9_fu_21915_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_9_fu_21915_p2.read()[0].to_bool())? select_ln56_85_fu_22569_p3.read(): select_ln56_86_fu_22577_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_89_fu_22601_p3() {
    select_ln56_89_fu_22601_p3 = (!or_ln56_10_fu_21937_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_10_fu_21937_p2.read()[0].to_bool())? select_ln56_87_fu_22585_p3.read(): select_ln56_88_fu_22593_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_8_fu_21879_p3() {
    select_ln56_8_fu_21879_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_fu_21773_p3.read(): select_ln56_1_fu_21787_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_90_fu_22619_p3() {
    select_ln56_90_fu_22619_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_126_V_read156_phi_phi_fu_16060_p4.read(): ap_phi_mux_data_125_V_read155_phi_phi_fu_16048_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_91_fu_22627_p3() {
    select_ln56_91_fu_22627_p3 = (!icmp_ln56_12_fu_21755_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_12_fu_21755_p2.read()[0].to_bool())? ap_phi_mux_data_124_V_read154_phi_phi_fu_16036_p4.read(): ap_phi_mux_data_123_V_read153_phi_phi_fu_16024_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_92_fu_22635_p3() {
    select_ln56_92_fu_22635_p3 = (!icmp_ln56_10_fu_21743_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_10_fu_21743_p2.read()[0].to_bool())? ap_phi_mux_data_122_V_read152_phi_phi_fu_16012_p4.read(): ap_phi_mux_data_121_V_read151_phi_phi_fu_16000_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_93_fu_22643_p3() {
    select_ln56_93_fu_22643_p3 = (!icmp_ln56_8_fu_21731_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_8_fu_21731_p2.read()[0].to_bool())? ap_phi_mux_data_120_V_read150_phi_phi_fu_15988_p4.read(): ap_phi_mux_data_119_V_read149_phi_phi_fu_15976_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_94_fu_22651_p3() {
    select_ln56_94_fu_22651_p3 = (!icmp_ln56_6_fu_21719_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_6_fu_21719_p2.read()[0].to_bool())? ap_phi_mux_data_118_V_read148_phi_phi_fu_15964_p4.read(): ap_phi_mux_data_117_V_read147_phi_phi_fu_15952_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_95_fu_22659_p3() {
    select_ln56_95_fu_22659_p3 = (!icmp_ln56_4_fu_21707_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_4_fu_21707_p2.read()[0].to_bool())? ap_phi_mux_data_116_V_read146_phi_phi_fu_15940_p4.read(): ap_phi_mux_data_115_V_read145_phi_phi_fu_15928_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_96_fu_22667_p3() {
    select_ln56_96_fu_22667_p3 = (!icmp_ln56_2_fu_21695_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_2_fu_21695_p2.read()[0].to_bool())? ap_phi_mux_data_114_V_read144_phi_phi_fu_15916_p4.read(): ap_phi_mux_data_113_V_read143_phi_phi_fu_15904_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_97_fu_22675_p3() {
    select_ln56_97_fu_22675_p3 = (!icmp_ln56_fu_21683_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_fu_21683_p2.read()[0].to_bool())? ap_phi_mux_data_112_V_read142_phi_phi_fu_15892_p4.read(): ap_phi_mux_data_127_V_read157_phi_phi_fu_16072_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_98_fu_22683_p3() {
    select_ln56_98_fu_22683_p3 = (!or_ln56_fu_21781_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_fu_21781_p2.read()[0].to_bool())? select_ln56_90_fu_22619_p3.read(): select_ln56_91_fu_22627_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_99_fu_22691_p3() {
    select_ln56_99_fu_22691_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_92_fu_22635_p3.read(): select_ln56_93_fu_22643_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_9_fu_21893_p3() {
    select_ln56_9_fu_21893_p3 = (!or_ln56_2_fu_21809_p2.read()[0].is_01())? sc_lv<16>(): ((or_ln56_2_fu_21809_p2.read()[0].to_bool())? select_ln56_2_fu_21801_p3.read(): select_ln56_3_fu_21815_p3.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_select_ln56_fu_21773_p3() {
    select_ln56_fu_21773_p3 = (!icmp_ln56_14_fu_21767_p2.read()[0].is_01())? sc_lv<16>(): ((icmp_ln56_14_fu_21767_p2.read()[0].to_bool())? ap_phi_mux_data_30_V_read60_phi_phi_fu_14908_p4.read(): ap_phi_mux_data_29_V_read59_phi_phi_fu_14896_p4.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_12_cast_fu_30484_p1() {
    sext_ln1116_12_cast_fu_30484_p1 = esl_sext<24,16>(select_ln56_14_reg_43791.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_13_cast_fu_30499_p1() {
    sext_ln1116_13_cast_fu_30499_p1 = esl_sext<24,16>(select_ln56_29_reg_43801.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_14_cast_fu_30514_p1() {
    sext_ln1116_14_cast_fu_30514_p1 = esl_sext<24,16>(select_ln56_44_reg_43811.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_15_cast_fu_30529_p1() {
    sext_ln1116_15_cast_fu_30529_p1 = esl_sext<24,16>(select_ln56_59_reg_43821.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_16_cast_fu_30544_p1() {
    sext_ln1116_16_cast_fu_30544_p1 = esl_sext<24,16>(select_ln56_74_reg_43831.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_17_cast_fu_30559_p1() {
    sext_ln1116_17_cast_fu_30559_p1 = esl_sext<24,16>(select_ln56_89_reg_43841.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_18_cast_fu_30574_p1() {
    sext_ln1116_18_cast_fu_30574_p1 = esl_sext<24,16>(select_ln56_104_reg_43851.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_19_cast_fu_30589_p1() {
    sext_ln1116_19_cast_fu_30589_p1 = esl_sext<24,16>(select_ln56_119_reg_43861.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_20_cast_fu_30604_p1() {
    sext_ln1116_20_cast_fu_30604_p1 = esl_sext<24,16>(select_ln56_134_reg_43871.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_21_cast_fu_30619_p1() {
    sext_ln1116_21_cast_fu_30619_p1 = esl_sext<24,16>(select_ln56_149_reg_43881.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_22_cast_fu_30634_p1() {
    sext_ln1116_22_cast_fu_30634_p1 = esl_sext<24,16>(select_ln56_164_reg_43891.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_23_cast_fu_30649_p1() {
    sext_ln1116_23_cast_fu_30649_p1 = esl_sext<24,16>(select_ln56_179_reg_43901.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_24_cast_fu_30664_p1() {
    sext_ln1116_24_cast_fu_30664_p1 = esl_sext<24,16>(select_ln56_194_reg_43911.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_25_cast_fu_30679_p1() {
    sext_ln1116_25_cast_fu_30679_p1 = esl_sext<24,16>(select_ln56_209_reg_43921.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_26_cast_fu_30694_p1() {
    sext_ln1116_26_cast_fu_30694_p1 = esl_sext<24,16>(select_ln56_224_reg_43931.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_27_cast_fu_30709_p1() {
    sext_ln1116_27_cast_fu_30709_p1 = esl_sext<24,16>(select_ln56_239_reg_43941.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_28_cast_fu_30724_p1() {
    sext_ln1116_28_cast_fu_30724_p1 = esl_sext<24,16>(select_ln56_254_reg_43951.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_29_cast_fu_30739_p1() {
    sext_ln1116_29_cast_fu_30739_p1 = esl_sext<24,16>(select_ln56_269_reg_43961.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_30_cast_fu_30754_p1() {
    sext_ln1116_30_cast_fu_30754_p1 = esl_sext<24,16>(select_ln56_284_reg_43971.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_31_cast_fu_30769_p1() {
    sext_ln1116_31_cast_fu_30769_p1 = esl_sext<24,16>(select_ln56_299_reg_43981.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_32_cast_fu_30784_p1() {
    sext_ln1116_32_cast_fu_30784_p1 = esl_sext<24,16>(select_ln56_314_reg_43991.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_33_cast_fu_30799_p1() {
    sext_ln1116_33_cast_fu_30799_p1 = esl_sext<24,16>(select_ln56_329_reg_44001.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_34_cast_fu_30814_p1() {
    sext_ln1116_34_cast_fu_30814_p1 = esl_sext<24,16>(select_ln56_344_reg_44011.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_35_cast_fu_30829_p1() {
    sext_ln1116_35_cast_fu_30829_p1 = esl_sext<24,16>(select_ln56_359_reg_44021.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_36_cast_fu_30844_p1() {
    sext_ln1116_36_cast_fu_30844_p1 = esl_sext<24,16>(select_ln56_374_reg_44031.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_37_cast_fu_30859_p1() {
    sext_ln1116_37_cast_fu_30859_p1 = esl_sext<24,16>(select_ln56_389_reg_44041.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_38_cast_fu_30874_p1() {
    sext_ln1116_38_cast_fu_30874_p1 = esl_sext<24,16>(select_ln56_404_reg_44051.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_39_cast_fu_30889_p1() {
    sext_ln1116_39_cast_fu_30889_p1 = esl_sext<24,16>(select_ln56_419_reg_44061.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_40_cast_fu_30904_p1() {
    sext_ln1116_40_cast_fu_30904_p1 = esl_sext<24,16>(select_ln56_434_reg_44071.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_41_cast_fu_30919_p1() {
    sext_ln1116_41_cast_fu_30919_p1 = esl_sext<24,16>(select_ln56_449_reg_44081.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_42_cast_fu_30934_p1() {
    sext_ln1116_42_cast_fu_30934_p1 = esl_sext<24,16>(select_ln56_464_reg_44091.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_43_cast_fu_30949_p1() {
    sext_ln1116_43_cast_fu_30949_p1 = esl_sext<24,16>(select_ln56_479_reg_44101.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_44_cast_fu_30964_p1() {
    sext_ln1116_44_cast_fu_30964_p1 = esl_sext<24,16>(select_ln56_494_reg_44111.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_45_cast_fu_30979_p1() {
    sext_ln1116_45_cast_fu_30979_p1 = esl_sext<24,16>(select_ln56_509_reg_44121.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_46_cast_fu_30994_p1() {
    sext_ln1116_46_cast_fu_30994_p1 = esl_sext<24,16>(select_ln56_524_reg_44131.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln1116_47_cast_fu_31012_p1() {
    sext_ln1116_47_cast_fu_31012_p1 = esl_sext<24,16>(select_ln56_539_reg_44142.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_sext_ln708_fu_37087_p1() {
    sext_ln708_fu_37087_p1 = esl_sext<16,15>(trunc_ln708_430_reg_48282.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_trunc_ln56_fu_21679_p1() {
    trunc_ln56_fu_21679_p1 = w6_V_q0.read().range(16-1, 0);
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_w6_V_address0() {
    w6_V_address0 =  (sc_lv<4>) (zext_ln56_fu_21630_p1.read());
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_w6_V_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        w6_V_ce0 = ap_const_logic_1;
    } else {
        w6_V_ce0 = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_w_index_fu_21624_p2() {
    w_index_fu_21624_p2 = (!ap_const_lv4_1.is_01() || !ap_phi_mux_w_index29_phi_fu_6469_p6.read().is_01())? sc_lv<4>(): (sc_biguint<4>(ap_const_lv4_1) + sc_biguint<4>(ap_phi_mux_w_index29_phi_fu_6469_p6.read()));
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_zext_ln56_fu_21630_p1() {
    zext_ln56_fu_21630_p1 = esl_zext<64,4>(ap_phi_mux_w_index29_phi_fu_6469_p6.read());
}

}

