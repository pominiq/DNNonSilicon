#include "dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_347_V_read377_phi_phi_fu_18712_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_347_V_read377_phi_phi_fu_18712_p4 = ap_phi_mux_data_347_V_read377_rewind_phi_fu_11342_p6.read();
    } else {
        ap_phi_mux_data_347_V_read377_phi_phi_fu_18712_p4 = ap_phi_reg_pp0_iter1_data_347_V_read377_phi_reg_18708.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_347_V_read377_rewind_phi_fu_11342_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_347_V_read377_rewind_phi_fu_11342_p6 = data_347_V_read377_phi_reg_18708.read();
    } else {
        ap_phi_mux_data_347_V_read377_rewind_phi_fu_11342_p6 = data_347_V_read377_rewind_reg_11338.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_348_V_read378_phi_phi_fu_18724_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_348_V_read378_phi_phi_fu_18724_p4 = ap_phi_mux_data_348_V_read378_rewind_phi_fu_11356_p6.read();
    } else {
        ap_phi_mux_data_348_V_read378_phi_phi_fu_18724_p4 = ap_phi_reg_pp0_iter1_data_348_V_read378_phi_reg_18720.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_348_V_read378_rewind_phi_fu_11356_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_348_V_read378_rewind_phi_fu_11356_p6 = data_348_V_read378_phi_reg_18720.read();
    } else {
        ap_phi_mux_data_348_V_read378_rewind_phi_fu_11356_p6 = data_348_V_read378_rewind_reg_11352.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_349_V_read379_phi_phi_fu_18736_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_349_V_read379_phi_phi_fu_18736_p4 = ap_phi_mux_data_349_V_read379_rewind_phi_fu_11370_p6.read();
    } else {
        ap_phi_mux_data_349_V_read379_phi_phi_fu_18736_p4 = ap_phi_reg_pp0_iter1_data_349_V_read379_phi_reg_18732.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_349_V_read379_rewind_phi_fu_11370_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_349_V_read379_rewind_phi_fu_11370_p6 = data_349_V_read379_phi_reg_18732.read();
    } else {
        ap_phi_mux_data_349_V_read379_rewind_phi_fu_11370_p6 = data_349_V_read379_rewind_reg_11366.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_34_V_read64_phi_phi_fu_14956_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_34_V_read64_phi_phi_fu_14956_p4 = ap_phi_mux_data_34_V_read64_rewind_phi_fu_6960_p6.read();
    } else {
        ap_phi_mux_data_34_V_read64_phi_phi_fu_14956_p4 = ap_phi_reg_pp0_iter1_data_34_V_read64_phi_reg_14952.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_34_V_read64_rewind_phi_fu_6960_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_34_V_read64_rewind_phi_fu_6960_p6 = data_34_V_read64_phi_reg_14952.read();
    } else {
        ap_phi_mux_data_34_V_read64_rewind_phi_fu_6960_p6 = data_34_V_read64_rewind_reg_6956.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_350_V_read380_phi_phi_fu_18748_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_350_V_read380_phi_phi_fu_18748_p4 = ap_phi_mux_data_350_V_read380_rewind_phi_fu_11384_p6.read();
    } else {
        ap_phi_mux_data_350_V_read380_phi_phi_fu_18748_p4 = ap_phi_reg_pp0_iter1_data_350_V_read380_phi_reg_18744.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_350_V_read380_rewind_phi_fu_11384_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_350_V_read380_rewind_phi_fu_11384_p6 = data_350_V_read380_phi_reg_18744.read();
    } else {
        ap_phi_mux_data_350_V_read380_rewind_phi_fu_11384_p6 = data_350_V_read380_rewind_reg_11380.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_351_V_read381_phi_phi_fu_18760_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_351_V_read381_phi_phi_fu_18760_p4 = ap_phi_mux_data_351_V_read381_rewind_phi_fu_11398_p6.read();
    } else {
        ap_phi_mux_data_351_V_read381_phi_phi_fu_18760_p4 = ap_phi_reg_pp0_iter1_data_351_V_read381_phi_reg_18756.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_351_V_read381_rewind_phi_fu_11398_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_351_V_read381_rewind_phi_fu_11398_p6 = data_351_V_read381_phi_reg_18756.read();
    } else {
        ap_phi_mux_data_351_V_read381_rewind_phi_fu_11398_p6 = data_351_V_read381_rewind_reg_11394.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_352_V_read382_phi_phi_fu_18772_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_352_V_read382_phi_phi_fu_18772_p4 = ap_phi_mux_data_352_V_read382_rewind_phi_fu_11412_p6.read();
    } else {
        ap_phi_mux_data_352_V_read382_phi_phi_fu_18772_p4 = ap_phi_reg_pp0_iter1_data_352_V_read382_phi_reg_18768.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_352_V_read382_rewind_phi_fu_11412_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_352_V_read382_rewind_phi_fu_11412_p6 = data_352_V_read382_phi_reg_18768.read();
    } else {
        ap_phi_mux_data_352_V_read382_rewind_phi_fu_11412_p6 = data_352_V_read382_rewind_reg_11408.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_353_V_read383_phi_phi_fu_18784_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_353_V_read383_phi_phi_fu_18784_p4 = ap_phi_mux_data_353_V_read383_rewind_phi_fu_11426_p6.read();
    } else {
        ap_phi_mux_data_353_V_read383_phi_phi_fu_18784_p4 = ap_phi_reg_pp0_iter1_data_353_V_read383_phi_reg_18780.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_353_V_read383_rewind_phi_fu_11426_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_353_V_read383_rewind_phi_fu_11426_p6 = data_353_V_read383_phi_reg_18780.read();
    } else {
        ap_phi_mux_data_353_V_read383_rewind_phi_fu_11426_p6 = data_353_V_read383_rewind_reg_11422.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_354_V_read384_phi_phi_fu_18796_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_354_V_read384_phi_phi_fu_18796_p4 = ap_phi_mux_data_354_V_read384_rewind_phi_fu_11440_p6.read();
    } else {
        ap_phi_mux_data_354_V_read384_phi_phi_fu_18796_p4 = ap_phi_reg_pp0_iter1_data_354_V_read384_phi_reg_18792.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_354_V_read384_rewind_phi_fu_11440_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_354_V_read384_rewind_phi_fu_11440_p6 = data_354_V_read384_phi_reg_18792.read();
    } else {
        ap_phi_mux_data_354_V_read384_rewind_phi_fu_11440_p6 = data_354_V_read384_rewind_reg_11436.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_355_V_read385_phi_phi_fu_18808_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_355_V_read385_phi_phi_fu_18808_p4 = ap_phi_mux_data_355_V_read385_rewind_phi_fu_11454_p6.read();
    } else {
        ap_phi_mux_data_355_V_read385_phi_phi_fu_18808_p4 = ap_phi_reg_pp0_iter1_data_355_V_read385_phi_reg_18804.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_355_V_read385_rewind_phi_fu_11454_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_355_V_read385_rewind_phi_fu_11454_p6 = data_355_V_read385_phi_reg_18804.read();
    } else {
        ap_phi_mux_data_355_V_read385_rewind_phi_fu_11454_p6 = data_355_V_read385_rewind_reg_11450.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_356_V_read386_phi_phi_fu_18820_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_356_V_read386_phi_phi_fu_18820_p4 = ap_phi_mux_data_356_V_read386_rewind_phi_fu_11468_p6.read();
    } else {
        ap_phi_mux_data_356_V_read386_phi_phi_fu_18820_p4 = ap_phi_reg_pp0_iter1_data_356_V_read386_phi_reg_18816.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_356_V_read386_rewind_phi_fu_11468_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_356_V_read386_rewind_phi_fu_11468_p6 = data_356_V_read386_phi_reg_18816.read();
    } else {
        ap_phi_mux_data_356_V_read386_rewind_phi_fu_11468_p6 = data_356_V_read386_rewind_reg_11464.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_357_V_read387_phi_phi_fu_18832_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_357_V_read387_phi_phi_fu_18832_p4 = ap_phi_mux_data_357_V_read387_rewind_phi_fu_11482_p6.read();
    } else {
        ap_phi_mux_data_357_V_read387_phi_phi_fu_18832_p4 = ap_phi_reg_pp0_iter1_data_357_V_read387_phi_reg_18828.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_357_V_read387_rewind_phi_fu_11482_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_357_V_read387_rewind_phi_fu_11482_p6 = data_357_V_read387_phi_reg_18828.read();
    } else {
        ap_phi_mux_data_357_V_read387_rewind_phi_fu_11482_p6 = data_357_V_read387_rewind_reg_11478.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_358_V_read388_phi_phi_fu_18844_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_358_V_read388_phi_phi_fu_18844_p4 = ap_phi_mux_data_358_V_read388_rewind_phi_fu_11496_p6.read();
    } else {
        ap_phi_mux_data_358_V_read388_phi_phi_fu_18844_p4 = ap_phi_reg_pp0_iter1_data_358_V_read388_phi_reg_18840.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_358_V_read388_rewind_phi_fu_11496_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_358_V_read388_rewind_phi_fu_11496_p6 = data_358_V_read388_phi_reg_18840.read();
    } else {
        ap_phi_mux_data_358_V_read388_rewind_phi_fu_11496_p6 = data_358_V_read388_rewind_reg_11492.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_359_V_read389_phi_phi_fu_18856_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_359_V_read389_phi_phi_fu_18856_p4 = ap_phi_mux_data_359_V_read389_rewind_phi_fu_11510_p6.read();
    } else {
        ap_phi_mux_data_359_V_read389_phi_phi_fu_18856_p4 = ap_phi_reg_pp0_iter1_data_359_V_read389_phi_reg_18852.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_359_V_read389_rewind_phi_fu_11510_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_359_V_read389_rewind_phi_fu_11510_p6 = data_359_V_read389_phi_reg_18852.read();
    } else {
        ap_phi_mux_data_359_V_read389_rewind_phi_fu_11510_p6 = data_359_V_read389_rewind_reg_11506.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_35_V_read65_phi_phi_fu_14968_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_35_V_read65_phi_phi_fu_14968_p4 = ap_phi_mux_data_35_V_read65_rewind_phi_fu_6974_p6.read();
    } else {
        ap_phi_mux_data_35_V_read65_phi_phi_fu_14968_p4 = ap_phi_reg_pp0_iter1_data_35_V_read65_phi_reg_14964.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_35_V_read65_rewind_phi_fu_6974_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_35_V_read65_rewind_phi_fu_6974_p6 = data_35_V_read65_phi_reg_14964.read();
    } else {
        ap_phi_mux_data_35_V_read65_rewind_phi_fu_6974_p6 = data_35_V_read65_rewind_reg_6970.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_360_V_read390_phi_phi_fu_18868_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_360_V_read390_phi_phi_fu_18868_p4 = ap_phi_mux_data_360_V_read390_rewind_phi_fu_11524_p6.read();
    } else {
        ap_phi_mux_data_360_V_read390_phi_phi_fu_18868_p4 = ap_phi_reg_pp0_iter1_data_360_V_read390_phi_reg_18864.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_360_V_read390_rewind_phi_fu_11524_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_360_V_read390_rewind_phi_fu_11524_p6 = data_360_V_read390_phi_reg_18864.read();
    } else {
        ap_phi_mux_data_360_V_read390_rewind_phi_fu_11524_p6 = data_360_V_read390_rewind_reg_11520.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_361_V_read391_phi_phi_fu_18880_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_361_V_read391_phi_phi_fu_18880_p4 = ap_phi_mux_data_361_V_read391_rewind_phi_fu_11538_p6.read();
    } else {
        ap_phi_mux_data_361_V_read391_phi_phi_fu_18880_p4 = ap_phi_reg_pp0_iter1_data_361_V_read391_phi_reg_18876.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_361_V_read391_rewind_phi_fu_11538_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_361_V_read391_rewind_phi_fu_11538_p6 = data_361_V_read391_phi_reg_18876.read();
    } else {
        ap_phi_mux_data_361_V_read391_rewind_phi_fu_11538_p6 = data_361_V_read391_rewind_reg_11534.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_362_V_read392_phi_phi_fu_18892_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_362_V_read392_phi_phi_fu_18892_p4 = ap_phi_mux_data_362_V_read392_rewind_phi_fu_11552_p6.read();
    } else {
        ap_phi_mux_data_362_V_read392_phi_phi_fu_18892_p4 = ap_phi_reg_pp0_iter1_data_362_V_read392_phi_reg_18888.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_362_V_read392_rewind_phi_fu_11552_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_362_V_read392_rewind_phi_fu_11552_p6 = data_362_V_read392_phi_reg_18888.read();
    } else {
        ap_phi_mux_data_362_V_read392_rewind_phi_fu_11552_p6 = data_362_V_read392_rewind_reg_11548.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_363_V_read393_phi_phi_fu_18904_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_363_V_read393_phi_phi_fu_18904_p4 = ap_phi_mux_data_363_V_read393_rewind_phi_fu_11566_p6.read();
    } else {
        ap_phi_mux_data_363_V_read393_phi_phi_fu_18904_p4 = ap_phi_reg_pp0_iter1_data_363_V_read393_phi_reg_18900.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_363_V_read393_rewind_phi_fu_11566_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_363_V_read393_rewind_phi_fu_11566_p6 = data_363_V_read393_phi_reg_18900.read();
    } else {
        ap_phi_mux_data_363_V_read393_rewind_phi_fu_11566_p6 = data_363_V_read393_rewind_reg_11562.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_364_V_read394_phi_phi_fu_18916_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_364_V_read394_phi_phi_fu_18916_p4 = ap_phi_mux_data_364_V_read394_rewind_phi_fu_11580_p6.read();
    } else {
        ap_phi_mux_data_364_V_read394_phi_phi_fu_18916_p4 = ap_phi_reg_pp0_iter1_data_364_V_read394_phi_reg_18912.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_364_V_read394_rewind_phi_fu_11580_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_364_V_read394_rewind_phi_fu_11580_p6 = data_364_V_read394_phi_reg_18912.read();
    } else {
        ap_phi_mux_data_364_V_read394_rewind_phi_fu_11580_p6 = data_364_V_read394_rewind_reg_11576.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_365_V_read395_phi_phi_fu_18928_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_365_V_read395_phi_phi_fu_18928_p4 = ap_phi_mux_data_365_V_read395_rewind_phi_fu_11594_p6.read();
    } else {
        ap_phi_mux_data_365_V_read395_phi_phi_fu_18928_p4 = ap_phi_reg_pp0_iter1_data_365_V_read395_phi_reg_18924.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_365_V_read395_rewind_phi_fu_11594_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_365_V_read395_rewind_phi_fu_11594_p6 = data_365_V_read395_phi_reg_18924.read();
    } else {
        ap_phi_mux_data_365_V_read395_rewind_phi_fu_11594_p6 = data_365_V_read395_rewind_reg_11590.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_366_V_read396_phi_phi_fu_18940_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_366_V_read396_phi_phi_fu_18940_p4 = ap_phi_mux_data_366_V_read396_rewind_phi_fu_11608_p6.read();
    } else {
        ap_phi_mux_data_366_V_read396_phi_phi_fu_18940_p4 = ap_phi_reg_pp0_iter1_data_366_V_read396_phi_reg_18936.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_366_V_read396_rewind_phi_fu_11608_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_366_V_read396_rewind_phi_fu_11608_p6 = data_366_V_read396_phi_reg_18936.read();
    } else {
        ap_phi_mux_data_366_V_read396_rewind_phi_fu_11608_p6 = data_366_V_read396_rewind_reg_11604.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_367_V_read397_phi_phi_fu_18952_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_367_V_read397_phi_phi_fu_18952_p4 = ap_phi_mux_data_367_V_read397_rewind_phi_fu_11622_p6.read();
    } else {
        ap_phi_mux_data_367_V_read397_phi_phi_fu_18952_p4 = ap_phi_reg_pp0_iter1_data_367_V_read397_phi_reg_18948.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_367_V_read397_rewind_phi_fu_11622_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_367_V_read397_rewind_phi_fu_11622_p6 = data_367_V_read397_phi_reg_18948.read();
    } else {
        ap_phi_mux_data_367_V_read397_rewind_phi_fu_11622_p6 = data_367_V_read397_rewind_reg_11618.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_368_V_read398_phi_phi_fu_18964_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_368_V_read398_phi_phi_fu_18964_p4 = ap_phi_mux_data_368_V_read398_rewind_phi_fu_11636_p6.read();
    } else {
        ap_phi_mux_data_368_V_read398_phi_phi_fu_18964_p4 = ap_phi_reg_pp0_iter1_data_368_V_read398_phi_reg_18960.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_368_V_read398_rewind_phi_fu_11636_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_368_V_read398_rewind_phi_fu_11636_p6 = data_368_V_read398_phi_reg_18960.read();
    } else {
        ap_phi_mux_data_368_V_read398_rewind_phi_fu_11636_p6 = data_368_V_read398_rewind_reg_11632.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_369_V_read399_phi_phi_fu_18976_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_369_V_read399_phi_phi_fu_18976_p4 = ap_phi_mux_data_369_V_read399_rewind_phi_fu_11650_p6.read();
    } else {
        ap_phi_mux_data_369_V_read399_phi_phi_fu_18976_p4 = ap_phi_reg_pp0_iter1_data_369_V_read399_phi_reg_18972.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_369_V_read399_rewind_phi_fu_11650_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_369_V_read399_rewind_phi_fu_11650_p6 = data_369_V_read399_phi_reg_18972.read();
    } else {
        ap_phi_mux_data_369_V_read399_rewind_phi_fu_11650_p6 = data_369_V_read399_rewind_reg_11646.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_36_V_read66_phi_phi_fu_14980_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_36_V_read66_phi_phi_fu_14980_p4 = ap_phi_mux_data_36_V_read66_rewind_phi_fu_6988_p6.read();
    } else {
        ap_phi_mux_data_36_V_read66_phi_phi_fu_14980_p4 = ap_phi_reg_pp0_iter1_data_36_V_read66_phi_reg_14976.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_36_V_read66_rewind_phi_fu_6988_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_36_V_read66_rewind_phi_fu_6988_p6 = data_36_V_read66_phi_reg_14976.read();
    } else {
        ap_phi_mux_data_36_V_read66_rewind_phi_fu_6988_p6 = data_36_V_read66_rewind_reg_6984.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_370_V_read400_phi_phi_fu_18988_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_370_V_read400_phi_phi_fu_18988_p4 = ap_phi_mux_data_370_V_read400_rewind_phi_fu_11664_p6.read();
    } else {
        ap_phi_mux_data_370_V_read400_phi_phi_fu_18988_p4 = ap_phi_reg_pp0_iter1_data_370_V_read400_phi_reg_18984.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_370_V_read400_rewind_phi_fu_11664_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_370_V_read400_rewind_phi_fu_11664_p6 = data_370_V_read400_phi_reg_18984.read();
    } else {
        ap_phi_mux_data_370_V_read400_rewind_phi_fu_11664_p6 = data_370_V_read400_rewind_reg_11660.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_371_V_read401_phi_phi_fu_19000_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_371_V_read401_phi_phi_fu_19000_p4 = ap_phi_mux_data_371_V_read401_rewind_phi_fu_11678_p6.read();
    } else {
        ap_phi_mux_data_371_V_read401_phi_phi_fu_19000_p4 = ap_phi_reg_pp0_iter1_data_371_V_read401_phi_reg_18996.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_371_V_read401_rewind_phi_fu_11678_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_371_V_read401_rewind_phi_fu_11678_p6 = data_371_V_read401_phi_reg_18996.read();
    } else {
        ap_phi_mux_data_371_V_read401_rewind_phi_fu_11678_p6 = data_371_V_read401_rewind_reg_11674.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_372_V_read402_phi_phi_fu_19012_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_372_V_read402_phi_phi_fu_19012_p4 = ap_phi_mux_data_372_V_read402_rewind_phi_fu_11692_p6.read();
    } else {
        ap_phi_mux_data_372_V_read402_phi_phi_fu_19012_p4 = ap_phi_reg_pp0_iter1_data_372_V_read402_phi_reg_19008.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_372_V_read402_rewind_phi_fu_11692_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_372_V_read402_rewind_phi_fu_11692_p6 = data_372_V_read402_phi_reg_19008.read();
    } else {
        ap_phi_mux_data_372_V_read402_rewind_phi_fu_11692_p6 = data_372_V_read402_rewind_reg_11688.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_373_V_read403_phi_phi_fu_19024_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_373_V_read403_phi_phi_fu_19024_p4 = ap_phi_mux_data_373_V_read403_rewind_phi_fu_11706_p6.read();
    } else {
        ap_phi_mux_data_373_V_read403_phi_phi_fu_19024_p4 = ap_phi_reg_pp0_iter1_data_373_V_read403_phi_reg_19020.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_373_V_read403_rewind_phi_fu_11706_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_373_V_read403_rewind_phi_fu_11706_p6 = data_373_V_read403_phi_reg_19020.read();
    } else {
        ap_phi_mux_data_373_V_read403_rewind_phi_fu_11706_p6 = data_373_V_read403_rewind_reg_11702.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_374_V_read404_phi_phi_fu_19036_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_374_V_read404_phi_phi_fu_19036_p4 = ap_phi_mux_data_374_V_read404_rewind_phi_fu_11720_p6.read();
    } else {
        ap_phi_mux_data_374_V_read404_phi_phi_fu_19036_p4 = ap_phi_reg_pp0_iter1_data_374_V_read404_phi_reg_19032.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_374_V_read404_rewind_phi_fu_11720_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_374_V_read404_rewind_phi_fu_11720_p6 = data_374_V_read404_phi_reg_19032.read();
    } else {
        ap_phi_mux_data_374_V_read404_rewind_phi_fu_11720_p6 = data_374_V_read404_rewind_reg_11716.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_375_V_read405_phi_phi_fu_19048_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_375_V_read405_phi_phi_fu_19048_p4 = ap_phi_mux_data_375_V_read405_rewind_phi_fu_11734_p6.read();
    } else {
        ap_phi_mux_data_375_V_read405_phi_phi_fu_19048_p4 = ap_phi_reg_pp0_iter1_data_375_V_read405_phi_reg_19044.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_375_V_read405_rewind_phi_fu_11734_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_375_V_read405_rewind_phi_fu_11734_p6 = data_375_V_read405_phi_reg_19044.read();
    } else {
        ap_phi_mux_data_375_V_read405_rewind_phi_fu_11734_p6 = data_375_V_read405_rewind_reg_11730.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_376_V_read406_phi_phi_fu_19060_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_376_V_read406_phi_phi_fu_19060_p4 = ap_phi_mux_data_376_V_read406_rewind_phi_fu_11748_p6.read();
    } else {
        ap_phi_mux_data_376_V_read406_phi_phi_fu_19060_p4 = ap_phi_reg_pp0_iter1_data_376_V_read406_phi_reg_19056.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_376_V_read406_rewind_phi_fu_11748_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_376_V_read406_rewind_phi_fu_11748_p6 = data_376_V_read406_phi_reg_19056.read();
    } else {
        ap_phi_mux_data_376_V_read406_rewind_phi_fu_11748_p6 = data_376_V_read406_rewind_reg_11744.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_377_V_read407_phi_phi_fu_19072_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_377_V_read407_phi_phi_fu_19072_p4 = ap_phi_mux_data_377_V_read407_rewind_phi_fu_11762_p6.read();
    } else {
        ap_phi_mux_data_377_V_read407_phi_phi_fu_19072_p4 = ap_phi_reg_pp0_iter1_data_377_V_read407_phi_reg_19068.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_377_V_read407_rewind_phi_fu_11762_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_377_V_read407_rewind_phi_fu_11762_p6 = data_377_V_read407_phi_reg_19068.read();
    } else {
        ap_phi_mux_data_377_V_read407_rewind_phi_fu_11762_p6 = data_377_V_read407_rewind_reg_11758.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_378_V_read408_phi_phi_fu_19084_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_378_V_read408_phi_phi_fu_19084_p4 = ap_phi_mux_data_378_V_read408_rewind_phi_fu_11776_p6.read();
    } else {
        ap_phi_mux_data_378_V_read408_phi_phi_fu_19084_p4 = ap_phi_reg_pp0_iter1_data_378_V_read408_phi_reg_19080.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_378_V_read408_rewind_phi_fu_11776_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_378_V_read408_rewind_phi_fu_11776_p6 = data_378_V_read408_phi_reg_19080.read();
    } else {
        ap_phi_mux_data_378_V_read408_rewind_phi_fu_11776_p6 = data_378_V_read408_rewind_reg_11772.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_379_V_read409_phi_phi_fu_19096_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_379_V_read409_phi_phi_fu_19096_p4 = ap_phi_mux_data_379_V_read409_rewind_phi_fu_11790_p6.read();
    } else {
        ap_phi_mux_data_379_V_read409_phi_phi_fu_19096_p4 = ap_phi_reg_pp0_iter1_data_379_V_read409_phi_reg_19092.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_379_V_read409_rewind_phi_fu_11790_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_379_V_read409_rewind_phi_fu_11790_p6 = data_379_V_read409_phi_reg_19092.read();
    } else {
        ap_phi_mux_data_379_V_read409_rewind_phi_fu_11790_p6 = data_379_V_read409_rewind_reg_11786.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_37_V_read67_phi_phi_fu_14992_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_37_V_read67_phi_phi_fu_14992_p4 = ap_phi_mux_data_37_V_read67_rewind_phi_fu_7002_p6.read();
    } else {
        ap_phi_mux_data_37_V_read67_phi_phi_fu_14992_p4 = ap_phi_reg_pp0_iter1_data_37_V_read67_phi_reg_14988.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_37_V_read67_rewind_phi_fu_7002_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_37_V_read67_rewind_phi_fu_7002_p6 = data_37_V_read67_phi_reg_14988.read();
    } else {
        ap_phi_mux_data_37_V_read67_rewind_phi_fu_7002_p6 = data_37_V_read67_rewind_reg_6998.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_380_V_read410_phi_phi_fu_19108_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_380_V_read410_phi_phi_fu_19108_p4 = ap_phi_mux_data_380_V_read410_rewind_phi_fu_11804_p6.read();
    } else {
        ap_phi_mux_data_380_V_read410_phi_phi_fu_19108_p4 = ap_phi_reg_pp0_iter1_data_380_V_read410_phi_reg_19104.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_380_V_read410_rewind_phi_fu_11804_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_380_V_read410_rewind_phi_fu_11804_p6 = data_380_V_read410_phi_reg_19104.read();
    } else {
        ap_phi_mux_data_380_V_read410_rewind_phi_fu_11804_p6 = data_380_V_read410_rewind_reg_11800.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_381_V_read411_phi_phi_fu_19120_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_381_V_read411_phi_phi_fu_19120_p4 = ap_phi_mux_data_381_V_read411_rewind_phi_fu_11818_p6.read();
    } else {
        ap_phi_mux_data_381_V_read411_phi_phi_fu_19120_p4 = ap_phi_reg_pp0_iter1_data_381_V_read411_phi_reg_19116.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_381_V_read411_rewind_phi_fu_11818_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_381_V_read411_rewind_phi_fu_11818_p6 = data_381_V_read411_phi_reg_19116.read();
    } else {
        ap_phi_mux_data_381_V_read411_rewind_phi_fu_11818_p6 = data_381_V_read411_rewind_reg_11814.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_382_V_read412_phi_phi_fu_19132_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_382_V_read412_phi_phi_fu_19132_p4 = ap_phi_mux_data_382_V_read412_rewind_phi_fu_11832_p6.read();
    } else {
        ap_phi_mux_data_382_V_read412_phi_phi_fu_19132_p4 = ap_phi_reg_pp0_iter1_data_382_V_read412_phi_reg_19128.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_382_V_read412_rewind_phi_fu_11832_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_382_V_read412_rewind_phi_fu_11832_p6 = data_382_V_read412_phi_reg_19128.read();
    } else {
        ap_phi_mux_data_382_V_read412_rewind_phi_fu_11832_p6 = data_382_V_read412_rewind_reg_11828.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_383_V_read413_phi_phi_fu_19144_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_383_V_read413_phi_phi_fu_19144_p4 = ap_phi_mux_data_383_V_read413_rewind_phi_fu_11846_p6.read();
    } else {
        ap_phi_mux_data_383_V_read413_phi_phi_fu_19144_p4 = ap_phi_reg_pp0_iter1_data_383_V_read413_phi_reg_19140.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_383_V_read413_rewind_phi_fu_11846_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_383_V_read413_rewind_phi_fu_11846_p6 = data_383_V_read413_phi_reg_19140.read();
    } else {
        ap_phi_mux_data_383_V_read413_rewind_phi_fu_11846_p6 = data_383_V_read413_rewind_reg_11842.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_384_V_read414_phi_phi_fu_19156_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_384_V_read414_phi_phi_fu_19156_p4 = ap_phi_mux_data_384_V_read414_rewind_phi_fu_11860_p6.read();
    } else {
        ap_phi_mux_data_384_V_read414_phi_phi_fu_19156_p4 = ap_phi_reg_pp0_iter1_data_384_V_read414_phi_reg_19152.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_384_V_read414_rewind_phi_fu_11860_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_384_V_read414_rewind_phi_fu_11860_p6 = data_384_V_read414_phi_reg_19152.read();
    } else {
        ap_phi_mux_data_384_V_read414_rewind_phi_fu_11860_p6 = data_384_V_read414_rewind_reg_11856.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_385_V_read415_phi_phi_fu_19168_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_385_V_read415_phi_phi_fu_19168_p4 = ap_phi_mux_data_385_V_read415_rewind_phi_fu_11874_p6.read();
    } else {
        ap_phi_mux_data_385_V_read415_phi_phi_fu_19168_p4 = ap_phi_reg_pp0_iter1_data_385_V_read415_phi_reg_19164.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_385_V_read415_rewind_phi_fu_11874_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_385_V_read415_rewind_phi_fu_11874_p6 = data_385_V_read415_phi_reg_19164.read();
    } else {
        ap_phi_mux_data_385_V_read415_rewind_phi_fu_11874_p6 = data_385_V_read415_rewind_reg_11870.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_386_V_read416_phi_phi_fu_19180_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_386_V_read416_phi_phi_fu_19180_p4 = ap_phi_mux_data_386_V_read416_rewind_phi_fu_11888_p6.read();
    } else {
        ap_phi_mux_data_386_V_read416_phi_phi_fu_19180_p4 = ap_phi_reg_pp0_iter1_data_386_V_read416_phi_reg_19176.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_386_V_read416_rewind_phi_fu_11888_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_386_V_read416_rewind_phi_fu_11888_p6 = data_386_V_read416_phi_reg_19176.read();
    } else {
        ap_phi_mux_data_386_V_read416_rewind_phi_fu_11888_p6 = data_386_V_read416_rewind_reg_11884.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_387_V_read417_phi_phi_fu_19192_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_387_V_read417_phi_phi_fu_19192_p4 = ap_phi_mux_data_387_V_read417_rewind_phi_fu_11902_p6.read();
    } else {
        ap_phi_mux_data_387_V_read417_phi_phi_fu_19192_p4 = ap_phi_reg_pp0_iter1_data_387_V_read417_phi_reg_19188.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_387_V_read417_rewind_phi_fu_11902_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_387_V_read417_rewind_phi_fu_11902_p6 = data_387_V_read417_phi_reg_19188.read();
    } else {
        ap_phi_mux_data_387_V_read417_rewind_phi_fu_11902_p6 = data_387_V_read417_rewind_reg_11898.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_388_V_read418_phi_phi_fu_19204_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_388_V_read418_phi_phi_fu_19204_p4 = ap_phi_mux_data_388_V_read418_rewind_phi_fu_11916_p6.read();
    } else {
        ap_phi_mux_data_388_V_read418_phi_phi_fu_19204_p4 = ap_phi_reg_pp0_iter1_data_388_V_read418_phi_reg_19200.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_388_V_read418_rewind_phi_fu_11916_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_388_V_read418_rewind_phi_fu_11916_p6 = data_388_V_read418_phi_reg_19200.read();
    } else {
        ap_phi_mux_data_388_V_read418_rewind_phi_fu_11916_p6 = data_388_V_read418_rewind_reg_11912.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_389_V_read419_phi_phi_fu_19216_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_389_V_read419_phi_phi_fu_19216_p4 = ap_phi_mux_data_389_V_read419_rewind_phi_fu_11930_p6.read();
    } else {
        ap_phi_mux_data_389_V_read419_phi_phi_fu_19216_p4 = ap_phi_reg_pp0_iter1_data_389_V_read419_phi_reg_19212.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_389_V_read419_rewind_phi_fu_11930_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_389_V_read419_rewind_phi_fu_11930_p6 = data_389_V_read419_phi_reg_19212.read();
    } else {
        ap_phi_mux_data_389_V_read419_rewind_phi_fu_11930_p6 = data_389_V_read419_rewind_reg_11926.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_38_V_read68_phi_phi_fu_15004_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_38_V_read68_phi_phi_fu_15004_p4 = ap_phi_mux_data_38_V_read68_rewind_phi_fu_7016_p6.read();
    } else {
        ap_phi_mux_data_38_V_read68_phi_phi_fu_15004_p4 = ap_phi_reg_pp0_iter1_data_38_V_read68_phi_reg_15000.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_38_V_read68_rewind_phi_fu_7016_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_38_V_read68_rewind_phi_fu_7016_p6 = data_38_V_read68_phi_reg_15000.read();
    } else {
        ap_phi_mux_data_38_V_read68_rewind_phi_fu_7016_p6 = data_38_V_read68_rewind_reg_7012.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_390_V_read420_phi_phi_fu_19228_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_390_V_read420_phi_phi_fu_19228_p4 = ap_phi_mux_data_390_V_read420_rewind_phi_fu_11944_p6.read();
    } else {
        ap_phi_mux_data_390_V_read420_phi_phi_fu_19228_p4 = ap_phi_reg_pp0_iter1_data_390_V_read420_phi_reg_19224.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_390_V_read420_rewind_phi_fu_11944_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_390_V_read420_rewind_phi_fu_11944_p6 = data_390_V_read420_phi_reg_19224.read();
    } else {
        ap_phi_mux_data_390_V_read420_rewind_phi_fu_11944_p6 = data_390_V_read420_rewind_reg_11940.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_391_V_read421_phi_phi_fu_19240_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_391_V_read421_phi_phi_fu_19240_p4 = ap_phi_mux_data_391_V_read421_rewind_phi_fu_11958_p6.read();
    } else {
        ap_phi_mux_data_391_V_read421_phi_phi_fu_19240_p4 = ap_phi_reg_pp0_iter1_data_391_V_read421_phi_reg_19236.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_391_V_read421_rewind_phi_fu_11958_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_391_V_read421_rewind_phi_fu_11958_p6 = data_391_V_read421_phi_reg_19236.read();
    } else {
        ap_phi_mux_data_391_V_read421_rewind_phi_fu_11958_p6 = data_391_V_read421_rewind_reg_11954.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_392_V_read422_phi_phi_fu_19252_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_392_V_read422_phi_phi_fu_19252_p4 = ap_phi_mux_data_392_V_read422_rewind_phi_fu_11972_p6.read();
    } else {
        ap_phi_mux_data_392_V_read422_phi_phi_fu_19252_p4 = ap_phi_reg_pp0_iter1_data_392_V_read422_phi_reg_19248.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_392_V_read422_rewind_phi_fu_11972_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_392_V_read422_rewind_phi_fu_11972_p6 = data_392_V_read422_phi_reg_19248.read();
    } else {
        ap_phi_mux_data_392_V_read422_rewind_phi_fu_11972_p6 = data_392_V_read422_rewind_reg_11968.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_393_V_read423_phi_phi_fu_19264_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_393_V_read423_phi_phi_fu_19264_p4 = ap_phi_mux_data_393_V_read423_rewind_phi_fu_11986_p6.read();
    } else {
        ap_phi_mux_data_393_V_read423_phi_phi_fu_19264_p4 = ap_phi_reg_pp0_iter1_data_393_V_read423_phi_reg_19260.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_393_V_read423_rewind_phi_fu_11986_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_393_V_read423_rewind_phi_fu_11986_p6 = data_393_V_read423_phi_reg_19260.read();
    } else {
        ap_phi_mux_data_393_V_read423_rewind_phi_fu_11986_p6 = data_393_V_read423_rewind_reg_11982.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_394_V_read424_phi_phi_fu_19276_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_394_V_read424_phi_phi_fu_19276_p4 = ap_phi_mux_data_394_V_read424_rewind_phi_fu_12000_p6.read();
    } else {
        ap_phi_mux_data_394_V_read424_phi_phi_fu_19276_p4 = ap_phi_reg_pp0_iter1_data_394_V_read424_phi_reg_19272.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_394_V_read424_rewind_phi_fu_12000_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_394_V_read424_rewind_phi_fu_12000_p6 = data_394_V_read424_phi_reg_19272.read();
    } else {
        ap_phi_mux_data_394_V_read424_rewind_phi_fu_12000_p6 = data_394_V_read424_rewind_reg_11996.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_395_V_read425_phi_phi_fu_19288_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_395_V_read425_phi_phi_fu_19288_p4 = ap_phi_mux_data_395_V_read425_rewind_phi_fu_12014_p6.read();
    } else {
        ap_phi_mux_data_395_V_read425_phi_phi_fu_19288_p4 = ap_phi_reg_pp0_iter1_data_395_V_read425_phi_reg_19284.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_395_V_read425_rewind_phi_fu_12014_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_395_V_read425_rewind_phi_fu_12014_p6 = data_395_V_read425_phi_reg_19284.read();
    } else {
        ap_phi_mux_data_395_V_read425_rewind_phi_fu_12014_p6 = data_395_V_read425_rewind_reg_12010.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_396_V_read426_phi_phi_fu_19300_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_396_V_read426_phi_phi_fu_19300_p4 = ap_phi_mux_data_396_V_read426_rewind_phi_fu_12028_p6.read();
    } else {
        ap_phi_mux_data_396_V_read426_phi_phi_fu_19300_p4 = ap_phi_reg_pp0_iter1_data_396_V_read426_phi_reg_19296.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_396_V_read426_rewind_phi_fu_12028_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_396_V_read426_rewind_phi_fu_12028_p6 = data_396_V_read426_phi_reg_19296.read();
    } else {
        ap_phi_mux_data_396_V_read426_rewind_phi_fu_12028_p6 = data_396_V_read426_rewind_reg_12024.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_397_V_read427_phi_phi_fu_19312_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_397_V_read427_phi_phi_fu_19312_p4 = ap_phi_mux_data_397_V_read427_rewind_phi_fu_12042_p6.read();
    } else {
        ap_phi_mux_data_397_V_read427_phi_phi_fu_19312_p4 = ap_phi_reg_pp0_iter1_data_397_V_read427_phi_reg_19308.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_397_V_read427_rewind_phi_fu_12042_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_397_V_read427_rewind_phi_fu_12042_p6 = data_397_V_read427_phi_reg_19308.read();
    } else {
        ap_phi_mux_data_397_V_read427_rewind_phi_fu_12042_p6 = data_397_V_read427_rewind_reg_12038.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_398_V_read428_phi_phi_fu_19324_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_398_V_read428_phi_phi_fu_19324_p4 = ap_phi_mux_data_398_V_read428_rewind_phi_fu_12056_p6.read();
    } else {
        ap_phi_mux_data_398_V_read428_phi_phi_fu_19324_p4 = ap_phi_reg_pp0_iter1_data_398_V_read428_phi_reg_19320.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_398_V_read428_rewind_phi_fu_12056_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_398_V_read428_rewind_phi_fu_12056_p6 = data_398_V_read428_phi_reg_19320.read();
    } else {
        ap_phi_mux_data_398_V_read428_rewind_phi_fu_12056_p6 = data_398_V_read428_rewind_reg_12052.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_399_V_read429_phi_phi_fu_19336_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_399_V_read429_phi_phi_fu_19336_p4 = ap_phi_mux_data_399_V_read429_rewind_phi_fu_12070_p6.read();
    } else {
        ap_phi_mux_data_399_V_read429_phi_phi_fu_19336_p4 = ap_phi_reg_pp0_iter1_data_399_V_read429_phi_reg_19332.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_399_V_read429_rewind_phi_fu_12070_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_399_V_read429_rewind_phi_fu_12070_p6 = data_399_V_read429_phi_reg_19332.read();
    } else {
        ap_phi_mux_data_399_V_read429_rewind_phi_fu_12070_p6 = data_399_V_read429_rewind_reg_12066.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_39_V_read69_phi_phi_fu_15016_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_39_V_read69_phi_phi_fu_15016_p4 = ap_phi_mux_data_39_V_read69_rewind_phi_fu_7030_p6.read();
    } else {
        ap_phi_mux_data_39_V_read69_phi_phi_fu_15016_p4 = ap_phi_reg_pp0_iter1_data_39_V_read69_phi_reg_15012.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_39_V_read69_rewind_phi_fu_7030_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_39_V_read69_rewind_phi_fu_7030_p6 = data_39_V_read69_phi_reg_15012.read();
    } else {
        ap_phi_mux_data_39_V_read69_rewind_phi_fu_7030_p6 = data_39_V_read69_rewind_reg_7026.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_3_V_read33_phi_phi_fu_14584_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_3_V_read33_phi_phi_fu_14584_p4 = ap_phi_mux_data_3_V_read33_rewind_phi_fu_6526_p6.read();
    } else {
        ap_phi_mux_data_3_V_read33_phi_phi_fu_14584_p4 = ap_phi_reg_pp0_iter1_data_3_V_read33_phi_reg_14580.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_3_V_read33_rewind_phi_fu_6526_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_3_V_read33_rewind_phi_fu_6526_p6 = data_3_V_read33_phi_reg_14580.read();
    } else {
        ap_phi_mux_data_3_V_read33_rewind_phi_fu_6526_p6 = data_3_V_read33_rewind_reg_6522.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_400_V_read430_phi_phi_fu_19348_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_400_V_read430_phi_phi_fu_19348_p4 = ap_phi_mux_data_400_V_read430_rewind_phi_fu_12084_p6.read();
    } else {
        ap_phi_mux_data_400_V_read430_phi_phi_fu_19348_p4 = ap_phi_reg_pp0_iter1_data_400_V_read430_phi_reg_19344.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_400_V_read430_rewind_phi_fu_12084_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_400_V_read430_rewind_phi_fu_12084_p6 = data_400_V_read430_phi_reg_19344.read();
    } else {
        ap_phi_mux_data_400_V_read430_rewind_phi_fu_12084_p6 = data_400_V_read430_rewind_reg_12080.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_401_V_read431_phi_phi_fu_19360_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_401_V_read431_phi_phi_fu_19360_p4 = ap_phi_mux_data_401_V_read431_rewind_phi_fu_12098_p6.read();
    } else {
        ap_phi_mux_data_401_V_read431_phi_phi_fu_19360_p4 = ap_phi_reg_pp0_iter1_data_401_V_read431_phi_reg_19356.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_401_V_read431_rewind_phi_fu_12098_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_401_V_read431_rewind_phi_fu_12098_p6 = data_401_V_read431_phi_reg_19356.read();
    } else {
        ap_phi_mux_data_401_V_read431_rewind_phi_fu_12098_p6 = data_401_V_read431_rewind_reg_12094.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_402_V_read432_phi_phi_fu_19372_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_402_V_read432_phi_phi_fu_19372_p4 = ap_phi_mux_data_402_V_read432_rewind_phi_fu_12112_p6.read();
    } else {
        ap_phi_mux_data_402_V_read432_phi_phi_fu_19372_p4 = ap_phi_reg_pp0_iter1_data_402_V_read432_phi_reg_19368.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_402_V_read432_rewind_phi_fu_12112_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_402_V_read432_rewind_phi_fu_12112_p6 = data_402_V_read432_phi_reg_19368.read();
    } else {
        ap_phi_mux_data_402_V_read432_rewind_phi_fu_12112_p6 = data_402_V_read432_rewind_reg_12108.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_403_V_read433_phi_phi_fu_19384_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_403_V_read433_phi_phi_fu_19384_p4 = ap_phi_mux_data_403_V_read433_rewind_phi_fu_12126_p6.read();
    } else {
        ap_phi_mux_data_403_V_read433_phi_phi_fu_19384_p4 = ap_phi_reg_pp0_iter1_data_403_V_read433_phi_reg_19380.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_403_V_read433_rewind_phi_fu_12126_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_403_V_read433_rewind_phi_fu_12126_p6 = data_403_V_read433_phi_reg_19380.read();
    } else {
        ap_phi_mux_data_403_V_read433_rewind_phi_fu_12126_p6 = data_403_V_read433_rewind_reg_12122.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_404_V_read434_phi_phi_fu_19396_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_404_V_read434_phi_phi_fu_19396_p4 = ap_phi_mux_data_404_V_read434_rewind_phi_fu_12140_p6.read();
    } else {
        ap_phi_mux_data_404_V_read434_phi_phi_fu_19396_p4 = ap_phi_reg_pp0_iter1_data_404_V_read434_phi_reg_19392.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_404_V_read434_rewind_phi_fu_12140_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_404_V_read434_rewind_phi_fu_12140_p6 = data_404_V_read434_phi_reg_19392.read();
    } else {
        ap_phi_mux_data_404_V_read434_rewind_phi_fu_12140_p6 = data_404_V_read434_rewind_reg_12136.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_405_V_read435_phi_phi_fu_19408_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_405_V_read435_phi_phi_fu_19408_p4 = ap_phi_mux_data_405_V_read435_rewind_phi_fu_12154_p6.read();
    } else {
        ap_phi_mux_data_405_V_read435_phi_phi_fu_19408_p4 = ap_phi_reg_pp0_iter1_data_405_V_read435_phi_reg_19404.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_405_V_read435_rewind_phi_fu_12154_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_405_V_read435_rewind_phi_fu_12154_p6 = data_405_V_read435_phi_reg_19404.read();
    } else {
        ap_phi_mux_data_405_V_read435_rewind_phi_fu_12154_p6 = data_405_V_read435_rewind_reg_12150.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_406_V_read436_phi_phi_fu_19420_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_406_V_read436_phi_phi_fu_19420_p4 = ap_phi_mux_data_406_V_read436_rewind_phi_fu_12168_p6.read();
    } else {
        ap_phi_mux_data_406_V_read436_phi_phi_fu_19420_p4 = ap_phi_reg_pp0_iter1_data_406_V_read436_phi_reg_19416.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_406_V_read436_rewind_phi_fu_12168_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_406_V_read436_rewind_phi_fu_12168_p6 = data_406_V_read436_phi_reg_19416.read();
    } else {
        ap_phi_mux_data_406_V_read436_rewind_phi_fu_12168_p6 = data_406_V_read436_rewind_reg_12164.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_407_V_read437_phi_phi_fu_19432_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_407_V_read437_phi_phi_fu_19432_p4 = ap_phi_mux_data_407_V_read437_rewind_phi_fu_12182_p6.read();
    } else {
        ap_phi_mux_data_407_V_read437_phi_phi_fu_19432_p4 = ap_phi_reg_pp0_iter1_data_407_V_read437_phi_reg_19428.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_407_V_read437_rewind_phi_fu_12182_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_407_V_read437_rewind_phi_fu_12182_p6 = data_407_V_read437_phi_reg_19428.read();
    } else {
        ap_phi_mux_data_407_V_read437_rewind_phi_fu_12182_p6 = data_407_V_read437_rewind_reg_12178.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_408_V_read438_phi_phi_fu_19444_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_408_V_read438_phi_phi_fu_19444_p4 = ap_phi_mux_data_408_V_read438_rewind_phi_fu_12196_p6.read();
    } else {
        ap_phi_mux_data_408_V_read438_phi_phi_fu_19444_p4 = ap_phi_reg_pp0_iter1_data_408_V_read438_phi_reg_19440.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_408_V_read438_rewind_phi_fu_12196_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_408_V_read438_rewind_phi_fu_12196_p6 = data_408_V_read438_phi_reg_19440.read();
    } else {
        ap_phi_mux_data_408_V_read438_rewind_phi_fu_12196_p6 = data_408_V_read438_rewind_reg_12192.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_409_V_read439_phi_phi_fu_19456_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_409_V_read439_phi_phi_fu_19456_p4 = ap_phi_mux_data_409_V_read439_rewind_phi_fu_12210_p6.read();
    } else {
        ap_phi_mux_data_409_V_read439_phi_phi_fu_19456_p4 = ap_phi_reg_pp0_iter1_data_409_V_read439_phi_reg_19452.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_409_V_read439_rewind_phi_fu_12210_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_409_V_read439_rewind_phi_fu_12210_p6 = data_409_V_read439_phi_reg_19452.read();
    } else {
        ap_phi_mux_data_409_V_read439_rewind_phi_fu_12210_p6 = data_409_V_read439_rewind_reg_12206.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_40_V_read70_phi_phi_fu_15028_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_40_V_read70_phi_phi_fu_15028_p4 = ap_phi_mux_data_40_V_read70_rewind_phi_fu_7044_p6.read();
    } else {
        ap_phi_mux_data_40_V_read70_phi_phi_fu_15028_p4 = ap_phi_reg_pp0_iter1_data_40_V_read70_phi_reg_15024.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_40_V_read70_rewind_phi_fu_7044_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_40_V_read70_rewind_phi_fu_7044_p6 = data_40_V_read70_phi_reg_15024.read();
    } else {
        ap_phi_mux_data_40_V_read70_rewind_phi_fu_7044_p6 = data_40_V_read70_rewind_reg_7040.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_410_V_read440_phi_phi_fu_19468_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_410_V_read440_phi_phi_fu_19468_p4 = ap_phi_mux_data_410_V_read440_rewind_phi_fu_12224_p6.read();
    } else {
        ap_phi_mux_data_410_V_read440_phi_phi_fu_19468_p4 = ap_phi_reg_pp0_iter1_data_410_V_read440_phi_reg_19464.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_410_V_read440_rewind_phi_fu_12224_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_410_V_read440_rewind_phi_fu_12224_p6 = data_410_V_read440_phi_reg_19464.read();
    } else {
        ap_phi_mux_data_410_V_read440_rewind_phi_fu_12224_p6 = data_410_V_read440_rewind_reg_12220.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_411_V_read441_phi_phi_fu_19480_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_411_V_read441_phi_phi_fu_19480_p4 = ap_phi_mux_data_411_V_read441_rewind_phi_fu_12238_p6.read();
    } else {
        ap_phi_mux_data_411_V_read441_phi_phi_fu_19480_p4 = ap_phi_reg_pp0_iter1_data_411_V_read441_phi_reg_19476.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_411_V_read441_rewind_phi_fu_12238_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_411_V_read441_rewind_phi_fu_12238_p6 = data_411_V_read441_phi_reg_19476.read();
    } else {
        ap_phi_mux_data_411_V_read441_rewind_phi_fu_12238_p6 = data_411_V_read441_rewind_reg_12234.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_412_V_read442_phi_phi_fu_19492_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_412_V_read442_phi_phi_fu_19492_p4 = ap_phi_mux_data_412_V_read442_rewind_phi_fu_12252_p6.read();
    } else {
        ap_phi_mux_data_412_V_read442_phi_phi_fu_19492_p4 = ap_phi_reg_pp0_iter1_data_412_V_read442_phi_reg_19488.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_412_V_read442_rewind_phi_fu_12252_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_412_V_read442_rewind_phi_fu_12252_p6 = data_412_V_read442_phi_reg_19488.read();
    } else {
        ap_phi_mux_data_412_V_read442_rewind_phi_fu_12252_p6 = data_412_V_read442_rewind_reg_12248.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_413_V_read443_phi_phi_fu_19504_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_413_V_read443_phi_phi_fu_19504_p4 = ap_phi_mux_data_413_V_read443_rewind_phi_fu_12266_p6.read();
    } else {
        ap_phi_mux_data_413_V_read443_phi_phi_fu_19504_p4 = ap_phi_reg_pp0_iter1_data_413_V_read443_phi_reg_19500.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_413_V_read443_rewind_phi_fu_12266_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_413_V_read443_rewind_phi_fu_12266_p6 = data_413_V_read443_phi_reg_19500.read();
    } else {
        ap_phi_mux_data_413_V_read443_rewind_phi_fu_12266_p6 = data_413_V_read443_rewind_reg_12262.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_414_V_read444_phi_phi_fu_19516_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_414_V_read444_phi_phi_fu_19516_p4 = ap_phi_mux_data_414_V_read444_rewind_phi_fu_12280_p6.read();
    } else {
        ap_phi_mux_data_414_V_read444_phi_phi_fu_19516_p4 = ap_phi_reg_pp0_iter1_data_414_V_read444_phi_reg_19512.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_414_V_read444_rewind_phi_fu_12280_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_414_V_read444_rewind_phi_fu_12280_p6 = data_414_V_read444_phi_reg_19512.read();
    } else {
        ap_phi_mux_data_414_V_read444_rewind_phi_fu_12280_p6 = data_414_V_read444_rewind_reg_12276.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_415_V_read445_phi_phi_fu_19528_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_415_V_read445_phi_phi_fu_19528_p4 = ap_phi_mux_data_415_V_read445_rewind_phi_fu_12294_p6.read();
    } else {
        ap_phi_mux_data_415_V_read445_phi_phi_fu_19528_p4 = ap_phi_reg_pp0_iter1_data_415_V_read445_phi_reg_19524.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_415_V_read445_rewind_phi_fu_12294_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_415_V_read445_rewind_phi_fu_12294_p6 = data_415_V_read445_phi_reg_19524.read();
    } else {
        ap_phi_mux_data_415_V_read445_rewind_phi_fu_12294_p6 = data_415_V_read445_rewind_reg_12290.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_416_V_read446_phi_phi_fu_19540_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_416_V_read446_phi_phi_fu_19540_p4 = ap_phi_mux_data_416_V_read446_rewind_phi_fu_12308_p6.read();
    } else {
        ap_phi_mux_data_416_V_read446_phi_phi_fu_19540_p4 = ap_phi_reg_pp0_iter1_data_416_V_read446_phi_reg_19536.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_416_V_read446_rewind_phi_fu_12308_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_416_V_read446_rewind_phi_fu_12308_p6 = data_416_V_read446_phi_reg_19536.read();
    } else {
        ap_phi_mux_data_416_V_read446_rewind_phi_fu_12308_p6 = data_416_V_read446_rewind_reg_12304.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_417_V_read447_phi_phi_fu_19552_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_417_V_read447_phi_phi_fu_19552_p4 = ap_phi_mux_data_417_V_read447_rewind_phi_fu_12322_p6.read();
    } else {
        ap_phi_mux_data_417_V_read447_phi_phi_fu_19552_p4 = ap_phi_reg_pp0_iter1_data_417_V_read447_phi_reg_19548.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_417_V_read447_rewind_phi_fu_12322_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_417_V_read447_rewind_phi_fu_12322_p6 = data_417_V_read447_phi_reg_19548.read();
    } else {
        ap_phi_mux_data_417_V_read447_rewind_phi_fu_12322_p6 = data_417_V_read447_rewind_reg_12318.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_418_V_read448_phi_phi_fu_19564_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_418_V_read448_phi_phi_fu_19564_p4 = ap_phi_mux_data_418_V_read448_rewind_phi_fu_12336_p6.read();
    } else {
        ap_phi_mux_data_418_V_read448_phi_phi_fu_19564_p4 = ap_phi_reg_pp0_iter1_data_418_V_read448_phi_reg_19560.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_418_V_read448_rewind_phi_fu_12336_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_418_V_read448_rewind_phi_fu_12336_p6 = data_418_V_read448_phi_reg_19560.read();
    } else {
        ap_phi_mux_data_418_V_read448_rewind_phi_fu_12336_p6 = data_418_V_read448_rewind_reg_12332.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_419_V_read449_phi_phi_fu_19576_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_419_V_read449_phi_phi_fu_19576_p4 = ap_phi_mux_data_419_V_read449_rewind_phi_fu_12350_p6.read();
    } else {
        ap_phi_mux_data_419_V_read449_phi_phi_fu_19576_p4 = ap_phi_reg_pp0_iter1_data_419_V_read449_phi_reg_19572.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_419_V_read449_rewind_phi_fu_12350_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_419_V_read449_rewind_phi_fu_12350_p6 = data_419_V_read449_phi_reg_19572.read();
    } else {
        ap_phi_mux_data_419_V_read449_rewind_phi_fu_12350_p6 = data_419_V_read449_rewind_reg_12346.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_41_V_read71_phi_phi_fu_15040_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_41_V_read71_phi_phi_fu_15040_p4 = ap_phi_mux_data_41_V_read71_rewind_phi_fu_7058_p6.read();
    } else {
        ap_phi_mux_data_41_V_read71_phi_phi_fu_15040_p4 = ap_phi_reg_pp0_iter1_data_41_V_read71_phi_reg_15036.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_41_V_read71_rewind_phi_fu_7058_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_41_V_read71_rewind_phi_fu_7058_p6 = data_41_V_read71_phi_reg_15036.read();
    } else {
        ap_phi_mux_data_41_V_read71_rewind_phi_fu_7058_p6 = data_41_V_read71_rewind_reg_7054.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_420_V_read450_phi_phi_fu_19588_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_420_V_read450_phi_phi_fu_19588_p4 = ap_phi_mux_data_420_V_read450_rewind_phi_fu_12364_p6.read();
    } else {
        ap_phi_mux_data_420_V_read450_phi_phi_fu_19588_p4 = ap_phi_reg_pp0_iter1_data_420_V_read450_phi_reg_19584.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_420_V_read450_rewind_phi_fu_12364_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_420_V_read450_rewind_phi_fu_12364_p6 = data_420_V_read450_phi_reg_19584.read();
    } else {
        ap_phi_mux_data_420_V_read450_rewind_phi_fu_12364_p6 = data_420_V_read450_rewind_reg_12360.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_421_V_read451_phi_phi_fu_19600_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_421_V_read451_phi_phi_fu_19600_p4 = ap_phi_mux_data_421_V_read451_rewind_phi_fu_12378_p6.read();
    } else {
        ap_phi_mux_data_421_V_read451_phi_phi_fu_19600_p4 = ap_phi_reg_pp0_iter1_data_421_V_read451_phi_reg_19596.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_421_V_read451_rewind_phi_fu_12378_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_421_V_read451_rewind_phi_fu_12378_p6 = data_421_V_read451_phi_reg_19596.read();
    } else {
        ap_phi_mux_data_421_V_read451_rewind_phi_fu_12378_p6 = data_421_V_read451_rewind_reg_12374.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_422_V_read452_phi_phi_fu_19612_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_422_V_read452_phi_phi_fu_19612_p4 = ap_phi_mux_data_422_V_read452_rewind_phi_fu_12392_p6.read();
    } else {
        ap_phi_mux_data_422_V_read452_phi_phi_fu_19612_p4 = ap_phi_reg_pp0_iter1_data_422_V_read452_phi_reg_19608.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_422_V_read452_rewind_phi_fu_12392_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_422_V_read452_rewind_phi_fu_12392_p6 = data_422_V_read452_phi_reg_19608.read();
    } else {
        ap_phi_mux_data_422_V_read452_rewind_phi_fu_12392_p6 = data_422_V_read452_rewind_reg_12388.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_423_V_read453_phi_phi_fu_19624_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_423_V_read453_phi_phi_fu_19624_p4 = ap_phi_mux_data_423_V_read453_rewind_phi_fu_12406_p6.read();
    } else {
        ap_phi_mux_data_423_V_read453_phi_phi_fu_19624_p4 = ap_phi_reg_pp0_iter1_data_423_V_read453_phi_reg_19620.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_423_V_read453_rewind_phi_fu_12406_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_423_V_read453_rewind_phi_fu_12406_p6 = data_423_V_read453_phi_reg_19620.read();
    } else {
        ap_phi_mux_data_423_V_read453_rewind_phi_fu_12406_p6 = data_423_V_read453_rewind_reg_12402.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_424_V_read454_phi_phi_fu_19636_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_424_V_read454_phi_phi_fu_19636_p4 = ap_phi_mux_data_424_V_read454_rewind_phi_fu_12420_p6.read();
    } else {
        ap_phi_mux_data_424_V_read454_phi_phi_fu_19636_p4 = ap_phi_reg_pp0_iter1_data_424_V_read454_phi_reg_19632.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_424_V_read454_rewind_phi_fu_12420_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_424_V_read454_rewind_phi_fu_12420_p6 = data_424_V_read454_phi_reg_19632.read();
    } else {
        ap_phi_mux_data_424_V_read454_rewind_phi_fu_12420_p6 = data_424_V_read454_rewind_reg_12416.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_425_V_read455_phi_phi_fu_19648_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_425_V_read455_phi_phi_fu_19648_p4 = ap_phi_mux_data_425_V_read455_rewind_phi_fu_12434_p6.read();
    } else {
        ap_phi_mux_data_425_V_read455_phi_phi_fu_19648_p4 = ap_phi_reg_pp0_iter1_data_425_V_read455_phi_reg_19644.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_425_V_read455_rewind_phi_fu_12434_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_425_V_read455_rewind_phi_fu_12434_p6 = data_425_V_read455_phi_reg_19644.read();
    } else {
        ap_phi_mux_data_425_V_read455_rewind_phi_fu_12434_p6 = data_425_V_read455_rewind_reg_12430.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_426_V_read456_phi_phi_fu_19660_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_426_V_read456_phi_phi_fu_19660_p4 = ap_phi_mux_data_426_V_read456_rewind_phi_fu_12448_p6.read();
    } else {
        ap_phi_mux_data_426_V_read456_phi_phi_fu_19660_p4 = ap_phi_reg_pp0_iter1_data_426_V_read456_phi_reg_19656.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_426_V_read456_rewind_phi_fu_12448_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_426_V_read456_rewind_phi_fu_12448_p6 = data_426_V_read456_phi_reg_19656.read();
    } else {
        ap_phi_mux_data_426_V_read456_rewind_phi_fu_12448_p6 = data_426_V_read456_rewind_reg_12444.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_427_V_read457_phi_phi_fu_19672_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_427_V_read457_phi_phi_fu_19672_p4 = ap_phi_mux_data_427_V_read457_rewind_phi_fu_12462_p6.read();
    } else {
        ap_phi_mux_data_427_V_read457_phi_phi_fu_19672_p4 = ap_phi_reg_pp0_iter1_data_427_V_read457_phi_reg_19668.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_427_V_read457_rewind_phi_fu_12462_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_427_V_read457_rewind_phi_fu_12462_p6 = data_427_V_read457_phi_reg_19668.read();
    } else {
        ap_phi_mux_data_427_V_read457_rewind_phi_fu_12462_p6 = data_427_V_read457_rewind_reg_12458.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_428_V_read458_phi_phi_fu_19684_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_428_V_read458_phi_phi_fu_19684_p4 = ap_phi_mux_data_428_V_read458_rewind_phi_fu_12476_p6.read();
    } else {
        ap_phi_mux_data_428_V_read458_phi_phi_fu_19684_p4 = ap_phi_reg_pp0_iter1_data_428_V_read458_phi_reg_19680.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_428_V_read458_rewind_phi_fu_12476_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_428_V_read458_rewind_phi_fu_12476_p6 = data_428_V_read458_phi_reg_19680.read();
    } else {
        ap_phi_mux_data_428_V_read458_rewind_phi_fu_12476_p6 = data_428_V_read458_rewind_reg_12472.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_429_V_read459_phi_phi_fu_19696_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_429_V_read459_phi_phi_fu_19696_p4 = ap_phi_mux_data_429_V_read459_rewind_phi_fu_12490_p6.read();
    } else {
        ap_phi_mux_data_429_V_read459_phi_phi_fu_19696_p4 = ap_phi_reg_pp0_iter1_data_429_V_read459_phi_reg_19692.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_429_V_read459_rewind_phi_fu_12490_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_429_V_read459_rewind_phi_fu_12490_p6 = data_429_V_read459_phi_reg_19692.read();
    } else {
        ap_phi_mux_data_429_V_read459_rewind_phi_fu_12490_p6 = data_429_V_read459_rewind_reg_12486.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_42_V_read72_phi_phi_fu_15052_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_42_V_read72_phi_phi_fu_15052_p4 = ap_phi_mux_data_42_V_read72_rewind_phi_fu_7072_p6.read();
    } else {
        ap_phi_mux_data_42_V_read72_phi_phi_fu_15052_p4 = ap_phi_reg_pp0_iter1_data_42_V_read72_phi_reg_15048.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_42_V_read72_rewind_phi_fu_7072_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_42_V_read72_rewind_phi_fu_7072_p6 = data_42_V_read72_phi_reg_15048.read();
    } else {
        ap_phi_mux_data_42_V_read72_rewind_phi_fu_7072_p6 = data_42_V_read72_rewind_reg_7068.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_430_V_read460_phi_phi_fu_19708_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_430_V_read460_phi_phi_fu_19708_p4 = ap_phi_mux_data_430_V_read460_rewind_phi_fu_12504_p6.read();
    } else {
        ap_phi_mux_data_430_V_read460_phi_phi_fu_19708_p4 = ap_phi_reg_pp0_iter1_data_430_V_read460_phi_reg_19704.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_430_V_read460_rewind_phi_fu_12504_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_430_V_read460_rewind_phi_fu_12504_p6 = data_430_V_read460_phi_reg_19704.read();
    } else {
        ap_phi_mux_data_430_V_read460_rewind_phi_fu_12504_p6 = data_430_V_read460_rewind_reg_12500.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_431_V_read461_phi_phi_fu_19720_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_431_V_read461_phi_phi_fu_19720_p4 = ap_phi_mux_data_431_V_read461_rewind_phi_fu_12518_p6.read();
    } else {
        ap_phi_mux_data_431_V_read461_phi_phi_fu_19720_p4 = ap_phi_reg_pp0_iter1_data_431_V_read461_phi_reg_19716.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_431_V_read461_rewind_phi_fu_12518_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_431_V_read461_rewind_phi_fu_12518_p6 = data_431_V_read461_phi_reg_19716.read();
    } else {
        ap_phi_mux_data_431_V_read461_rewind_phi_fu_12518_p6 = data_431_V_read461_rewind_reg_12514.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_432_V_read462_phi_phi_fu_19732_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_432_V_read462_phi_phi_fu_19732_p4 = ap_phi_mux_data_432_V_read462_rewind_phi_fu_12532_p6.read();
    } else {
        ap_phi_mux_data_432_V_read462_phi_phi_fu_19732_p4 = ap_phi_reg_pp0_iter1_data_432_V_read462_phi_reg_19728.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_432_V_read462_rewind_phi_fu_12532_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_432_V_read462_rewind_phi_fu_12532_p6 = data_432_V_read462_phi_reg_19728.read();
    } else {
        ap_phi_mux_data_432_V_read462_rewind_phi_fu_12532_p6 = data_432_V_read462_rewind_reg_12528.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_433_V_read463_phi_phi_fu_19744_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_433_V_read463_phi_phi_fu_19744_p4 = ap_phi_mux_data_433_V_read463_rewind_phi_fu_12546_p6.read();
    } else {
        ap_phi_mux_data_433_V_read463_phi_phi_fu_19744_p4 = ap_phi_reg_pp0_iter1_data_433_V_read463_phi_reg_19740.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_433_V_read463_rewind_phi_fu_12546_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_433_V_read463_rewind_phi_fu_12546_p6 = data_433_V_read463_phi_reg_19740.read();
    } else {
        ap_phi_mux_data_433_V_read463_rewind_phi_fu_12546_p6 = data_433_V_read463_rewind_reg_12542.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_434_V_read464_phi_phi_fu_19756_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_434_V_read464_phi_phi_fu_19756_p4 = ap_phi_mux_data_434_V_read464_rewind_phi_fu_12560_p6.read();
    } else {
        ap_phi_mux_data_434_V_read464_phi_phi_fu_19756_p4 = ap_phi_reg_pp0_iter1_data_434_V_read464_phi_reg_19752.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_434_V_read464_rewind_phi_fu_12560_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_434_V_read464_rewind_phi_fu_12560_p6 = data_434_V_read464_phi_reg_19752.read();
    } else {
        ap_phi_mux_data_434_V_read464_rewind_phi_fu_12560_p6 = data_434_V_read464_rewind_reg_12556.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_435_V_read465_phi_phi_fu_19768_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_435_V_read465_phi_phi_fu_19768_p4 = ap_phi_mux_data_435_V_read465_rewind_phi_fu_12574_p6.read();
    } else {
        ap_phi_mux_data_435_V_read465_phi_phi_fu_19768_p4 = ap_phi_reg_pp0_iter1_data_435_V_read465_phi_reg_19764.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_435_V_read465_rewind_phi_fu_12574_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_435_V_read465_rewind_phi_fu_12574_p6 = data_435_V_read465_phi_reg_19764.read();
    } else {
        ap_phi_mux_data_435_V_read465_rewind_phi_fu_12574_p6 = data_435_V_read465_rewind_reg_12570.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_436_V_read466_phi_phi_fu_19780_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_436_V_read466_phi_phi_fu_19780_p4 = ap_phi_mux_data_436_V_read466_rewind_phi_fu_12588_p6.read();
    } else {
        ap_phi_mux_data_436_V_read466_phi_phi_fu_19780_p4 = ap_phi_reg_pp0_iter1_data_436_V_read466_phi_reg_19776.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_436_V_read466_rewind_phi_fu_12588_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_436_V_read466_rewind_phi_fu_12588_p6 = data_436_V_read466_phi_reg_19776.read();
    } else {
        ap_phi_mux_data_436_V_read466_rewind_phi_fu_12588_p6 = data_436_V_read466_rewind_reg_12584.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_437_V_read467_phi_phi_fu_19792_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_437_V_read467_phi_phi_fu_19792_p4 = ap_phi_mux_data_437_V_read467_rewind_phi_fu_12602_p6.read();
    } else {
        ap_phi_mux_data_437_V_read467_phi_phi_fu_19792_p4 = ap_phi_reg_pp0_iter1_data_437_V_read467_phi_reg_19788.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_437_V_read467_rewind_phi_fu_12602_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_437_V_read467_rewind_phi_fu_12602_p6 = data_437_V_read467_phi_reg_19788.read();
    } else {
        ap_phi_mux_data_437_V_read467_rewind_phi_fu_12602_p6 = data_437_V_read467_rewind_reg_12598.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_438_V_read468_phi_phi_fu_19804_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_438_V_read468_phi_phi_fu_19804_p4 = ap_phi_mux_data_438_V_read468_rewind_phi_fu_12616_p6.read();
    } else {
        ap_phi_mux_data_438_V_read468_phi_phi_fu_19804_p4 = ap_phi_reg_pp0_iter1_data_438_V_read468_phi_reg_19800.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_438_V_read468_rewind_phi_fu_12616_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_438_V_read468_rewind_phi_fu_12616_p6 = data_438_V_read468_phi_reg_19800.read();
    } else {
        ap_phi_mux_data_438_V_read468_rewind_phi_fu_12616_p6 = data_438_V_read468_rewind_reg_12612.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_439_V_read469_phi_phi_fu_19816_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_439_V_read469_phi_phi_fu_19816_p4 = ap_phi_mux_data_439_V_read469_rewind_phi_fu_12630_p6.read();
    } else {
        ap_phi_mux_data_439_V_read469_phi_phi_fu_19816_p4 = ap_phi_reg_pp0_iter1_data_439_V_read469_phi_reg_19812.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_439_V_read469_rewind_phi_fu_12630_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_439_V_read469_rewind_phi_fu_12630_p6 = data_439_V_read469_phi_reg_19812.read();
    } else {
        ap_phi_mux_data_439_V_read469_rewind_phi_fu_12630_p6 = data_439_V_read469_rewind_reg_12626.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_43_V_read73_phi_phi_fu_15064_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_43_V_read73_phi_phi_fu_15064_p4 = ap_phi_mux_data_43_V_read73_rewind_phi_fu_7086_p6.read();
    } else {
        ap_phi_mux_data_43_V_read73_phi_phi_fu_15064_p4 = ap_phi_reg_pp0_iter1_data_43_V_read73_phi_reg_15060.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_43_V_read73_rewind_phi_fu_7086_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_43_V_read73_rewind_phi_fu_7086_p6 = data_43_V_read73_phi_reg_15060.read();
    } else {
        ap_phi_mux_data_43_V_read73_rewind_phi_fu_7086_p6 = data_43_V_read73_rewind_reg_7082.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_440_V_read470_phi_phi_fu_19828_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_440_V_read470_phi_phi_fu_19828_p4 = ap_phi_mux_data_440_V_read470_rewind_phi_fu_12644_p6.read();
    } else {
        ap_phi_mux_data_440_V_read470_phi_phi_fu_19828_p4 = ap_phi_reg_pp0_iter1_data_440_V_read470_phi_reg_19824.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_440_V_read470_rewind_phi_fu_12644_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_440_V_read470_rewind_phi_fu_12644_p6 = data_440_V_read470_phi_reg_19824.read();
    } else {
        ap_phi_mux_data_440_V_read470_rewind_phi_fu_12644_p6 = data_440_V_read470_rewind_reg_12640.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_441_V_read471_phi_phi_fu_19840_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_441_V_read471_phi_phi_fu_19840_p4 = ap_phi_mux_data_441_V_read471_rewind_phi_fu_12658_p6.read();
    } else {
        ap_phi_mux_data_441_V_read471_phi_phi_fu_19840_p4 = ap_phi_reg_pp0_iter1_data_441_V_read471_phi_reg_19836.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_441_V_read471_rewind_phi_fu_12658_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_441_V_read471_rewind_phi_fu_12658_p6 = data_441_V_read471_phi_reg_19836.read();
    } else {
        ap_phi_mux_data_441_V_read471_rewind_phi_fu_12658_p6 = data_441_V_read471_rewind_reg_12654.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_442_V_read472_phi_phi_fu_19852_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_442_V_read472_phi_phi_fu_19852_p4 = ap_phi_mux_data_442_V_read472_rewind_phi_fu_12672_p6.read();
    } else {
        ap_phi_mux_data_442_V_read472_phi_phi_fu_19852_p4 = ap_phi_reg_pp0_iter1_data_442_V_read472_phi_reg_19848.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_442_V_read472_rewind_phi_fu_12672_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_442_V_read472_rewind_phi_fu_12672_p6 = data_442_V_read472_phi_reg_19848.read();
    } else {
        ap_phi_mux_data_442_V_read472_rewind_phi_fu_12672_p6 = data_442_V_read472_rewind_reg_12668.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_443_V_read473_phi_phi_fu_19864_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_443_V_read473_phi_phi_fu_19864_p4 = ap_phi_mux_data_443_V_read473_rewind_phi_fu_12686_p6.read();
    } else {
        ap_phi_mux_data_443_V_read473_phi_phi_fu_19864_p4 = ap_phi_reg_pp0_iter1_data_443_V_read473_phi_reg_19860.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_443_V_read473_rewind_phi_fu_12686_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_443_V_read473_rewind_phi_fu_12686_p6 = data_443_V_read473_phi_reg_19860.read();
    } else {
        ap_phi_mux_data_443_V_read473_rewind_phi_fu_12686_p6 = data_443_V_read473_rewind_reg_12682.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_444_V_read474_phi_phi_fu_19876_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_444_V_read474_phi_phi_fu_19876_p4 = ap_phi_mux_data_444_V_read474_rewind_phi_fu_12700_p6.read();
    } else {
        ap_phi_mux_data_444_V_read474_phi_phi_fu_19876_p4 = ap_phi_reg_pp0_iter1_data_444_V_read474_phi_reg_19872.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_444_V_read474_rewind_phi_fu_12700_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_444_V_read474_rewind_phi_fu_12700_p6 = data_444_V_read474_phi_reg_19872.read();
    } else {
        ap_phi_mux_data_444_V_read474_rewind_phi_fu_12700_p6 = data_444_V_read474_rewind_reg_12696.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_445_V_read475_phi_phi_fu_19888_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_445_V_read475_phi_phi_fu_19888_p4 = ap_phi_mux_data_445_V_read475_rewind_phi_fu_12714_p6.read();
    } else {
        ap_phi_mux_data_445_V_read475_phi_phi_fu_19888_p4 = ap_phi_reg_pp0_iter1_data_445_V_read475_phi_reg_19884.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_445_V_read475_rewind_phi_fu_12714_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_445_V_read475_rewind_phi_fu_12714_p6 = data_445_V_read475_phi_reg_19884.read();
    } else {
        ap_phi_mux_data_445_V_read475_rewind_phi_fu_12714_p6 = data_445_V_read475_rewind_reg_12710.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_446_V_read476_phi_phi_fu_19900_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_446_V_read476_phi_phi_fu_19900_p4 = ap_phi_mux_data_446_V_read476_rewind_phi_fu_12728_p6.read();
    } else {
        ap_phi_mux_data_446_V_read476_phi_phi_fu_19900_p4 = ap_phi_reg_pp0_iter1_data_446_V_read476_phi_reg_19896.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_446_V_read476_rewind_phi_fu_12728_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_446_V_read476_rewind_phi_fu_12728_p6 = data_446_V_read476_phi_reg_19896.read();
    } else {
        ap_phi_mux_data_446_V_read476_rewind_phi_fu_12728_p6 = data_446_V_read476_rewind_reg_12724.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_447_V_read477_phi_phi_fu_19912_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_447_V_read477_phi_phi_fu_19912_p4 = ap_phi_mux_data_447_V_read477_rewind_phi_fu_12742_p6.read();
    } else {
        ap_phi_mux_data_447_V_read477_phi_phi_fu_19912_p4 = ap_phi_reg_pp0_iter1_data_447_V_read477_phi_reg_19908.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_447_V_read477_rewind_phi_fu_12742_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_447_V_read477_rewind_phi_fu_12742_p6 = data_447_V_read477_phi_reg_19908.read();
    } else {
        ap_phi_mux_data_447_V_read477_rewind_phi_fu_12742_p6 = data_447_V_read477_rewind_reg_12738.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_448_V_read478_phi_phi_fu_19924_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_448_V_read478_phi_phi_fu_19924_p4 = ap_phi_mux_data_448_V_read478_rewind_phi_fu_12756_p6.read();
    } else {
        ap_phi_mux_data_448_V_read478_phi_phi_fu_19924_p4 = ap_phi_reg_pp0_iter1_data_448_V_read478_phi_reg_19920.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_448_V_read478_rewind_phi_fu_12756_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_448_V_read478_rewind_phi_fu_12756_p6 = data_448_V_read478_phi_reg_19920.read();
    } else {
        ap_phi_mux_data_448_V_read478_rewind_phi_fu_12756_p6 = data_448_V_read478_rewind_reg_12752.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_449_V_read479_phi_phi_fu_19936_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_449_V_read479_phi_phi_fu_19936_p4 = ap_phi_mux_data_449_V_read479_rewind_phi_fu_12770_p6.read();
    } else {
        ap_phi_mux_data_449_V_read479_phi_phi_fu_19936_p4 = ap_phi_reg_pp0_iter1_data_449_V_read479_phi_reg_19932.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_449_V_read479_rewind_phi_fu_12770_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_449_V_read479_rewind_phi_fu_12770_p6 = data_449_V_read479_phi_reg_19932.read();
    } else {
        ap_phi_mux_data_449_V_read479_rewind_phi_fu_12770_p6 = data_449_V_read479_rewind_reg_12766.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_44_V_read74_phi_phi_fu_15076_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_44_V_read74_phi_phi_fu_15076_p4 = ap_phi_mux_data_44_V_read74_rewind_phi_fu_7100_p6.read();
    } else {
        ap_phi_mux_data_44_V_read74_phi_phi_fu_15076_p4 = ap_phi_reg_pp0_iter1_data_44_V_read74_phi_reg_15072.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_44_V_read74_rewind_phi_fu_7100_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_44_V_read74_rewind_phi_fu_7100_p6 = data_44_V_read74_phi_reg_15072.read();
    } else {
        ap_phi_mux_data_44_V_read74_rewind_phi_fu_7100_p6 = data_44_V_read74_rewind_reg_7096.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_450_V_read480_phi_phi_fu_19948_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_450_V_read480_phi_phi_fu_19948_p4 = ap_phi_mux_data_450_V_read480_rewind_phi_fu_12784_p6.read();
    } else {
        ap_phi_mux_data_450_V_read480_phi_phi_fu_19948_p4 = ap_phi_reg_pp0_iter1_data_450_V_read480_phi_reg_19944.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_450_V_read480_rewind_phi_fu_12784_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_450_V_read480_rewind_phi_fu_12784_p6 = data_450_V_read480_phi_reg_19944.read();
    } else {
        ap_phi_mux_data_450_V_read480_rewind_phi_fu_12784_p6 = data_450_V_read480_rewind_reg_12780.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_451_V_read481_phi_phi_fu_19960_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_451_V_read481_phi_phi_fu_19960_p4 = ap_phi_mux_data_451_V_read481_rewind_phi_fu_12798_p6.read();
    } else {
        ap_phi_mux_data_451_V_read481_phi_phi_fu_19960_p4 = ap_phi_reg_pp0_iter1_data_451_V_read481_phi_reg_19956.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_451_V_read481_rewind_phi_fu_12798_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_451_V_read481_rewind_phi_fu_12798_p6 = data_451_V_read481_phi_reg_19956.read();
    } else {
        ap_phi_mux_data_451_V_read481_rewind_phi_fu_12798_p6 = data_451_V_read481_rewind_reg_12794.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_452_V_read482_phi_phi_fu_19972_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_452_V_read482_phi_phi_fu_19972_p4 = ap_phi_mux_data_452_V_read482_rewind_phi_fu_12812_p6.read();
    } else {
        ap_phi_mux_data_452_V_read482_phi_phi_fu_19972_p4 = ap_phi_reg_pp0_iter1_data_452_V_read482_phi_reg_19968.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_452_V_read482_rewind_phi_fu_12812_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_452_V_read482_rewind_phi_fu_12812_p6 = data_452_V_read482_phi_reg_19968.read();
    } else {
        ap_phi_mux_data_452_V_read482_rewind_phi_fu_12812_p6 = data_452_V_read482_rewind_reg_12808.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_453_V_read483_phi_phi_fu_19984_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_453_V_read483_phi_phi_fu_19984_p4 = ap_phi_mux_data_453_V_read483_rewind_phi_fu_12826_p6.read();
    } else {
        ap_phi_mux_data_453_V_read483_phi_phi_fu_19984_p4 = ap_phi_reg_pp0_iter1_data_453_V_read483_phi_reg_19980.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_453_V_read483_rewind_phi_fu_12826_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_453_V_read483_rewind_phi_fu_12826_p6 = data_453_V_read483_phi_reg_19980.read();
    } else {
        ap_phi_mux_data_453_V_read483_rewind_phi_fu_12826_p6 = data_453_V_read483_rewind_reg_12822.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_454_V_read484_phi_phi_fu_19996_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_454_V_read484_phi_phi_fu_19996_p4 = ap_phi_mux_data_454_V_read484_rewind_phi_fu_12840_p6.read();
    } else {
        ap_phi_mux_data_454_V_read484_phi_phi_fu_19996_p4 = ap_phi_reg_pp0_iter1_data_454_V_read484_phi_reg_19992.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_454_V_read484_rewind_phi_fu_12840_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_454_V_read484_rewind_phi_fu_12840_p6 = data_454_V_read484_phi_reg_19992.read();
    } else {
        ap_phi_mux_data_454_V_read484_rewind_phi_fu_12840_p6 = data_454_V_read484_rewind_reg_12836.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_455_V_read485_phi_phi_fu_20008_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_455_V_read485_phi_phi_fu_20008_p4 = ap_phi_mux_data_455_V_read485_rewind_phi_fu_12854_p6.read();
    } else {
        ap_phi_mux_data_455_V_read485_phi_phi_fu_20008_p4 = ap_phi_reg_pp0_iter1_data_455_V_read485_phi_reg_20004.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_455_V_read485_rewind_phi_fu_12854_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_455_V_read485_rewind_phi_fu_12854_p6 = data_455_V_read485_phi_reg_20004.read();
    } else {
        ap_phi_mux_data_455_V_read485_rewind_phi_fu_12854_p6 = data_455_V_read485_rewind_reg_12850.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_456_V_read486_phi_phi_fu_20020_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_456_V_read486_phi_phi_fu_20020_p4 = ap_phi_mux_data_456_V_read486_rewind_phi_fu_12868_p6.read();
    } else {
        ap_phi_mux_data_456_V_read486_phi_phi_fu_20020_p4 = ap_phi_reg_pp0_iter1_data_456_V_read486_phi_reg_20016.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_456_V_read486_rewind_phi_fu_12868_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_456_V_read486_rewind_phi_fu_12868_p6 = data_456_V_read486_phi_reg_20016.read();
    } else {
        ap_phi_mux_data_456_V_read486_rewind_phi_fu_12868_p6 = data_456_V_read486_rewind_reg_12864.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_457_V_read487_phi_phi_fu_20032_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_457_V_read487_phi_phi_fu_20032_p4 = ap_phi_mux_data_457_V_read487_rewind_phi_fu_12882_p6.read();
    } else {
        ap_phi_mux_data_457_V_read487_phi_phi_fu_20032_p4 = ap_phi_reg_pp0_iter1_data_457_V_read487_phi_reg_20028.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_457_V_read487_rewind_phi_fu_12882_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_457_V_read487_rewind_phi_fu_12882_p6 = data_457_V_read487_phi_reg_20028.read();
    } else {
        ap_phi_mux_data_457_V_read487_rewind_phi_fu_12882_p6 = data_457_V_read487_rewind_reg_12878.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_458_V_read488_phi_phi_fu_20044_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_458_V_read488_phi_phi_fu_20044_p4 = ap_phi_mux_data_458_V_read488_rewind_phi_fu_12896_p6.read();
    } else {
        ap_phi_mux_data_458_V_read488_phi_phi_fu_20044_p4 = ap_phi_reg_pp0_iter1_data_458_V_read488_phi_reg_20040.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_458_V_read488_rewind_phi_fu_12896_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_458_V_read488_rewind_phi_fu_12896_p6 = data_458_V_read488_phi_reg_20040.read();
    } else {
        ap_phi_mux_data_458_V_read488_rewind_phi_fu_12896_p6 = data_458_V_read488_rewind_reg_12892.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_459_V_read489_phi_phi_fu_20056_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_459_V_read489_phi_phi_fu_20056_p4 = ap_phi_mux_data_459_V_read489_rewind_phi_fu_12910_p6.read();
    } else {
        ap_phi_mux_data_459_V_read489_phi_phi_fu_20056_p4 = ap_phi_reg_pp0_iter1_data_459_V_read489_phi_reg_20052.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_459_V_read489_rewind_phi_fu_12910_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_459_V_read489_rewind_phi_fu_12910_p6 = data_459_V_read489_phi_reg_20052.read();
    } else {
        ap_phi_mux_data_459_V_read489_rewind_phi_fu_12910_p6 = data_459_V_read489_rewind_reg_12906.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_45_V_read75_phi_phi_fu_15088_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_45_V_read75_phi_phi_fu_15088_p4 = ap_phi_mux_data_45_V_read75_rewind_phi_fu_7114_p6.read();
    } else {
        ap_phi_mux_data_45_V_read75_phi_phi_fu_15088_p4 = ap_phi_reg_pp0_iter1_data_45_V_read75_phi_reg_15084.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_45_V_read75_rewind_phi_fu_7114_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_45_V_read75_rewind_phi_fu_7114_p6 = data_45_V_read75_phi_reg_15084.read();
    } else {
        ap_phi_mux_data_45_V_read75_rewind_phi_fu_7114_p6 = data_45_V_read75_rewind_reg_7110.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_460_V_read490_phi_phi_fu_20068_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_460_V_read490_phi_phi_fu_20068_p4 = ap_phi_mux_data_460_V_read490_rewind_phi_fu_12924_p6.read();
    } else {
        ap_phi_mux_data_460_V_read490_phi_phi_fu_20068_p4 = ap_phi_reg_pp0_iter1_data_460_V_read490_phi_reg_20064.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_460_V_read490_rewind_phi_fu_12924_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_460_V_read490_rewind_phi_fu_12924_p6 = data_460_V_read490_phi_reg_20064.read();
    } else {
        ap_phi_mux_data_460_V_read490_rewind_phi_fu_12924_p6 = data_460_V_read490_rewind_reg_12920.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_461_V_read491_phi_phi_fu_20080_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_461_V_read491_phi_phi_fu_20080_p4 = ap_phi_mux_data_461_V_read491_rewind_phi_fu_12938_p6.read();
    } else {
        ap_phi_mux_data_461_V_read491_phi_phi_fu_20080_p4 = ap_phi_reg_pp0_iter1_data_461_V_read491_phi_reg_20076.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_461_V_read491_rewind_phi_fu_12938_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_461_V_read491_rewind_phi_fu_12938_p6 = data_461_V_read491_phi_reg_20076.read();
    } else {
        ap_phi_mux_data_461_V_read491_rewind_phi_fu_12938_p6 = data_461_V_read491_rewind_reg_12934.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_462_V_read492_phi_phi_fu_20092_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_462_V_read492_phi_phi_fu_20092_p4 = ap_phi_mux_data_462_V_read492_rewind_phi_fu_12952_p6.read();
    } else {
        ap_phi_mux_data_462_V_read492_phi_phi_fu_20092_p4 = ap_phi_reg_pp0_iter1_data_462_V_read492_phi_reg_20088.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_462_V_read492_rewind_phi_fu_12952_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_462_V_read492_rewind_phi_fu_12952_p6 = data_462_V_read492_phi_reg_20088.read();
    } else {
        ap_phi_mux_data_462_V_read492_rewind_phi_fu_12952_p6 = data_462_V_read492_rewind_reg_12948.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_463_V_read493_phi_phi_fu_20104_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_463_V_read493_phi_phi_fu_20104_p4 = ap_phi_mux_data_463_V_read493_rewind_phi_fu_12966_p6.read();
    } else {
        ap_phi_mux_data_463_V_read493_phi_phi_fu_20104_p4 = ap_phi_reg_pp0_iter1_data_463_V_read493_phi_reg_20100.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_463_V_read493_rewind_phi_fu_12966_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_463_V_read493_rewind_phi_fu_12966_p6 = data_463_V_read493_phi_reg_20100.read();
    } else {
        ap_phi_mux_data_463_V_read493_rewind_phi_fu_12966_p6 = data_463_V_read493_rewind_reg_12962.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_464_V_read494_phi_phi_fu_20116_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_464_V_read494_phi_phi_fu_20116_p4 = ap_phi_mux_data_464_V_read494_rewind_phi_fu_12980_p6.read();
    } else {
        ap_phi_mux_data_464_V_read494_phi_phi_fu_20116_p4 = ap_phi_reg_pp0_iter1_data_464_V_read494_phi_reg_20112.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_464_V_read494_rewind_phi_fu_12980_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_464_V_read494_rewind_phi_fu_12980_p6 = data_464_V_read494_phi_reg_20112.read();
    } else {
        ap_phi_mux_data_464_V_read494_rewind_phi_fu_12980_p6 = data_464_V_read494_rewind_reg_12976.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_465_V_read495_phi_phi_fu_20128_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_465_V_read495_phi_phi_fu_20128_p4 = ap_phi_mux_data_465_V_read495_rewind_phi_fu_12994_p6.read();
    } else {
        ap_phi_mux_data_465_V_read495_phi_phi_fu_20128_p4 = ap_phi_reg_pp0_iter1_data_465_V_read495_phi_reg_20124.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_465_V_read495_rewind_phi_fu_12994_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_465_V_read495_rewind_phi_fu_12994_p6 = data_465_V_read495_phi_reg_20124.read();
    } else {
        ap_phi_mux_data_465_V_read495_rewind_phi_fu_12994_p6 = data_465_V_read495_rewind_reg_12990.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_466_V_read496_phi_phi_fu_20140_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_466_V_read496_phi_phi_fu_20140_p4 = ap_phi_mux_data_466_V_read496_rewind_phi_fu_13008_p6.read();
    } else {
        ap_phi_mux_data_466_V_read496_phi_phi_fu_20140_p4 = ap_phi_reg_pp0_iter1_data_466_V_read496_phi_reg_20136.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_466_V_read496_rewind_phi_fu_13008_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_466_V_read496_rewind_phi_fu_13008_p6 = data_466_V_read496_phi_reg_20136.read();
    } else {
        ap_phi_mux_data_466_V_read496_rewind_phi_fu_13008_p6 = data_466_V_read496_rewind_reg_13004.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_467_V_read497_phi_phi_fu_20152_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_467_V_read497_phi_phi_fu_20152_p4 = ap_phi_mux_data_467_V_read497_rewind_phi_fu_13022_p6.read();
    } else {
        ap_phi_mux_data_467_V_read497_phi_phi_fu_20152_p4 = ap_phi_reg_pp0_iter1_data_467_V_read497_phi_reg_20148.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_467_V_read497_rewind_phi_fu_13022_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_467_V_read497_rewind_phi_fu_13022_p6 = data_467_V_read497_phi_reg_20148.read();
    } else {
        ap_phi_mux_data_467_V_read497_rewind_phi_fu_13022_p6 = data_467_V_read497_rewind_reg_13018.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_468_V_read498_phi_phi_fu_20164_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_468_V_read498_phi_phi_fu_20164_p4 = ap_phi_mux_data_468_V_read498_rewind_phi_fu_13036_p6.read();
    } else {
        ap_phi_mux_data_468_V_read498_phi_phi_fu_20164_p4 = ap_phi_reg_pp0_iter1_data_468_V_read498_phi_reg_20160.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_468_V_read498_rewind_phi_fu_13036_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_468_V_read498_rewind_phi_fu_13036_p6 = data_468_V_read498_phi_reg_20160.read();
    } else {
        ap_phi_mux_data_468_V_read498_rewind_phi_fu_13036_p6 = data_468_V_read498_rewind_reg_13032.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_469_V_read499_phi_phi_fu_20176_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_469_V_read499_phi_phi_fu_20176_p4 = ap_phi_mux_data_469_V_read499_rewind_phi_fu_13050_p6.read();
    } else {
        ap_phi_mux_data_469_V_read499_phi_phi_fu_20176_p4 = ap_phi_reg_pp0_iter1_data_469_V_read499_phi_reg_20172.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_469_V_read499_rewind_phi_fu_13050_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_469_V_read499_rewind_phi_fu_13050_p6 = data_469_V_read499_phi_reg_20172.read();
    } else {
        ap_phi_mux_data_469_V_read499_rewind_phi_fu_13050_p6 = data_469_V_read499_rewind_reg_13046.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_46_V_read76_phi_phi_fu_15100_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_46_V_read76_phi_phi_fu_15100_p4 = ap_phi_mux_data_46_V_read76_rewind_phi_fu_7128_p6.read();
    } else {
        ap_phi_mux_data_46_V_read76_phi_phi_fu_15100_p4 = ap_phi_reg_pp0_iter1_data_46_V_read76_phi_reg_15096.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_46_V_read76_rewind_phi_fu_7128_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_46_V_read76_rewind_phi_fu_7128_p6 = data_46_V_read76_phi_reg_15096.read();
    } else {
        ap_phi_mux_data_46_V_read76_rewind_phi_fu_7128_p6 = data_46_V_read76_rewind_reg_7124.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_470_V_read500_phi_phi_fu_20188_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_470_V_read500_phi_phi_fu_20188_p4 = ap_phi_mux_data_470_V_read500_rewind_phi_fu_13064_p6.read();
    } else {
        ap_phi_mux_data_470_V_read500_phi_phi_fu_20188_p4 = ap_phi_reg_pp0_iter1_data_470_V_read500_phi_reg_20184.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_470_V_read500_rewind_phi_fu_13064_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_470_V_read500_rewind_phi_fu_13064_p6 = data_470_V_read500_phi_reg_20184.read();
    } else {
        ap_phi_mux_data_470_V_read500_rewind_phi_fu_13064_p6 = data_470_V_read500_rewind_reg_13060.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_471_V_read501_phi_phi_fu_20200_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_471_V_read501_phi_phi_fu_20200_p4 = ap_phi_mux_data_471_V_read501_rewind_phi_fu_13078_p6.read();
    } else {
        ap_phi_mux_data_471_V_read501_phi_phi_fu_20200_p4 = ap_phi_reg_pp0_iter1_data_471_V_read501_phi_reg_20196.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_471_V_read501_rewind_phi_fu_13078_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_471_V_read501_rewind_phi_fu_13078_p6 = data_471_V_read501_phi_reg_20196.read();
    } else {
        ap_phi_mux_data_471_V_read501_rewind_phi_fu_13078_p6 = data_471_V_read501_rewind_reg_13074.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_472_V_read502_phi_phi_fu_20212_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_472_V_read502_phi_phi_fu_20212_p4 = ap_phi_mux_data_472_V_read502_rewind_phi_fu_13092_p6.read();
    } else {
        ap_phi_mux_data_472_V_read502_phi_phi_fu_20212_p4 = ap_phi_reg_pp0_iter1_data_472_V_read502_phi_reg_20208.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_472_V_read502_rewind_phi_fu_13092_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_472_V_read502_rewind_phi_fu_13092_p6 = data_472_V_read502_phi_reg_20208.read();
    } else {
        ap_phi_mux_data_472_V_read502_rewind_phi_fu_13092_p6 = data_472_V_read502_rewind_reg_13088.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_473_V_read503_phi_phi_fu_20224_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_473_V_read503_phi_phi_fu_20224_p4 = ap_phi_mux_data_473_V_read503_rewind_phi_fu_13106_p6.read();
    } else {
        ap_phi_mux_data_473_V_read503_phi_phi_fu_20224_p4 = ap_phi_reg_pp0_iter1_data_473_V_read503_phi_reg_20220.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_473_V_read503_rewind_phi_fu_13106_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_473_V_read503_rewind_phi_fu_13106_p6 = data_473_V_read503_phi_reg_20220.read();
    } else {
        ap_phi_mux_data_473_V_read503_rewind_phi_fu_13106_p6 = data_473_V_read503_rewind_reg_13102.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_474_V_read504_phi_phi_fu_20236_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_474_V_read504_phi_phi_fu_20236_p4 = ap_phi_mux_data_474_V_read504_rewind_phi_fu_13120_p6.read();
    } else {
        ap_phi_mux_data_474_V_read504_phi_phi_fu_20236_p4 = ap_phi_reg_pp0_iter1_data_474_V_read504_phi_reg_20232.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_474_V_read504_rewind_phi_fu_13120_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_474_V_read504_rewind_phi_fu_13120_p6 = data_474_V_read504_phi_reg_20232.read();
    } else {
        ap_phi_mux_data_474_V_read504_rewind_phi_fu_13120_p6 = data_474_V_read504_rewind_reg_13116.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_475_V_read505_phi_phi_fu_20248_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_475_V_read505_phi_phi_fu_20248_p4 = ap_phi_mux_data_475_V_read505_rewind_phi_fu_13134_p6.read();
    } else {
        ap_phi_mux_data_475_V_read505_phi_phi_fu_20248_p4 = ap_phi_reg_pp0_iter1_data_475_V_read505_phi_reg_20244.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_475_V_read505_rewind_phi_fu_13134_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_475_V_read505_rewind_phi_fu_13134_p6 = data_475_V_read505_phi_reg_20244.read();
    } else {
        ap_phi_mux_data_475_V_read505_rewind_phi_fu_13134_p6 = data_475_V_read505_rewind_reg_13130.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_476_V_read506_phi_phi_fu_20260_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_476_V_read506_phi_phi_fu_20260_p4 = ap_phi_mux_data_476_V_read506_rewind_phi_fu_13148_p6.read();
    } else {
        ap_phi_mux_data_476_V_read506_phi_phi_fu_20260_p4 = ap_phi_reg_pp0_iter1_data_476_V_read506_phi_reg_20256.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_476_V_read506_rewind_phi_fu_13148_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_476_V_read506_rewind_phi_fu_13148_p6 = data_476_V_read506_phi_reg_20256.read();
    } else {
        ap_phi_mux_data_476_V_read506_rewind_phi_fu_13148_p6 = data_476_V_read506_rewind_reg_13144.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_477_V_read507_phi_phi_fu_20272_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_477_V_read507_phi_phi_fu_20272_p4 = ap_phi_mux_data_477_V_read507_rewind_phi_fu_13162_p6.read();
    } else {
        ap_phi_mux_data_477_V_read507_phi_phi_fu_20272_p4 = ap_phi_reg_pp0_iter1_data_477_V_read507_phi_reg_20268.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_477_V_read507_rewind_phi_fu_13162_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_477_V_read507_rewind_phi_fu_13162_p6 = data_477_V_read507_phi_reg_20268.read();
    } else {
        ap_phi_mux_data_477_V_read507_rewind_phi_fu_13162_p6 = data_477_V_read507_rewind_reg_13158.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_478_V_read508_phi_phi_fu_20284_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_478_V_read508_phi_phi_fu_20284_p4 = ap_phi_mux_data_478_V_read508_rewind_phi_fu_13176_p6.read();
    } else {
        ap_phi_mux_data_478_V_read508_phi_phi_fu_20284_p4 = ap_phi_reg_pp0_iter1_data_478_V_read508_phi_reg_20280.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_478_V_read508_rewind_phi_fu_13176_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_478_V_read508_rewind_phi_fu_13176_p6 = data_478_V_read508_phi_reg_20280.read();
    } else {
        ap_phi_mux_data_478_V_read508_rewind_phi_fu_13176_p6 = data_478_V_read508_rewind_reg_13172.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_479_V_read509_phi_phi_fu_20296_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_479_V_read509_phi_phi_fu_20296_p4 = ap_phi_mux_data_479_V_read509_rewind_phi_fu_13190_p6.read();
    } else {
        ap_phi_mux_data_479_V_read509_phi_phi_fu_20296_p4 = ap_phi_reg_pp0_iter1_data_479_V_read509_phi_reg_20292.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_479_V_read509_rewind_phi_fu_13190_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_479_V_read509_rewind_phi_fu_13190_p6 = data_479_V_read509_phi_reg_20292.read();
    } else {
        ap_phi_mux_data_479_V_read509_rewind_phi_fu_13190_p6 = data_479_V_read509_rewind_reg_13186.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_47_V_read77_phi_phi_fu_15112_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_47_V_read77_phi_phi_fu_15112_p4 = ap_phi_mux_data_47_V_read77_rewind_phi_fu_7142_p6.read();
    } else {
        ap_phi_mux_data_47_V_read77_phi_phi_fu_15112_p4 = ap_phi_reg_pp0_iter1_data_47_V_read77_phi_reg_15108.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_47_V_read77_rewind_phi_fu_7142_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_47_V_read77_rewind_phi_fu_7142_p6 = data_47_V_read77_phi_reg_15108.read();
    } else {
        ap_phi_mux_data_47_V_read77_rewind_phi_fu_7142_p6 = data_47_V_read77_rewind_reg_7138.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_480_V_read510_phi_phi_fu_20308_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_480_V_read510_phi_phi_fu_20308_p4 = ap_phi_mux_data_480_V_read510_rewind_phi_fu_13204_p6.read();
    } else {
        ap_phi_mux_data_480_V_read510_phi_phi_fu_20308_p4 = ap_phi_reg_pp0_iter1_data_480_V_read510_phi_reg_20304.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_480_V_read510_rewind_phi_fu_13204_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_480_V_read510_rewind_phi_fu_13204_p6 = data_480_V_read510_phi_reg_20304.read();
    } else {
        ap_phi_mux_data_480_V_read510_rewind_phi_fu_13204_p6 = data_480_V_read510_rewind_reg_13200.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_481_V_read511_phi_phi_fu_20320_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_481_V_read511_phi_phi_fu_20320_p4 = ap_phi_mux_data_481_V_read511_rewind_phi_fu_13218_p6.read();
    } else {
        ap_phi_mux_data_481_V_read511_phi_phi_fu_20320_p4 = ap_phi_reg_pp0_iter1_data_481_V_read511_phi_reg_20316.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_481_V_read511_rewind_phi_fu_13218_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_481_V_read511_rewind_phi_fu_13218_p6 = data_481_V_read511_phi_reg_20316.read();
    } else {
        ap_phi_mux_data_481_V_read511_rewind_phi_fu_13218_p6 = data_481_V_read511_rewind_reg_13214.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_482_V_read512_phi_phi_fu_20332_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_482_V_read512_phi_phi_fu_20332_p4 = ap_phi_mux_data_482_V_read512_rewind_phi_fu_13232_p6.read();
    } else {
        ap_phi_mux_data_482_V_read512_phi_phi_fu_20332_p4 = ap_phi_reg_pp0_iter1_data_482_V_read512_phi_reg_20328.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_482_V_read512_rewind_phi_fu_13232_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_482_V_read512_rewind_phi_fu_13232_p6 = data_482_V_read512_phi_reg_20328.read();
    } else {
        ap_phi_mux_data_482_V_read512_rewind_phi_fu_13232_p6 = data_482_V_read512_rewind_reg_13228.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_483_V_read513_phi_phi_fu_20344_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_483_V_read513_phi_phi_fu_20344_p4 = ap_phi_mux_data_483_V_read513_rewind_phi_fu_13246_p6.read();
    } else {
        ap_phi_mux_data_483_V_read513_phi_phi_fu_20344_p4 = ap_phi_reg_pp0_iter1_data_483_V_read513_phi_reg_20340.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_483_V_read513_rewind_phi_fu_13246_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_483_V_read513_rewind_phi_fu_13246_p6 = data_483_V_read513_phi_reg_20340.read();
    } else {
        ap_phi_mux_data_483_V_read513_rewind_phi_fu_13246_p6 = data_483_V_read513_rewind_reg_13242.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_484_V_read514_phi_phi_fu_20356_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_484_V_read514_phi_phi_fu_20356_p4 = ap_phi_mux_data_484_V_read514_rewind_phi_fu_13260_p6.read();
    } else {
        ap_phi_mux_data_484_V_read514_phi_phi_fu_20356_p4 = ap_phi_reg_pp0_iter1_data_484_V_read514_phi_reg_20352.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_484_V_read514_rewind_phi_fu_13260_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_484_V_read514_rewind_phi_fu_13260_p6 = data_484_V_read514_phi_reg_20352.read();
    } else {
        ap_phi_mux_data_484_V_read514_rewind_phi_fu_13260_p6 = data_484_V_read514_rewind_reg_13256.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_485_V_read515_phi_phi_fu_20368_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_485_V_read515_phi_phi_fu_20368_p4 = ap_phi_mux_data_485_V_read515_rewind_phi_fu_13274_p6.read();
    } else {
        ap_phi_mux_data_485_V_read515_phi_phi_fu_20368_p4 = ap_phi_reg_pp0_iter1_data_485_V_read515_phi_reg_20364.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_485_V_read515_rewind_phi_fu_13274_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_485_V_read515_rewind_phi_fu_13274_p6 = data_485_V_read515_phi_reg_20364.read();
    } else {
        ap_phi_mux_data_485_V_read515_rewind_phi_fu_13274_p6 = data_485_V_read515_rewind_reg_13270.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_486_V_read516_phi_phi_fu_20380_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_486_V_read516_phi_phi_fu_20380_p4 = ap_phi_mux_data_486_V_read516_rewind_phi_fu_13288_p6.read();
    } else {
        ap_phi_mux_data_486_V_read516_phi_phi_fu_20380_p4 = ap_phi_reg_pp0_iter1_data_486_V_read516_phi_reg_20376.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_486_V_read516_rewind_phi_fu_13288_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_486_V_read516_rewind_phi_fu_13288_p6 = data_486_V_read516_phi_reg_20376.read();
    } else {
        ap_phi_mux_data_486_V_read516_rewind_phi_fu_13288_p6 = data_486_V_read516_rewind_reg_13284.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_487_V_read517_phi_phi_fu_20392_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_487_V_read517_phi_phi_fu_20392_p4 = ap_phi_mux_data_487_V_read517_rewind_phi_fu_13302_p6.read();
    } else {
        ap_phi_mux_data_487_V_read517_phi_phi_fu_20392_p4 = ap_phi_reg_pp0_iter1_data_487_V_read517_phi_reg_20388.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_487_V_read517_rewind_phi_fu_13302_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_487_V_read517_rewind_phi_fu_13302_p6 = data_487_V_read517_phi_reg_20388.read();
    } else {
        ap_phi_mux_data_487_V_read517_rewind_phi_fu_13302_p6 = data_487_V_read517_rewind_reg_13298.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_488_V_read518_phi_phi_fu_20404_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_488_V_read518_phi_phi_fu_20404_p4 = ap_phi_mux_data_488_V_read518_rewind_phi_fu_13316_p6.read();
    } else {
        ap_phi_mux_data_488_V_read518_phi_phi_fu_20404_p4 = ap_phi_reg_pp0_iter1_data_488_V_read518_phi_reg_20400.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_488_V_read518_rewind_phi_fu_13316_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_488_V_read518_rewind_phi_fu_13316_p6 = data_488_V_read518_phi_reg_20400.read();
    } else {
        ap_phi_mux_data_488_V_read518_rewind_phi_fu_13316_p6 = data_488_V_read518_rewind_reg_13312.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_489_V_read519_phi_phi_fu_20416_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_489_V_read519_phi_phi_fu_20416_p4 = ap_phi_mux_data_489_V_read519_rewind_phi_fu_13330_p6.read();
    } else {
        ap_phi_mux_data_489_V_read519_phi_phi_fu_20416_p4 = ap_phi_reg_pp0_iter1_data_489_V_read519_phi_reg_20412.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_489_V_read519_rewind_phi_fu_13330_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_489_V_read519_rewind_phi_fu_13330_p6 = data_489_V_read519_phi_reg_20412.read();
    } else {
        ap_phi_mux_data_489_V_read519_rewind_phi_fu_13330_p6 = data_489_V_read519_rewind_reg_13326.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_48_V_read78_phi_phi_fu_15124_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_48_V_read78_phi_phi_fu_15124_p4 = ap_phi_mux_data_48_V_read78_rewind_phi_fu_7156_p6.read();
    } else {
        ap_phi_mux_data_48_V_read78_phi_phi_fu_15124_p4 = ap_phi_reg_pp0_iter1_data_48_V_read78_phi_reg_15120.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_48_V_read78_rewind_phi_fu_7156_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_48_V_read78_rewind_phi_fu_7156_p6 = data_48_V_read78_phi_reg_15120.read();
    } else {
        ap_phi_mux_data_48_V_read78_rewind_phi_fu_7156_p6 = data_48_V_read78_rewind_reg_7152.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_490_V_read520_phi_phi_fu_20428_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_490_V_read520_phi_phi_fu_20428_p4 = ap_phi_mux_data_490_V_read520_rewind_phi_fu_13344_p6.read();
    } else {
        ap_phi_mux_data_490_V_read520_phi_phi_fu_20428_p4 = ap_phi_reg_pp0_iter1_data_490_V_read520_phi_reg_20424.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_490_V_read520_rewind_phi_fu_13344_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_490_V_read520_rewind_phi_fu_13344_p6 = data_490_V_read520_phi_reg_20424.read();
    } else {
        ap_phi_mux_data_490_V_read520_rewind_phi_fu_13344_p6 = data_490_V_read520_rewind_reg_13340.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_491_V_read521_phi_phi_fu_20440_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_491_V_read521_phi_phi_fu_20440_p4 = ap_phi_mux_data_491_V_read521_rewind_phi_fu_13358_p6.read();
    } else {
        ap_phi_mux_data_491_V_read521_phi_phi_fu_20440_p4 = ap_phi_reg_pp0_iter1_data_491_V_read521_phi_reg_20436.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_491_V_read521_rewind_phi_fu_13358_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_491_V_read521_rewind_phi_fu_13358_p6 = data_491_V_read521_phi_reg_20436.read();
    } else {
        ap_phi_mux_data_491_V_read521_rewind_phi_fu_13358_p6 = data_491_V_read521_rewind_reg_13354.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_492_V_read522_phi_phi_fu_20452_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_492_V_read522_phi_phi_fu_20452_p4 = ap_phi_mux_data_492_V_read522_rewind_phi_fu_13372_p6.read();
    } else {
        ap_phi_mux_data_492_V_read522_phi_phi_fu_20452_p4 = ap_phi_reg_pp0_iter1_data_492_V_read522_phi_reg_20448.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_492_V_read522_rewind_phi_fu_13372_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_492_V_read522_rewind_phi_fu_13372_p6 = data_492_V_read522_phi_reg_20448.read();
    } else {
        ap_phi_mux_data_492_V_read522_rewind_phi_fu_13372_p6 = data_492_V_read522_rewind_reg_13368.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_493_V_read523_phi_phi_fu_20464_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_493_V_read523_phi_phi_fu_20464_p4 = ap_phi_mux_data_493_V_read523_rewind_phi_fu_13386_p6.read();
    } else {
        ap_phi_mux_data_493_V_read523_phi_phi_fu_20464_p4 = ap_phi_reg_pp0_iter1_data_493_V_read523_phi_reg_20460.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_493_V_read523_rewind_phi_fu_13386_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_493_V_read523_rewind_phi_fu_13386_p6 = data_493_V_read523_phi_reg_20460.read();
    } else {
        ap_phi_mux_data_493_V_read523_rewind_phi_fu_13386_p6 = data_493_V_read523_rewind_reg_13382.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_494_V_read524_phi_phi_fu_20476_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_494_V_read524_phi_phi_fu_20476_p4 = ap_phi_mux_data_494_V_read524_rewind_phi_fu_13400_p6.read();
    } else {
        ap_phi_mux_data_494_V_read524_phi_phi_fu_20476_p4 = ap_phi_reg_pp0_iter1_data_494_V_read524_phi_reg_20472.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_494_V_read524_rewind_phi_fu_13400_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_494_V_read524_rewind_phi_fu_13400_p6 = data_494_V_read524_phi_reg_20472.read();
    } else {
        ap_phi_mux_data_494_V_read524_rewind_phi_fu_13400_p6 = data_494_V_read524_rewind_reg_13396.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_495_V_read525_phi_phi_fu_20488_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_495_V_read525_phi_phi_fu_20488_p4 = ap_phi_mux_data_495_V_read525_rewind_phi_fu_13414_p6.read();
    } else {
        ap_phi_mux_data_495_V_read525_phi_phi_fu_20488_p4 = ap_phi_reg_pp0_iter1_data_495_V_read525_phi_reg_20484.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_495_V_read525_rewind_phi_fu_13414_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_495_V_read525_rewind_phi_fu_13414_p6 = data_495_V_read525_phi_reg_20484.read();
    } else {
        ap_phi_mux_data_495_V_read525_rewind_phi_fu_13414_p6 = data_495_V_read525_rewind_reg_13410.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_496_V_read526_phi_phi_fu_20500_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_496_V_read526_phi_phi_fu_20500_p4 = ap_phi_mux_data_496_V_read526_rewind_phi_fu_13428_p6.read();
    } else {
        ap_phi_mux_data_496_V_read526_phi_phi_fu_20500_p4 = ap_phi_reg_pp0_iter1_data_496_V_read526_phi_reg_20496.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_496_V_read526_rewind_phi_fu_13428_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_496_V_read526_rewind_phi_fu_13428_p6 = data_496_V_read526_phi_reg_20496.read();
    } else {
        ap_phi_mux_data_496_V_read526_rewind_phi_fu_13428_p6 = data_496_V_read526_rewind_reg_13424.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_497_V_read527_phi_phi_fu_20512_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_497_V_read527_phi_phi_fu_20512_p4 = ap_phi_mux_data_497_V_read527_rewind_phi_fu_13442_p6.read();
    } else {
        ap_phi_mux_data_497_V_read527_phi_phi_fu_20512_p4 = ap_phi_reg_pp0_iter1_data_497_V_read527_phi_reg_20508.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_497_V_read527_rewind_phi_fu_13442_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_497_V_read527_rewind_phi_fu_13442_p6 = data_497_V_read527_phi_reg_20508.read();
    } else {
        ap_phi_mux_data_497_V_read527_rewind_phi_fu_13442_p6 = data_497_V_read527_rewind_reg_13438.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_498_V_read528_phi_phi_fu_20524_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_498_V_read528_phi_phi_fu_20524_p4 = ap_phi_mux_data_498_V_read528_rewind_phi_fu_13456_p6.read();
    } else {
        ap_phi_mux_data_498_V_read528_phi_phi_fu_20524_p4 = ap_phi_reg_pp0_iter1_data_498_V_read528_phi_reg_20520.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_498_V_read528_rewind_phi_fu_13456_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_498_V_read528_rewind_phi_fu_13456_p6 = data_498_V_read528_phi_reg_20520.read();
    } else {
        ap_phi_mux_data_498_V_read528_rewind_phi_fu_13456_p6 = data_498_V_read528_rewind_reg_13452.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_499_V_read529_phi_phi_fu_20536_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_499_V_read529_phi_phi_fu_20536_p4 = ap_phi_mux_data_499_V_read529_rewind_phi_fu_13470_p6.read();
    } else {
        ap_phi_mux_data_499_V_read529_phi_phi_fu_20536_p4 = ap_phi_reg_pp0_iter1_data_499_V_read529_phi_reg_20532.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_499_V_read529_rewind_phi_fu_13470_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_499_V_read529_rewind_phi_fu_13470_p6 = data_499_V_read529_phi_reg_20532.read();
    } else {
        ap_phi_mux_data_499_V_read529_rewind_phi_fu_13470_p6 = data_499_V_read529_rewind_reg_13466.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_49_V_read79_phi_phi_fu_15136_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_49_V_read79_phi_phi_fu_15136_p4 = ap_phi_mux_data_49_V_read79_rewind_phi_fu_7170_p6.read();
    } else {
        ap_phi_mux_data_49_V_read79_phi_phi_fu_15136_p4 = ap_phi_reg_pp0_iter1_data_49_V_read79_phi_reg_15132.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_49_V_read79_rewind_phi_fu_7170_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_49_V_read79_rewind_phi_fu_7170_p6 = data_49_V_read79_phi_reg_15132.read();
    } else {
        ap_phi_mux_data_49_V_read79_rewind_phi_fu_7170_p6 = data_49_V_read79_rewind_reg_7166.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_4_V_read34_phi_phi_fu_14596_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_4_V_read34_phi_phi_fu_14596_p4 = ap_phi_mux_data_4_V_read34_rewind_phi_fu_6540_p6.read();
    } else {
        ap_phi_mux_data_4_V_read34_phi_phi_fu_14596_p4 = ap_phi_reg_pp0_iter1_data_4_V_read34_phi_reg_14592.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_4_V_read34_rewind_phi_fu_6540_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_4_V_read34_rewind_phi_fu_6540_p6 = data_4_V_read34_phi_reg_14592.read();
    } else {
        ap_phi_mux_data_4_V_read34_rewind_phi_fu_6540_p6 = data_4_V_read34_rewind_reg_6536.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_500_V_read530_phi_phi_fu_20548_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_500_V_read530_phi_phi_fu_20548_p4 = ap_phi_mux_data_500_V_read530_rewind_phi_fu_13484_p6.read();
    } else {
        ap_phi_mux_data_500_V_read530_phi_phi_fu_20548_p4 = ap_phi_reg_pp0_iter1_data_500_V_read530_phi_reg_20544.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_500_V_read530_rewind_phi_fu_13484_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_500_V_read530_rewind_phi_fu_13484_p6 = data_500_V_read530_phi_reg_20544.read();
    } else {
        ap_phi_mux_data_500_V_read530_rewind_phi_fu_13484_p6 = data_500_V_read530_rewind_reg_13480.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_501_V_read531_phi_phi_fu_20560_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_501_V_read531_phi_phi_fu_20560_p4 = ap_phi_mux_data_501_V_read531_rewind_phi_fu_13498_p6.read();
    } else {
        ap_phi_mux_data_501_V_read531_phi_phi_fu_20560_p4 = ap_phi_reg_pp0_iter1_data_501_V_read531_phi_reg_20556.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_501_V_read531_rewind_phi_fu_13498_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_501_V_read531_rewind_phi_fu_13498_p6 = data_501_V_read531_phi_reg_20556.read();
    } else {
        ap_phi_mux_data_501_V_read531_rewind_phi_fu_13498_p6 = data_501_V_read531_rewind_reg_13494.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_502_V_read532_phi_phi_fu_20572_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_502_V_read532_phi_phi_fu_20572_p4 = ap_phi_mux_data_502_V_read532_rewind_phi_fu_13512_p6.read();
    } else {
        ap_phi_mux_data_502_V_read532_phi_phi_fu_20572_p4 = ap_phi_reg_pp0_iter1_data_502_V_read532_phi_reg_20568.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_502_V_read532_rewind_phi_fu_13512_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_502_V_read532_rewind_phi_fu_13512_p6 = data_502_V_read532_phi_reg_20568.read();
    } else {
        ap_phi_mux_data_502_V_read532_rewind_phi_fu_13512_p6 = data_502_V_read532_rewind_reg_13508.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_503_V_read533_phi_phi_fu_20584_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_503_V_read533_phi_phi_fu_20584_p4 = ap_phi_mux_data_503_V_read533_rewind_phi_fu_13526_p6.read();
    } else {
        ap_phi_mux_data_503_V_read533_phi_phi_fu_20584_p4 = ap_phi_reg_pp0_iter1_data_503_V_read533_phi_reg_20580.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_503_V_read533_rewind_phi_fu_13526_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_503_V_read533_rewind_phi_fu_13526_p6 = data_503_V_read533_phi_reg_20580.read();
    } else {
        ap_phi_mux_data_503_V_read533_rewind_phi_fu_13526_p6 = data_503_V_read533_rewind_reg_13522.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_504_V_read534_phi_phi_fu_20596_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_504_V_read534_phi_phi_fu_20596_p4 = ap_phi_mux_data_504_V_read534_rewind_phi_fu_13540_p6.read();
    } else {
        ap_phi_mux_data_504_V_read534_phi_phi_fu_20596_p4 = ap_phi_reg_pp0_iter1_data_504_V_read534_phi_reg_20592.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_504_V_read534_rewind_phi_fu_13540_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_504_V_read534_rewind_phi_fu_13540_p6 = data_504_V_read534_phi_reg_20592.read();
    } else {
        ap_phi_mux_data_504_V_read534_rewind_phi_fu_13540_p6 = data_504_V_read534_rewind_reg_13536.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_505_V_read535_phi_phi_fu_20608_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_505_V_read535_phi_phi_fu_20608_p4 = ap_phi_mux_data_505_V_read535_rewind_phi_fu_13554_p6.read();
    } else {
        ap_phi_mux_data_505_V_read535_phi_phi_fu_20608_p4 = ap_phi_reg_pp0_iter1_data_505_V_read535_phi_reg_20604.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_505_V_read535_rewind_phi_fu_13554_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_505_V_read535_rewind_phi_fu_13554_p6 = data_505_V_read535_phi_reg_20604.read();
    } else {
        ap_phi_mux_data_505_V_read535_rewind_phi_fu_13554_p6 = data_505_V_read535_rewind_reg_13550.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_506_V_read536_phi_phi_fu_20620_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_506_V_read536_phi_phi_fu_20620_p4 = ap_phi_mux_data_506_V_read536_rewind_phi_fu_13568_p6.read();
    } else {
        ap_phi_mux_data_506_V_read536_phi_phi_fu_20620_p4 = ap_phi_reg_pp0_iter1_data_506_V_read536_phi_reg_20616.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_506_V_read536_rewind_phi_fu_13568_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_506_V_read536_rewind_phi_fu_13568_p6 = data_506_V_read536_phi_reg_20616.read();
    } else {
        ap_phi_mux_data_506_V_read536_rewind_phi_fu_13568_p6 = data_506_V_read536_rewind_reg_13564.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_507_V_read537_phi_phi_fu_20632_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_507_V_read537_phi_phi_fu_20632_p4 = ap_phi_mux_data_507_V_read537_rewind_phi_fu_13582_p6.read();
    } else {
        ap_phi_mux_data_507_V_read537_phi_phi_fu_20632_p4 = ap_phi_reg_pp0_iter1_data_507_V_read537_phi_reg_20628.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_507_V_read537_rewind_phi_fu_13582_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_507_V_read537_rewind_phi_fu_13582_p6 = data_507_V_read537_phi_reg_20628.read();
    } else {
        ap_phi_mux_data_507_V_read537_rewind_phi_fu_13582_p6 = data_507_V_read537_rewind_reg_13578.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_508_V_read538_phi_phi_fu_20644_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_508_V_read538_phi_phi_fu_20644_p4 = ap_phi_mux_data_508_V_read538_rewind_phi_fu_13596_p6.read();
    } else {
        ap_phi_mux_data_508_V_read538_phi_phi_fu_20644_p4 = ap_phi_reg_pp0_iter1_data_508_V_read538_phi_reg_20640.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_508_V_read538_rewind_phi_fu_13596_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_508_V_read538_rewind_phi_fu_13596_p6 = data_508_V_read538_phi_reg_20640.read();
    } else {
        ap_phi_mux_data_508_V_read538_rewind_phi_fu_13596_p6 = data_508_V_read538_rewind_reg_13592.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_509_V_read539_phi_phi_fu_20656_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_509_V_read539_phi_phi_fu_20656_p4 = ap_phi_mux_data_509_V_read539_rewind_phi_fu_13610_p6.read();
    } else {
        ap_phi_mux_data_509_V_read539_phi_phi_fu_20656_p4 = ap_phi_reg_pp0_iter1_data_509_V_read539_phi_reg_20652.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_509_V_read539_rewind_phi_fu_13610_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_509_V_read539_rewind_phi_fu_13610_p6 = data_509_V_read539_phi_reg_20652.read();
    } else {
        ap_phi_mux_data_509_V_read539_rewind_phi_fu_13610_p6 = data_509_V_read539_rewind_reg_13606.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_50_V_read80_phi_phi_fu_15148_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_50_V_read80_phi_phi_fu_15148_p4 = ap_phi_mux_data_50_V_read80_rewind_phi_fu_7184_p6.read();
    } else {
        ap_phi_mux_data_50_V_read80_phi_phi_fu_15148_p4 = ap_phi_reg_pp0_iter1_data_50_V_read80_phi_reg_15144.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_50_V_read80_rewind_phi_fu_7184_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_50_V_read80_rewind_phi_fu_7184_p6 = data_50_V_read80_phi_reg_15144.read();
    } else {
        ap_phi_mux_data_50_V_read80_rewind_phi_fu_7184_p6 = data_50_V_read80_rewind_reg_7180.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_510_V_read540_phi_phi_fu_20668_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_510_V_read540_phi_phi_fu_20668_p4 = ap_phi_mux_data_510_V_read540_rewind_phi_fu_13624_p6.read();
    } else {
        ap_phi_mux_data_510_V_read540_phi_phi_fu_20668_p4 = ap_phi_reg_pp0_iter1_data_510_V_read540_phi_reg_20664.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_510_V_read540_rewind_phi_fu_13624_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_510_V_read540_rewind_phi_fu_13624_p6 = data_510_V_read540_phi_reg_20664.read();
    } else {
        ap_phi_mux_data_510_V_read540_rewind_phi_fu_13624_p6 = data_510_V_read540_rewind_reg_13620.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_511_V_read541_phi_phi_fu_20680_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_511_V_read541_phi_phi_fu_20680_p4 = ap_phi_mux_data_511_V_read541_rewind_phi_fu_13638_p6.read();
    } else {
        ap_phi_mux_data_511_V_read541_phi_phi_fu_20680_p4 = ap_phi_reg_pp0_iter1_data_511_V_read541_phi_reg_20676.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_511_V_read541_rewind_phi_fu_13638_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_511_V_read541_rewind_phi_fu_13638_p6 = data_511_V_read541_phi_reg_20676.read();
    } else {
        ap_phi_mux_data_511_V_read541_rewind_phi_fu_13638_p6 = data_511_V_read541_rewind_reg_13634.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_512_V_read542_phi_phi_fu_20692_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_512_V_read542_phi_phi_fu_20692_p4 = ap_phi_mux_data_512_V_read542_rewind_phi_fu_13652_p6.read();
    } else {
        ap_phi_mux_data_512_V_read542_phi_phi_fu_20692_p4 = ap_phi_reg_pp0_iter1_data_512_V_read542_phi_reg_20688.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_512_V_read542_rewind_phi_fu_13652_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_512_V_read542_rewind_phi_fu_13652_p6 = data_512_V_read542_phi_reg_20688.read();
    } else {
        ap_phi_mux_data_512_V_read542_rewind_phi_fu_13652_p6 = data_512_V_read542_rewind_reg_13648.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_513_V_read543_phi_phi_fu_20704_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_513_V_read543_phi_phi_fu_20704_p4 = ap_phi_mux_data_513_V_read543_rewind_phi_fu_13666_p6.read();
    } else {
        ap_phi_mux_data_513_V_read543_phi_phi_fu_20704_p4 = ap_phi_reg_pp0_iter1_data_513_V_read543_phi_reg_20700.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_513_V_read543_rewind_phi_fu_13666_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_513_V_read543_rewind_phi_fu_13666_p6 = data_513_V_read543_phi_reg_20700.read();
    } else {
        ap_phi_mux_data_513_V_read543_rewind_phi_fu_13666_p6 = data_513_V_read543_rewind_reg_13662.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_514_V_read544_phi_phi_fu_20716_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_514_V_read544_phi_phi_fu_20716_p4 = ap_phi_mux_data_514_V_read544_rewind_phi_fu_13680_p6.read();
    } else {
        ap_phi_mux_data_514_V_read544_phi_phi_fu_20716_p4 = ap_phi_reg_pp0_iter1_data_514_V_read544_phi_reg_20712.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_514_V_read544_rewind_phi_fu_13680_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_514_V_read544_rewind_phi_fu_13680_p6 = data_514_V_read544_phi_reg_20712.read();
    } else {
        ap_phi_mux_data_514_V_read544_rewind_phi_fu_13680_p6 = data_514_V_read544_rewind_reg_13676.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_515_V_read545_phi_phi_fu_20728_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_515_V_read545_phi_phi_fu_20728_p4 = ap_phi_mux_data_515_V_read545_rewind_phi_fu_13694_p6.read();
    } else {
        ap_phi_mux_data_515_V_read545_phi_phi_fu_20728_p4 = ap_phi_reg_pp0_iter1_data_515_V_read545_phi_reg_20724.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_515_V_read545_rewind_phi_fu_13694_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_515_V_read545_rewind_phi_fu_13694_p6 = data_515_V_read545_phi_reg_20724.read();
    } else {
        ap_phi_mux_data_515_V_read545_rewind_phi_fu_13694_p6 = data_515_V_read545_rewind_reg_13690.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_516_V_read546_phi_phi_fu_20740_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_516_V_read546_phi_phi_fu_20740_p4 = ap_phi_mux_data_516_V_read546_rewind_phi_fu_13708_p6.read();
    } else {
        ap_phi_mux_data_516_V_read546_phi_phi_fu_20740_p4 = ap_phi_reg_pp0_iter1_data_516_V_read546_phi_reg_20736.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_516_V_read546_rewind_phi_fu_13708_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_516_V_read546_rewind_phi_fu_13708_p6 = data_516_V_read546_phi_reg_20736.read();
    } else {
        ap_phi_mux_data_516_V_read546_rewind_phi_fu_13708_p6 = data_516_V_read546_rewind_reg_13704.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_517_V_read547_phi_phi_fu_20752_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_517_V_read547_phi_phi_fu_20752_p4 = ap_phi_mux_data_517_V_read547_rewind_phi_fu_13722_p6.read();
    } else {
        ap_phi_mux_data_517_V_read547_phi_phi_fu_20752_p4 = ap_phi_reg_pp0_iter1_data_517_V_read547_phi_reg_20748.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_517_V_read547_rewind_phi_fu_13722_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_517_V_read547_rewind_phi_fu_13722_p6 = data_517_V_read547_phi_reg_20748.read();
    } else {
        ap_phi_mux_data_517_V_read547_rewind_phi_fu_13722_p6 = data_517_V_read547_rewind_reg_13718.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_518_V_read548_phi_phi_fu_20764_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_518_V_read548_phi_phi_fu_20764_p4 = ap_phi_mux_data_518_V_read548_rewind_phi_fu_13736_p6.read();
    } else {
        ap_phi_mux_data_518_V_read548_phi_phi_fu_20764_p4 = ap_phi_reg_pp0_iter1_data_518_V_read548_phi_reg_20760.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_518_V_read548_rewind_phi_fu_13736_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_518_V_read548_rewind_phi_fu_13736_p6 = data_518_V_read548_phi_reg_20760.read();
    } else {
        ap_phi_mux_data_518_V_read548_rewind_phi_fu_13736_p6 = data_518_V_read548_rewind_reg_13732.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_519_V_read549_phi_phi_fu_20776_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_519_V_read549_phi_phi_fu_20776_p4 = ap_phi_mux_data_519_V_read549_rewind_phi_fu_13750_p6.read();
    } else {
        ap_phi_mux_data_519_V_read549_phi_phi_fu_20776_p4 = ap_phi_reg_pp0_iter1_data_519_V_read549_phi_reg_20772.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_519_V_read549_rewind_phi_fu_13750_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_519_V_read549_rewind_phi_fu_13750_p6 = data_519_V_read549_phi_reg_20772.read();
    } else {
        ap_phi_mux_data_519_V_read549_rewind_phi_fu_13750_p6 = data_519_V_read549_rewind_reg_13746.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_51_V_read81_phi_phi_fu_15160_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_51_V_read81_phi_phi_fu_15160_p4 = ap_phi_mux_data_51_V_read81_rewind_phi_fu_7198_p6.read();
    } else {
        ap_phi_mux_data_51_V_read81_phi_phi_fu_15160_p4 = ap_phi_reg_pp0_iter1_data_51_V_read81_phi_reg_15156.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_51_V_read81_rewind_phi_fu_7198_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_51_V_read81_rewind_phi_fu_7198_p6 = data_51_V_read81_phi_reg_15156.read();
    } else {
        ap_phi_mux_data_51_V_read81_rewind_phi_fu_7198_p6 = data_51_V_read81_rewind_reg_7194.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_520_V_read550_phi_phi_fu_20788_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_520_V_read550_phi_phi_fu_20788_p4 = ap_phi_mux_data_520_V_read550_rewind_phi_fu_13764_p6.read();
    } else {
        ap_phi_mux_data_520_V_read550_phi_phi_fu_20788_p4 = ap_phi_reg_pp0_iter1_data_520_V_read550_phi_reg_20784.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_520_V_read550_rewind_phi_fu_13764_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_520_V_read550_rewind_phi_fu_13764_p6 = data_520_V_read550_phi_reg_20784.read();
    } else {
        ap_phi_mux_data_520_V_read550_rewind_phi_fu_13764_p6 = data_520_V_read550_rewind_reg_13760.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_521_V_read551_phi_phi_fu_20800_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_521_V_read551_phi_phi_fu_20800_p4 = ap_phi_mux_data_521_V_read551_rewind_phi_fu_13778_p6.read();
    } else {
        ap_phi_mux_data_521_V_read551_phi_phi_fu_20800_p4 = ap_phi_reg_pp0_iter1_data_521_V_read551_phi_reg_20796.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_521_V_read551_rewind_phi_fu_13778_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_521_V_read551_rewind_phi_fu_13778_p6 = data_521_V_read551_phi_reg_20796.read();
    } else {
        ap_phi_mux_data_521_V_read551_rewind_phi_fu_13778_p6 = data_521_V_read551_rewind_reg_13774.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_522_V_read552_phi_phi_fu_20812_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_522_V_read552_phi_phi_fu_20812_p4 = ap_phi_mux_data_522_V_read552_rewind_phi_fu_13792_p6.read();
    } else {
        ap_phi_mux_data_522_V_read552_phi_phi_fu_20812_p4 = ap_phi_reg_pp0_iter1_data_522_V_read552_phi_reg_20808.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_522_V_read552_rewind_phi_fu_13792_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_522_V_read552_rewind_phi_fu_13792_p6 = data_522_V_read552_phi_reg_20808.read();
    } else {
        ap_phi_mux_data_522_V_read552_rewind_phi_fu_13792_p6 = data_522_V_read552_rewind_reg_13788.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_523_V_read553_phi_phi_fu_20824_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_523_V_read553_phi_phi_fu_20824_p4 = ap_phi_mux_data_523_V_read553_rewind_phi_fu_13806_p6.read();
    } else {
        ap_phi_mux_data_523_V_read553_phi_phi_fu_20824_p4 = ap_phi_reg_pp0_iter1_data_523_V_read553_phi_reg_20820.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_523_V_read553_rewind_phi_fu_13806_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_523_V_read553_rewind_phi_fu_13806_p6 = data_523_V_read553_phi_reg_20820.read();
    } else {
        ap_phi_mux_data_523_V_read553_rewind_phi_fu_13806_p6 = data_523_V_read553_rewind_reg_13802.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_524_V_read554_phi_phi_fu_20836_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_524_V_read554_phi_phi_fu_20836_p4 = ap_phi_mux_data_524_V_read554_rewind_phi_fu_13820_p6.read();
    } else {
        ap_phi_mux_data_524_V_read554_phi_phi_fu_20836_p4 = ap_phi_reg_pp0_iter1_data_524_V_read554_phi_reg_20832.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_524_V_read554_rewind_phi_fu_13820_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_524_V_read554_rewind_phi_fu_13820_p6 = data_524_V_read554_phi_reg_20832.read();
    } else {
        ap_phi_mux_data_524_V_read554_rewind_phi_fu_13820_p6 = data_524_V_read554_rewind_reg_13816.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_525_V_read555_phi_phi_fu_20848_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_525_V_read555_phi_phi_fu_20848_p4 = ap_phi_mux_data_525_V_read555_rewind_phi_fu_13834_p6.read();
    } else {
        ap_phi_mux_data_525_V_read555_phi_phi_fu_20848_p4 = ap_phi_reg_pp0_iter1_data_525_V_read555_phi_reg_20844.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_525_V_read555_rewind_phi_fu_13834_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_525_V_read555_rewind_phi_fu_13834_p6 = data_525_V_read555_phi_reg_20844.read();
    } else {
        ap_phi_mux_data_525_V_read555_rewind_phi_fu_13834_p6 = data_525_V_read555_rewind_reg_13830.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_526_V_read556_phi_phi_fu_20860_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_526_V_read556_phi_phi_fu_20860_p4 = ap_phi_mux_data_526_V_read556_rewind_phi_fu_13848_p6.read();
    } else {
        ap_phi_mux_data_526_V_read556_phi_phi_fu_20860_p4 = ap_phi_reg_pp0_iter1_data_526_V_read556_phi_reg_20856.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_526_V_read556_rewind_phi_fu_13848_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_526_V_read556_rewind_phi_fu_13848_p6 = data_526_V_read556_phi_reg_20856.read();
    } else {
        ap_phi_mux_data_526_V_read556_rewind_phi_fu_13848_p6 = data_526_V_read556_rewind_reg_13844.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_527_V_read557_phi_phi_fu_20872_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_527_V_read557_phi_phi_fu_20872_p4 = ap_phi_mux_data_527_V_read557_rewind_phi_fu_13862_p6.read();
    } else {
        ap_phi_mux_data_527_V_read557_phi_phi_fu_20872_p4 = ap_phi_reg_pp0_iter1_data_527_V_read557_phi_reg_20868.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_527_V_read557_rewind_phi_fu_13862_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_527_V_read557_rewind_phi_fu_13862_p6 = data_527_V_read557_phi_reg_20868.read();
    } else {
        ap_phi_mux_data_527_V_read557_rewind_phi_fu_13862_p6 = data_527_V_read557_rewind_reg_13858.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_528_V_read558_phi_phi_fu_20884_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_528_V_read558_phi_phi_fu_20884_p4 = ap_phi_mux_data_528_V_read558_rewind_phi_fu_13876_p6.read();
    } else {
        ap_phi_mux_data_528_V_read558_phi_phi_fu_20884_p4 = ap_phi_reg_pp0_iter1_data_528_V_read558_phi_reg_20880.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_528_V_read558_rewind_phi_fu_13876_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_528_V_read558_rewind_phi_fu_13876_p6 = data_528_V_read558_phi_reg_20880.read();
    } else {
        ap_phi_mux_data_528_V_read558_rewind_phi_fu_13876_p6 = data_528_V_read558_rewind_reg_13872.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_529_V_read559_phi_phi_fu_20896_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_529_V_read559_phi_phi_fu_20896_p4 = ap_phi_mux_data_529_V_read559_rewind_phi_fu_13890_p6.read();
    } else {
        ap_phi_mux_data_529_V_read559_phi_phi_fu_20896_p4 = ap_phi_reg_pp0_iter1_data_529_V_read559_phi_reg_20892.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_529_V_read559_rewind_phi_fu_13890_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_529_V_read559_rewind_phi_fu_13890_p6 = data_529_V_read559_phi_reg_20892.read();
    } else {
        ap_phi_mux_data_529_V_read559_rewind_phi_fu_13890_p6 = data_529_V_read559_rewind_reg_13886.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_52_V_read82_phi_phi_fu_15172_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_52_V_read82_phi_phi_fu_15172_p4 = ap_phi_mux_data_52_V_read82_rewind_phi_fu_7212_p6.read();
    } else {
        ap_phi_mux_data_52_V_read82_phi_phi_fu_15172_p4 = ap_phi_reg_pp0_iter1_data_52_V_read82_phi_reg_15168.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_52_V_read82_rewind_phi_fu_7212_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_52_V_read82_rewind_phi_fu_7212_p6 = data_52_V_read82_phi_reg_15168.read();
    } else {
        ap_phi_mux_data_52_V_read82_rewind_phi_fu_7212_p6 = data_52_V_read82_rewind_reg_7208.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_530_V_read560_phi_phi_fu_20908_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_530_V_read560_phi_phi_fu_20908_p4 = ap_phi_mux_data_530_V_read560_rewind_phi_fu_13904_p6.read();
    } else {
        ap_phi_mux_data_530_V_read560_phi_phi_fu_20908_p4 = ap_phi_reg_pp0_iter1_data_530_V_read560_phi_reg_20904.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_530_V_read560_rewind_phi_fu_13904_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_530_V_read560_rewind_phi_fu_13904_p6 = data_530_V_read560_phi_reg_20904.read();
    } else {
        ap_phi_mux_data_530_V_read560_rewind_phi_fu_13904_p6 = data_530_V_read560_rewind_reg_13900.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_531_V_read561_phi_phi_fu_20920_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_531_V_read561_phi_phi_fu_20920_p4 = ap_phi_mux_data_531_V_read561_rewind_phi_fu_13918_p6.read();
    } else {
        ap_phi_mux_data_531_V_read561_phi_phi_fu_20920_p4 = ap_phi_reg_pp0_iter1_data_531_V_read561_phi_reg_20916.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_531_V_read561_rewind_phi_fu_13918_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_531_V_read561_rewind_phi_fu_13918_p6 = data_531_V_read561_phi_reg_20916.read();
    } else {
        ap_phi_mux_data_531_V_read561_rewind_phi_fu_13918_p6 = data_531_V_read561_rewind_reg_13914.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_532_V_read562_phi_phi_fu_20932_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_532_V_read562_phi_phi_fu_20932_p4 = ap_phi_mux_data_532_V_read562_rewind_phi_fu_13932_p6.read();
    } else {
        ap_phi_mux_data_532_V_read562_phi_phi_fu_20932_p4 = ap_phi_reg_pp0_iter1_data_532_V_read562_phi_reg_20928.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_532_V_read562_rewind_phi_fu_13932_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_532_V_read562_rewind_phi_fu_13932_p6 = data_532_V_read562_phi_reg_20928.read();
    } else {
        ap_phi_mux_data_532_V_read562_rewind_phi_fu_13932_p6 = data_532_V_read562_rewind_reg_13928.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_533_V_read563_phi_phi_fu_20944_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_533_V_read563_phi_phi_fu_20944_p4 = ap_phi_mux_data_533_V_read563_rewind_phi_fu_13946_p6.read();
    } else {
        ap_phi_mux_data_533_V_read563_phi_phi_fu_20944_p4 = ap_phi_reg_pp0_iter1_data_533_V_read563_phi_reg_20940.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_533_V_read563_rewind_phi_fu_13946_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_533_V_read563_rewind_phi_fu_13946_p6 = data_533_V_read563_phi_reg_20940.read();
    } else {
        ap_phi_mux_data_533_V_read563_rewind_phi_fu_13946_p6 = data_533_V_read563_rewind_reg_13942.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_534_V_read564_phi_phi_fu_20956_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_534_V_read564_phi_phi_fu_20956_p4 = ap_phi_mux_data_534_V_read564_rewind_phi_fu_13960_p6.read();
    } else {
        ap_phi_mux_data_534_V_read564_phi_phi_fu_20956_p4 = ap_phi_reg_pp0_iter1_data_534_V_read564_phi_reg_20952.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_534_V_read564_rewind_phi_fu_13960_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_534_V_read564_rewind_phi_fu_13960_p6 = data_534_V_read564_phi_reg_20952.read();
    } else {
        ap_phi_mux_data_534_V_read564_rewind_phi_fu_13960_p6 = data_534_V_read564_rewind_reg_13956.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_535_V_read565_phi_phi_fu_20968_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_535_V_read565_phi_phi_fu_20968_p4 = ap_phi_mux_data_535_V_read565_rewind_phi_fu_13974_p6.read();
    } else {
        ap_phi_mux_data_535_V_read565_phi_phi_fu_20968_p4 = ap_phi_reg_pp0_iter1_data_535_V_read565_phi_reg_20964.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_535_V_read565_rewind_phi_fu_13974_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_535_V_read565_rewind_phi_fu_13974_p6 = data_535_V_read565_phi_reg_20964.read();
    } else {
        ap_phi_mux_data_535_V_read565_rewind_phi_fu_13974_p6 = data_535_V_read565_rewind_reg_13970.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_536_V_read566_phi_phi_fu_20980_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_536_V_read566_phi_phi_fu_20980_p4 = ap_phi_mux_data_536_V_read566_rewind_phi_fu_13988_p6.read();
    } else {
        ap_phi_mux_data_536_V_read566_phi_phi_fu_20980_p4 = ap_phi_reg_pp0_iter1_data_536_V_read566_phi_reg_20976.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_536_V_read566_rewind_phi_fu_13988_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_536_V_read566_rewind_phi_fu_13988_p6 = data_536_V_read566_phi_reg_20976.read();
    } else {
        ap_phi_mux_data_536_V_read566_rewind_phi_fu_13988_p6 = data_536_V_read566_rewind_reg_13984.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_537_V_read567_phi_phi_fu_20992_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_537_V_read567_phi_phi_fu_20992_p4 = ap_phi_mux_data_537_V_read567_rewind_phi_fu_14002_p6.read();
    } else {
        ap_phi_mux_data_537_V_read567_phi_phi_fu_20992_p4 = ap_phi_reg_pp0_iter1_data_537_V_read567_phi_reg_20988.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_537_V_read567_rewind_phi_fu_14002_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_537_V_read567_rewind_phi_fu_14002_p6 = data_537_V_read567_phi_reg_20988.read();
    } else {
        ap_phi_mux_data_537_V_read567_rewind_phi_fu_14002_p6 = data_537_V_read567_rewind_reg_13998.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_538_V_read568_phi_phi_fu_21004_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_538_V_read568_phi_phi_fu_21004_p4 = ap_phi_mux_data_538_V_read568_rewind_phi_fu_14016_p6.read();
    } else {
        ap_phi_mux_data_538_V_read568_phi_phi_fu_21004_p4 = ap_phi_reg_pp0_iter1_data_538_V_read568_phi_reg_21000.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_538_V_read568_rewind_phi_fu_14016_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_538_V_read568_rewind_phi_fu_14016_p6 = data_538_V_read568_phi_reg_21000.read();
    } else {
        ap_phi_mux_data_538_V_read568_rewind_phi_fu_14016_p6 = data_538_V_read568_rewind_reg_14012.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_539_V_read569_phi_phi_fu_21016_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_539_V_read569_phi_phi_fu_21016_p4 = ap_phi_mux_data_539_V_read569_rewind_phi_fu_14030_p6.read();
    } else {
        ap_phi_mux_data_539_V_read569_phi_phi_fu_21016_p4 = ap_phi_reg_pp0_iter1_data_539_V_read569_phi_reg_21012.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_539_V_read569_rewind_phi_fu_14030_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_539_V_read569_rewind_phi_fu_14030_p6 = data_539_V_read569_phi_reg_21012.read();
    } else {
        ap_phi_mux_data_539_V_read569_rewind_phi_fu_14030_p6 = data_539_V_read569_rewind_reg_14026.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_53_V_read83_phi_phi_fu_15184_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_53_V_read83_phi_phi_fu_15184_p4 = ap_phi_mux_data_53_V_read83_rewind_phi_fu_7226_p6.read();
    } else {
        ap_phi_mux_data_53_V_read83_phi_phi_fu_15184_p4 = ap_phi_reg_pp0_iter1_data_53_V_read83_phi_reg_15180.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_53_V_read83_rewind_phi_fu_7226_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_53_V_read83_rewind_phi_fu_7226_p6 = data_53_V_read83_phi_reg_15180.read();
    } else {
        ap_phi_mux_data_53_V_read83_rewind_phi_fu_7226_p6 = data_53_V_read83_rewind_reg_7222.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_540_V_read570_phi_phi_fu_21028_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_540_V_read570_phi_phi_fu_21028_p4 = ap_phi_mux_data_540_V_read570_rewind_phi_fu_14044_p6.read();
    } else {
        ap_phi_mux_data_540_V_read570_phi_phi_fu_21028_p4 = ap_phi_reg_pp0_iter1_data_540_V_read570_phi_reg_21024.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_540_V_read570_rewind_phi_fu_14044_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_540_V_read570_rewind_phi_fu_14044_p6 = data_540_V_read570_phi_reg_21024.read();
    } else {
        ap_phi_mux_data_540_V_read570_rewind_phi_fu_14044_p6 = data_540_V_read570_rewind_reg_14040.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_541_V_read571_phi_phi_fu_21040_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_541_V_read571_phi_phi_fu_21040_p4 = ap_phi_mux_data_541_V_read571_rewind_phi_fu_14058_p6.read();
    } else {
        ap_phi_mux_data_541_V_read571_phi_phi_fu_21040_p4 = ap_phi_reg_pp0_iter1_data_541_V_read571_phi_reg_21036.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_541_V_read571_rewind_phi_fu_14058_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_541_V_read571_rewind_phi_fu_14058_p6 = data_541_V_read571_phi_reg_21036.read();
    } else {
        ap_phi_mux_data_541_V_read571_rewind_phi_fu_14058_p6 = data_541_V_read571_rewind_reg_14054.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_542_V_read572_phi_phi_fu_21052_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_542_V_read572_phi_phi_fu_21052_p4 = ap_phi_mux_data_542_V_read572_rewind_phi_fu_14072_p6.read();
    } else {
        ap_phi_mux_data_542_V_read572_phi_phi_fu_21052_p4 = ap_phi_reg_pp0_iter1_data_542_V_read572_phi_reg_21048.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_542_V_read572_rewind_phi_fu_14072_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_542_V_read572_rewind_phi_fu_14072_p6 = data_542_V_read572_phi_reg_21048.read();
    } else {
        ap_phi_mux_data_542_V_read572_rewind_phi_fu_14072_p6 = data_542_V_read572_rewind_reg_14068.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_543_V_read573_phi_phi_fu_21064_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_543_V_read573_phi_phi_fu_21064_p4 = ap_phi_mux_data_543_V_read573_rewind_phi_fu_14086_p6.read();
    } else {
        ap_phi_mux_data_543_V_read573_phi_phi_fu_21064_p4 = ap_phi_reg_pp0_iter1_data_543_V_read573_phi_reg_21060.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_543_V_read573_rewind_phi_fu_14086_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_543_V_read573_rewind_phi_fu_14086_p6 = data_543_V_read573_phi_reg_21060.read();
    } else {
        ap_phi_mux_data_543_V_read573_rewind_phi_fu_14086_p6 = data_543_V_read573_rewind_reg_14082.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_544_V_read574_phi_phi_fu_21076_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_544_V_read574_phi_phi_fu_21076_p4 = ap_phi_mux_data_544_V_read574_rewind_phi_fu_14100_p6.read();
    } else {
        ap_phi_mux_data_544_V_read574_phi_phi_fu_21076_p4 = ap_phi_reg_pp0_iter1_data_544_V_read574_phi_reg_21072.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_544_V_read574_rewind_phi_fu_14100_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_544_V_read574_rewind_phi_fu_14100_p6 = data_544_V_read574_phi_reg_21072.read();
    } else {
        ap_phi_mux_data_544_V_read574_rewind_phi_fu_14100_p6 = data_544_V_read574_rewind_reg_14096.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_545_V_read575_phi_phi_fu_21088_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_545_V_read575_phi_phi_fu_21088_p4 = ap_phi_mux_data_545_V_read575_rewind_phi_fu_14114_p6.read();
    } else {
        ap_phi_mux_data_545_V_read575_phi_phi_fu_21088_p4 = ap_phi_reg_pp0_iter1_data_545_V_read575_phi_reg_21084.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_545_V_read575_rewind_phi_fu_14114_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_545_V_read575_rewind_phi_fu_14114_p6 = data_545_V_read575_phi_reg_21084.read();
    } else {
        ap_phi_mux_data_545_V_read575_rewind_phi_fu_14114_p6 = data_545_V_read575_rewind_reg_14110.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_546_V_read576_phi_phi_fu_21100_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_546_V_read576_phi_phi_fu_21100_p4 = ap_phi_mux_data_546_V_read576_rewind_phi_fu_14128_p6.read();
    } else {
        ap_phi_mux_data_546_V_read576_phi_phi_fu_21100_p4 = ap_phi_reg_pp0_iter1_data_546_V_read576_phi_reg_21096.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_546_V_read576_rewind_phi_fu_14128_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_546_V_read576_rewind_phi_fu_14128_p6 = data_546_V_read576_phi_reg_21096.read();
    } else {
        ap_phi_mux_data_546_V_read576_rewind_phi_fu_14128_p6 = data_546_V_read576_rewind_reg_14124.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_547_V_read577_phi_phi_fu_21112_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_547_V_read577_phi_phi_fu_21112_p4 = ap_phi_mux_data_547_V_read577_rewind_phi_fu_14142_p6.read();
    } else {
        ap_phi_mux_data_547_V_read577_phi_phi_fu_21112_p4 = ap_phi_reg_pp0_iter1_data_547_V_read577_phi_reg_21108.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_547_V_read577_rewind_phi_fu_14142_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_547_V_read577_rewind_phi_fu_14142_p6 = data_547_V_read577_phi_reg_21108.read();
    } else {
        ap_phi_mux_data_547_V_read577_rewind_phi_fu_14142_p6 = data_547_V_read577_rewind_reg_14138.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_548_V_read578_phi_phi_fu_21124_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_548_V_read578_phi_phi_fu_21124_p4 = ap_phi_mux_data_548_V_read578_rewind_phi_fu_14156_p6.read();
    } else {
        ap_phi_mux_data_548_V_read578_phi_phi_fu_21124_p4 = ap_phi_reg_pp0_iter1_data_548_V_read578_phi_reg_21120.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_548_V_read578_rewind_phi_fu_14156_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_548_V_read578_rewind_phi_fu_14156_p6 = data_548_V_read578_phi_reg_21120.read();
    } else {
        ap_phi_mux_data_548_V_read578_rewind_phi_fu_14156_p6 = data_548_V_read578_rewind_reg_14152.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_549_V_read579_phi_phi_fu_21136_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_549_V_read579_phi_phi_fu_21136_p4 = ap_phi_mux_data_549_V_read579_rewind_phi_fu_14170_p6.read();
    } else {
        ap_phi_mux_data_549_V_read579_phi_phi_fu_21136_p4 = ap_phi_reg_pp0_iter1_data_549_V_read579_phi_reg_21132.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_549_V_read579_rewind_phi_fu_14170_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_549_V_read579_rewind_phi_fu_14170_p6 = data_549_V_read579_phi_reg_21132.read();
    } else {
        ap_phi_mux_data_549_V_read579_rewind_phi_fu_14170_p6 = data_549_V_read579_rewind_reg_14166.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_54_V_read84_phi_phi_fu_15196_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_54_V_read84_phi_phi_fu_15196_p4 = ap_phi_mux_data_54_V_read84_rewind_phi_fu_7240_p6.read();
    } else {
        ap_phi_mux_data_54_V_read84_phi_phi_fu_15196_p4 = ap_phi_reg_pp0_iter1_data_54_V_read84_phi_reg_15192.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_54_V_read84_rewind_phi_fu_7240_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_54_V_read84_rewind_phi_fu_7240_p6 = data_54_V_read84_phi_reg_15192.read();
    } else {
        ap_phi_mux_data_54_V_read84_rewind_phi_fu_7240_p6 = data_54_V_read84_rewind_reg_7236.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_550_V_read580_phi_phi_fu_21148_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_550_V_read580_phi_phi_fu_21148_p4 = ap_phi_mux_data_550_V_read580_rewind_phi_fu_14184_p6.read();
    } else {
        ap_phi_mux_data_550_V_read580_phi_phi_fu_21148_p4 = ap_phi_reg_pp0_iter1_data_550_V_read580_phi_reg_21144.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_550_V_read580_rewind_phi_fu_14184_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_550_V_read580_rewind_phi_fu_14184_p6 = data_550_V_read580_phi_reg_21144.read();
    } else {
        ap_phi_mux_data_550_V_read580_rewind_phi_fu_14184_p6 = data_550_V_read580_rewind_reg_14180.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_551_V_read581_phi_phi_fu_21160_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_551_V_read581_phi_phi_fu_21160_p4 = ap_phi_mux_data_551_V_read581_rewind_phi_fu_14198_p6.read();
    } else {
        ap_phi_mux_data_551_V_read581_phi_phi_fu_21160_p4 = ap_phi_reg_pp0_iter1_data_551_V_read581_phi_reg_21156.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_551_V_read581_rewind_phi_fu_14198_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_551_V_read581_rewind_phi_fu_14198_p6 = data_551_V_read581_phi_reg_21156.read();
    } else {
        ap_phi_mux_data_551_V_read581_rewind_phi_fu_14198_p6 = data_551_V_read581_rewind_reg_14194.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_552_V_read582_phi_phi_fu_21172_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_552_V_read582_phi_phi_fu_21172_p4 = ap_phi_mux_data_552_V_read582_rewind_phi_fu_14212_p6.read();
    } else {
        ap_phi_mux_data_552_V_read582_phi_phi_fu_21172_p4 = ap_phi_reg_pp0_iter1_data_552_V_read582_phi_reg_21168.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_552_V_read582_rewind_phi_fu_14212_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_552_V_read582_rewind_phi_fu_14212_p6 = data_552_V_read582_phi_reg_21168.read();
    } else {
        ap_phi_mux_data_552_V_read582_rewind_phi_fu_14212_p6 = data_552_V_read582_rewind_reg_14208.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_553_V_read583_phi_phi_fu_21184_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_553_V_read583_phi_phi_fu_21184_p4 = ap_phi_mux_data_553_V_read583_rewind_phi_fu_14226_p6.read();
    } else {
        ap_phi_mux_data_553_V_read583_phi_phi_fu_21184_p4 = ap_phi_reg_pp0_iter1_data_553_V_read583_phi_reg_21180.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_553_V_read583_rewind_phi_fu_14226_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_553_V_read583_rewind_phi_fu_14226_p6 = data_553_V_read583_phi_reg_21180.read();
    } else {
        ap_phi_mux_data_553_V_read583_rewind_phi_fu_14226_p6 = data_553_V_read583_rewind_reg_14222.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_554_V_read584_phi_phi_fu_21196_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_554_V_read584_phi_phi_fu_21196_p4 = ap_phi_mux_data_554_V_read584_rewind_phi_fu_14240_p6.read();
    } else {
        ap_phi_mux_data_554_V_read584_phi_phi_fu_21196_p4 = ap_phi_reg_pp0_iter1_data_554_V_read584_phi_reg_21192.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_554_V_read584_rewind_phi_fu_14240_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_554_V_read584_rewind_phi_fu_14240_p6 = data_554_V_read584_phi_reg_21192.read();
    } else {
        ap_phi_mux_data_554_V_read584_rewind_phi_fu_14240_p6 = data_554_V_read584_rewind_reg_14236.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_555_V_read585_phi_phi_fu_21208_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_555_V_read585_phi_phi_fu_21208_p4 = ap_phi_mux_data_555_V_read585_rewind_phi_fu_14254_p6.read();
    } else {
        ap_phi_mux_data_555_V_read585_phi_phi_fu_21208_p4 = ap_phi_reg_pp0_iter1_data_555_V_read585_phi_reg_21204.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_555_V_read585_rewind_phi_fu_14254_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_555_V_read585_rewind_phi_fu_14254_p6 = data_555_V_read585_phi_reg_21204.read();
    } else {
        ap_phi_mux_data_555_V_read585_rewind_phi_fu_14254_p6 = data_555_V_read585_rewind_reg_14250.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_556_V_read586_phi_phi_fu_21220_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_556_V_read586_phi_phi_fu_21220_p4 = ap_phi_mux_data_556_V_read586_rewind_phi_fu_14268_p6.read();
    } else {
        ap_phi_mux_data_556_V_read586_phi_phi_fu_21220_p4 = ap_phi_reg_pp0_iter1_data_556_V_read586_phi_reg_21216.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_556_V_read586_rewind_phi_fu_14268_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_556_V_read586_rewind_phi_fu_14268_p6 = data_556_V_read586_phi_reg_21216.read();
    } else {
        ap_phi_mux_data_556_V_read586_rewind_phi_fu_14268_p6 = data_556_V_read586_rewind_reg_14264.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_557_V_read587_phi_phi_fu_21232_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_557_V_read587_phi_phi_fu_21232_p4 = ap_phi_mux_data_557_V_read587_rewind_phi_fu_14282_p6.read();
    } else {
        ap_phi_mux_data_557_V_read587_phi_phi_fu_21232_p4 = ap_phi_reg_pp0_iter1_data_557_V_read587_phi_reg_21228.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_557_V_read587_rewind_phi_fu_14282_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_557_V_read587_rewind_phi_fu_14282_p6 = data_557_V_read587_phi_reg_21228.read();
    } else {
        ap_phi_mux_data_557_V_read587_rewind_phi_fu_14282_p6 = data_557_V_read587_rewind_reg_14278.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_558_V_read588_phi_phi_fu_21244_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_558_V_read588_phi_phi_fu_21244_p4 = ap_phi_mux_data_558_V_read588_rewind_phi_fu_14296_p6.read();
    } else {
        ap_phi_mux_data_558_V_read588_phi_phi_fu_21244_p4 = ap_phi_reg_pp0_iter1_data_558_V_read588_phi_reg_21240.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_558_V_read588_rewind_phi_fu_14296_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_558_V_read588_rewind_phi_fu_14296_p6 = data_558_V_read588_phi_reg_21240.read();
    } else {
        ap_phi_mux_data_558_V_read588_rewind_phi_fu_14296_p6 = data_558_V_read588_rewind_reg_14292.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_559_V_read589_phi_phi_fu_21256_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_559_V_read589_phi_phi_fu_21256_p4 = ap_phi_mux_data_559_V_read589_rewind_phi_fu_14310_p6.read();
    } else {
        ap_phi_mux_data_559_V_read589_phi_phi_fu_21256_p4 = ap_phi_reg_pp0_iter1_data_559_V_read589_phi_reg_21252.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_559_V_read589_rewind_phi_fu_14310_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_559_V_read589_rewind_phi_fu_14310_p6 = data_559_V_read589_phi_reg_21252.read();
    } else {
        ap_phi_mux_data_559_V_read589_rewind_phi_fu_14310_p6 = data_559_V_read589_rewind_reg_14306.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_55_V_read85_phi_phi_fu_15208_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_55_V_read85_phi_phi_fu_15208_p4 = ap_phi_mux_data_55_V_read85_rewind_phi_fu_7254_p6.read();
    } else {
        ap_phi_mux_data_55_V_read85_phi_phi_fu_15208_p4 = ap_phi_reg_pp0_iter1_data_55_V_read85_phi_reg_15204.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_55_V_read85_rewind_phi_fu_7254_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_55_V_read85_rewind_phi_fu_7254_p6 = data_55_V_read85_phi_reg_15204.read();
    } else {
        ap_phi_mux_data_55_V_read85_rewind_phi_fu_7254_p6 = data_55_V_read85_rewind_reg_7250.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_560_V_read590_phi_phi_fu_21268_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_560_V_read590_phi_phi_fu_21268_p4 = ap_phi_mux_data_560_V_read590_rewind_phi_fu_14324_p6.read();
    } else {
        ap_phi_mux_data_560_V_read590_phi_phi_fu_21268_p4 = ap_phi_reg_pp0_iter1_data_560_V_read590_phi_reg_21264.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_560_V_read590_rewind_phi_fu_14324_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_560_V_read590_rewind_phi_fu_14324_p6 = data_560_V_read590_phi_reg_21264.read();
    } else {
        ap_phi_mux_data_560_V_read590_rewind_phi_fu_14324_p6 = data_560_V_read590_rewind_reg_14320.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_561_V_read591_phi_phi_fu_21280_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_561_V_read591_phi_phi_fu_21280_p4 = ap_phi_mux_data_561_V_read591_rewind_phi_fu_14338_p6.read();
    } else {
        ap_phi_mux_data_561_V_read591_phi_phi_fu_21280_p4 = ap_phi_reg_pp0_iter1_data_561_V_read591_phi_reg_21276.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_561_V_read591_rewind_phi_fu_14338_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_561_V_read591_rewind_phi_fu_14338_p6 = data_561_V_read591_phi_reg_21276.read();
    } else {
        ap_phi_mux_data_561_V_read591_rewind_phi_fu_14338_p6 = data_561_V_read591_rewind_reg_14334.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_562_V_read592_phi_phi_fu_21292_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_562_V_read592_phi_phi_fu_21292_p4 = ap_phi_mux_data_562_V_read592_rewind_phi_fu_14352_p6.read();
    } else {
        ap_phi_mux_data_562_V_read592_phi_phi_fu_21292_p4 = ap_phi_reg_pp0_iter1_data_562_V_read592_phi_reg_21288.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_562_V_read592_rewind_phi_fu_14352_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_562_V_read592_rewind_phi_fu_14352_p6 = data_562_V_read592_phi_reg_21288.read();
    } else {
        ap_phi_mux_data_562_V_read592_rewind_phi_fu_14352_p6 = data_562_V_read592_rewind_reg_14348.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_563_V_read593_phi_phi_fu_21304_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_563_V_read593_phi_phi_fu_21304_p4 = ap_phi_mux_data_563_V_read593_rewind_phi_fu_14366_p6.read();
    } else {
        ap_phi_mux_data_563_V_read593_phi_phi_fu_21304_p4 = ap_phi_reg_pp0_iter1_data_563_V_read593_phi_reg_21300.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_563_V_read593_rewind_phi_fu_14366_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_563_V_read593_rewind_phi_fu_14366_p6 = data_563_V_read593_phi_reg_21300.read();
    } else {
        ap_phi_mux_data_563_V_read593_rewind_phi_fu_14366_p6 = data_563_V_read593_rewind_reg_14362.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_564_V_read594_phi_phi_fu_21316_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_564_V_read594_phi_phi_fu_21316_p4 = ap_phi_mux_data_564_V_read594_rewind_phi_fu_14380_p6.read();
    } else {
        ap_phi_mux_data_564_V_read594_phi_phi_fu_21316_p4 = ap_phi_reg_pp0_iter1_data_564_V_read594_phi_reg_21312.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_564_V_read594_rewind_phi_fu_14380_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_564_V_read594_rewind_phi_fu_14380_p6 = data_564_V_read594_phi_reg_21312.read();
    } else {
        ap_phi_mux_data_564_V_read594_rewind_phi_fu_14380_p6 = data_564_V_read594_rewind_reg_14376.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_565_V_read595_phi_phi_fu_21328_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_565_V_read595_phi_phi_fu_21328_p4 = ap_phi_mux_data_565_V_read595_rewind_phi_fu_14394_p6.read();
    } else {
        ap_phi_mux_data_565_V_read595_phi_phi_fu_21328_p4 = ap_phi_reg_pp0_iter1_data_565_V_read595_phi_reg_21324.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_565_V_read595_rewind_phi_fu_14394_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_565_V_read595_rewind_phi_fu_14394_p6 = data_565_V_read595_phi_reg_21324.read();
    } else {
        ap_phi_mux_data_565_V_read595_rewind_phi_fu_14394_p6 = data_565_V_read595_rewind_reg_14390.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_566_V_read596_phi_phi_fu_21340_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_566_V_read596_phi_phi_fu_21340_p4 = ap_phi_mux_data_566_V_read596_rewind_phi_fu_14408_p6.read();
    } else {
        ap_phi_mux_data_566_V_read596_phi_phi_fu_21340_p4 = ap_phi_reg_pp0_iter1_data_566_V_read596_phi_reg_21336.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_566_V_read596_rewind_phi_fu_14408_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_566_V_read596_rewind_phi_fu_14408_p6 = data_566_V_read596_phi_reg_21336.read();
    } else {
        ap_phi_mux_data_566_V_read596_rewind_phi_fu_14408_p6 = data_566_V_read596_rewind_reg_14404.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_567_V_read597_phi_phi_fu_21352_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_567_V_read597_phi_phi_fu_21352_p4 = ap_phi_mux_data_567_V_read597_rewind_phi_fu_14422_p6.read();
    } else {
        ap_phi_mux_data_567_V_read597_phi_phi_fu_21352_p4 = ap_phi_reg_pp0_iter1_data_567_V_read597_phi_reg_21348.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_567_V_read597_rewind_phi_fu_14422_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_567_V_read597_rewind_phi_fu_14422_p6 = data_567_V_read597_phi_reg_21348.read();
    } else {
        ap_phi_mux_data_567_V_read597_rewind_phi_fu_14422_p6 = data_567_V_read597_rewind_reg_14418.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_568_V_read598_phi_phi_fu_21364_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_568_V_read598_phi_phi_fu_21364_p4 = ap_phi_mux_data_568_V_read598_rewind_phi_fu_14436_p6.read();
    } else {
        ap_phi_mux_data_568_V_read598_phi_phi_fu_21364_p4 = ap_phi_reg_pp0_iter1_data_568_V_read598_phi_reg_21360.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_568_V_read598_rewind_phi_fu_14436_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_568_V_read598_rewind_phi_fu_14436_p6 = data_568_V_read598_phi_reg_21360.read();
    } else {
        ap_phi_mux_data_568_V_read598_rewind_phi_fu_14436_p6 = data_568_V_read598_rewind_reg_14432.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_569_V_read599_phi_phi_fu_21376_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_569_V_read599_phi_phi_fu_21376_p4 = ap_phi_mux_data_569_V_read599_rewind_phi_fu_14450_p6.read();
    } else {
        ap_phi_mux_data_569_V_read599_phi_phi_fu_21376_p4 = ap_phi_reg_pp0_iter1_data_569_V_read599_phi_reg_21372.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_569_V_read599_rewind_phi_fu_14450_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_569_V_read599_rewind_phi_fu_14450_p6 = data_569_V_read599_phi_reg_21372.read();
    } else {
        ap_phi_mux_data_569_V_read599_rewind_phi_fu_14450_p6 = data_569_V_read599_rewind_reg_14446.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_56_V_read86_phi_phi_fu_15220_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_56_V_read86_phi_phi_fu_15220_p4 = ap_phi_mux_data_56_V_read86_rewind_phi_fu_7268_p6.read();
    } else {
        ap_phi_mux_data_56_V_read86_phi_phi_fu_15220_p4 = ap_phi_reg_pp0_iter1_data_56_V_read86_phi_reg_15216.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_56_V_read86_rewind_phi_fu_7268_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_56_V_read86_rewind_phi_fu_7268_p6 = data_56_V_read86_phi_reg_15216.read();
    } else {
        ap_phi_mux_data_56_V_read86_rewind_phi_fu_7268_p6 = data_56_V_read86_rewind_reg_7264.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_570_V_read600_phi_phi_fu_21388_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_570_V_read600_phi_phi_fu_21388_p4 = ap_phi_mux_data_570_V_read600_rewind_phi_fu_14464_p6.read();
    } else {
        ap_phi_mux_data_570_V_read600_phi_phi_fu_21388_p4 = ap_phi_reg_pp0_iter1_data_570_V_read600_phi_reg_21384.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_570_V_read600_rewind_phi_fu_14464_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_570_V_read600_rewind_phi_fu_14464_p6 = data_570_V_read600_phi_reg_21384.read();
    } else {
        ap_phi_mux_data_570_V_read600_rewind_phi_fu_14464_p6 = data_570_V_read600_rewind_reg_14460.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_571_V_read601_phi_phi_fu_21400_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_571_V_read601_phi_phi_fu_21400_p4 = ap_phi_mux_data_571_V_read601_rewind_phi_fu_14478_p6.read();
    } else {
        ap_phi_mux_data_571_V_read601_phi_phi_fu_21400_p4 = ap_phi_reg_pp0_iter1_data_571_V_read601_phi_reg_21396.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_571_V_read601_rewind_phi_fu_14478_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_571_V_read601_rewind_phi_fu_14478_p6 = data_571_V_read601_phi_reg_21396.read();
    } else {
        ap_phi_mux_data_571_V_read601_rewind_phi_fu_14478_p6 = data_571_V_read601_rewind_reg_14474.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_572_V_read602_phi_phi_fu_21412_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_572_V_read602_phi_phi_fu_21412_p4 = ap_phi_mux_data_572_V_read602_rewind_phi_fu_14492_p6.read();
    } else {
        ap_phi_mux_data_572_V_read602_phi_phi_fu_21412_p4 = ap_phi_reg_pp0_iter1_data_572_V_read602_phi_reg_21408.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_572_V_read602_rewind_phi_fu_14492_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_572_V_read602_rewind_phi_fu_14492_p6 = data_572_V_read602_phi_reg_21408.read();
    } else {
        ap_phi_mux_data_572_V_read602_rewind_phi_fu_14492_p6 = data_572_V_read602_rewind_reg_14488.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_573_V_read603_phi_phi_fu_21424_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_573_V_read603_phi_phi_fu_21424_p4 = ap_phi_mux_data_573_V_read603_rewind_phi_fu_14506_p6.read();
    } else {
        ap_phi_mux_data_573_V_read603_phi_phi_fu_21424_p4 = ap_phi_reg_pp0_iter1_data_573_V_read603_phi_reg_21420.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_573_V_read603_rewind_phi_fu_14506_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_573_V_read603_rewind_phi_fu_14506_p6 = data_573_V_read603_phi_reg_21420.read();
    } else {
        ap_phi_mux_data_573_V_read603_rewind_phi_fu_14506_p6 = data_573_V_read603_rewind_reg_14502.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_574_V_read604_phi_phi_fu_21436_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_574_V_read604_phi_phi_fu_21436_p4 = ap_phi_mux_data_574_V_read604_rewind_phi_fu_14520_p6.read();
    } else {
        ap_phi_mux_data_574_V_read604_phi_phi_fu_21436_p4 = ap_phi_reg_pp0_iter1_data_574_V_read604_phi_reg_21432.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_574_V_read604_rewind_phi_fu_14520_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_574_V_read604_rewind_phi_fu_14520_p6 = data_574_V_read604_phi_reg_21432.read();
    } else {
        ap_phi_mux_data_574_V_read604_rewind_phi_fu_14520_p6 = data_574_V_read604_rewind_reg_14516.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_575_V_read605_phi_phi_fu_21448_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_575_V_read605_phi_phi_fu_21448_p4 = ap_phi_mux_data_575_V_read605_rewind_phi_fu_14534_p6.read();
    } else {
        ap_phi_mux_data_575_V_read605_phi_phi_fu_21448_p4 = ap_phi_reg_pp0_iter1_data_575_V_read605_phi_reg_21444.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_575_V_read605_rewind_phi_fu_14534_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_575_V_read605_rewind_phi_fu_14534_p6 = data_575_V_read605_phi_reg_21444.read();
    } else {
        ap_phi_mux_data_575_V_read605_rewind_phi_fu_14534_p6 = data_575_V_read605_rewind_reg_14530.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_57_V_read87_phi_phi_fu_15232_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_57_V_read87_phi_phi_fu_15232_p4 = ap_phi_mux_data_57_V_read87_rewind_phi_fu_7282_p6.read();
    } else {
        ap_phi_mux_data_57_V_read87_phi_phi_fu_15232_p4 = ap_phi_reg_pp0_iter1_data_57_V_read87_phi_reg_15228.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_57_V_read87_rewind_phi_fu_7282_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_57_V_read87_rewind_phi_fu_7282_p6 = data_57_V_read87_phi_reg_15228.read();
    } else {
        ap_phi_mux_data_57_V_read87_rewind_phi_fu_7282_p6 = data_57_V_read87_rewind_reg_7278.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_58_V_read88_phi_phi_fu_15244_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_58_V_read88_phi_phi_fu_15244_p4 = ap_phi_mux_data_58_V_read88_rewind_phi_fu_7296_p6.read();
    } else {
        ap_phi_mux_data_58_V_read88_phi_phi_fu_15244_p4 = ap_phi_reg_pp0_iter1_data_58_V_read88_phi_reg_15240.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_58_V_read88_rewind_phi_fu_7296_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_58_V_read88_rewind_phi_fu_7296_p6 = data_58_V_read88_phi_reg_15240.read();
    } else {
        ap_phi_mux_data_58_V_read88_rewind_phi_fu_7296_p6 = data_58_V_read88_rewind_reg_7292.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_59_V_read89_phi_phi_fu_15256_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_59_V_read89_phi_phi_fu_15256_p4 = ap_phi_mux_data_59_V_read89_rewind_phi_fu_7310_p6.read();
    } else {
        ap_phi_mux_data_59_V_read89_phi_phi_fu_15256_p4 = ap_phi_reg_pp0_iter1_data_59_V_read89_phi_reg_15252.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_59_V_read89_rewind_phi_fu_7310_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_59_V_read89_rewind_phi_fu_7310_p6 = data_59_V_read89_phi_reg_15252.read();
    } else {
        ap_phi_mux_data_59_V_read89_rewind_phi_fu_7310_p6 = data_59_V_read89_rewind_reg_7306.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_5_V_read35_phi_phi_fu_14608_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_5_V_read35_phi_phi_fu_14608_p4 = ap_phi_mux_data_5_V_read35_rewind_phi_fu_6554_p6.read();
    } else {
        ap_phi_mux_data_5_V_read35_phi_phi_fu_14608_p4 = ap_phi_reg_pp0_iter1_data_5_V_read35_phi_reg_14604.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_5_V_read35_rewind_phi_fu_6554_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_5_V_read35_rewind_phi_fu_6554_p6 = data_5_V_read35_phi_reg_14604.read();
    } else {
        ap_phi_mux_data_5_V_read35_rewind_phi_fu_6554_p6 = data_5_V_read35_rewind_reg_6550.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_60_V_read90_phi_phi_fu_15268_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_60_V_read90_phi_phi_fu_15268_p4 = ap_phi_mux_data_60_V_read90_rewind_phi_fu_7324_p6.read();
    } else {
        ap_phi_mux_data_60_V_read90_phi_phi_fu_15268_p4 = ap_phi_reg_pp0_iter1_data_60_V_read90_phi_reg_15264.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_60_V_read90_rewind_phi_fu_7324_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_60_V_read90_rewind_phi_fu_7324_p6 = data_60_V_read90_phi_reg_15264.read();
    } else {
        ap_phi_mux_data_60_V_read90_rewind_phi_fu_7324_p6 = data_60_V_read90_rewind_reg_7320.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_61_V_read91_phi_phi_fu_15280_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_61_V_read91_phi_phi_fu_15280_p4 = ap_phi_mux_data_61_V_read91_rewind_phi_fu_7338_p6.read();
    } else {
        ap_phi_mux_data_61_V_read91_phi_phi_fu_15280_p4 = ap_phi_reg_pp0_iter1_data_61_V_read91_phi_reg_15276.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_61_V_read91_rewind_phi_fu_7338_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_61_V_read91_rewind_phi_fu_7338_p6 = data_61_V_read91_phi_reg_15276.read();
    } else {
        ap_phi_mux_data_61_V_read91_rewind_phi_fu_7338_p6 = data_61_V_read91_rewind_reg_7334.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_62_V_read92_phi_phi_fu_15292_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_62_V_read92_phi_phi_fu_15292_p4 = ap_phi_mux_data_62_V_read92_rewind_phi_fu_7352_p6.read();
    } else {
        ap_phi_mux_data_62_V_read92_phi_phi_fu_15292_p4 = ap_phi_reg_pp0_iter1_data_62_V_read92_phi_reg_15288.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_62_V_read92_rewind_phi_fu_7352_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_62_V_read92_rewind_phi_fu_7352_p6 = data_62_V_read92_phi_reg_15288.read();
    } else {
        ap_phi_mux_data_62_V_read92_rewind_phi_fu_7352_p6 = data_62_V_read92_rewind_reg_7348.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_63_V_read93_phi_phi_fu_15304_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_63_V_read93_phi_phi_fu_15304_p4 = ap_phi_mux_data_63_V_read93_rewind_phi_fu_7366_p6.read();
    } else {
        ap_phi_mux_data_63_V_read93_phi_phi_fu_15304_p4 = ap_phi_reg_pp0_iter1_data_63_V_read93_phi_reg_15300.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_63_V_read93_rewind_phi_fu_7366_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_63_V_read93_rewind_phi_fu_7366_p6 = data_63_V_read93_phi_reg_15300.read();
    } else {
        ap_phi_mux_data_63_V_read93_rewind_phi_fu_7366_p6 = data_63_V_read93_rewind_reg_7362.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_64_V_read94_phi_phi_fu_15316_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_64_V_read94_phi_phi_fu_15316_p4 = ap_phi_mux_data_64_V_read94_rewind_phi_fu_7380_p6.read();
    } else {
        ap_phi_mux_data_64_V_read94_phi_phi_fu_15316_p4 = ap_phi_reg_pp0_iter1_data_64_V_read94_phi_reg_15312.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_64_V_read94_rewind_phi_fu_7380_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_64_V_read94_rewind_phi_fu_7380_p6 = data_64_V_read94_phi_reg_15312.read();
    } else {
        ap_phi_mux_data_64_V_read94_rewind_phi_fu_7380_p6 = data_64_V_read94_rewind_reg_7376.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_65_V_read95_phi_phi_fu_15328_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_65_V_read95_phi_phi_fu_15328_p4 = ap_phi_mux_data_65_V_read95_rewind_phi_fu_7394_p6.read();
    } else {
        ap_phi_mux_data_65_V_read95_phi_phi_fu_15328_p4 = ap_phi_reg_pp0_iter1_data_65_V_read95_phi_reg_15324.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_65_V_read95_rewind_phi_fu_7394_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_65_V_read95_rewind_phi_fu_7394_p6 = data_65_V_read95_phi_reg_15324.read();
    } else {
        ap_phi_mux_data_65_V_read95_rewind_phi_fu_7394_p6 = data_65_V_read95_rewind_reg_7390.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_66_V_read96_phi_phi_fu_15340_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_66_V_read96_phi_phi_fu_15340_p4 = ap_phi_mux_data_66_V_read96_rewind_phi_fu_7408_p6.read();
    } else {
        ap_phi_mux_data_66_V_read96_phi_phi_fu_15340_p4 = ap_phi_reg_pp0_iter1_data_66_V_read96_phi_reg_15336.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_66_V_read96_rewind_phi_fu_7408_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_66_V_read96_rewind_phi_fu_7408_p6 = data_66_V_read96_phi_reg_15336.read();
    } else {
        ap_phi_mux_data_66_V_read96_rewind_phi_fu_7408_p6 = data_66_V_read96_rewind_reg_7404.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_67_V_read97_phi_phi_fu_15352_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_67_V_read97_phi_phi_fu_15352_p4 = ap_phi_mux_data_67_V_read97_rewind_phi_fu_7422_p6.read();
    } else {
        ap_phi_mux_data_67_V_read97_phi_phi_fu_15352_p4 = ap_phi_reg_pp0_iter1_data_67_V_read97_phi_reg_15348.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_67_V_read97_rewind_phi_fu_7422_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_67_V_read97_rewind_phi_fu_7422_p6 = data_67_V_read97_phi_reg_15348.read();
    } else {
        ap_phi_mux_data_67_V_read97_rewind_phi_fu_7422_p6 = data_67_V_read97_rewind_reg_7418.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_68_V_read98_phi_phi_fu_15364_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_68_V_read98_phi_phi_fu_15364_p4 = ap_phi_mux_data_68_V_read98_rewind_phi_fu_7436_p6.read();
    } else {
        ap_phi_mux_data_68_V_read98_phi_phi_fu_15364_p4 = ap_phi_reg_pp0_iter1_data_68_V_read98_phi_reg_15360.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_68_V_read98_rewind_phi_fu_7436_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_68_V_read98_rewind_phi_fu_7436_p6 = data_68_V_read98_phi_reg_15360.read();
    } else {
        ap_phi_mux_data_68_V_read98_rewind_phi_fu_7436_p6 = data_68_V_read98_rewind_reg_7432.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_69_V_read99_phi_phi_fu_15376_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_69_V_read99_phi_phi_fu_15376_p4 = ap_phi_mux_data_69_V_read99_rewind_phi_fu_7450_p6.read();
    } else {
        ap_phi_mux_data_69_V_read99_phi_phi_fu_15376_p4 = ap_phi_reg_pp0_iter1_data_69_V_read99_phi_reg_15372.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_69_V_read99_rewind_phi_fu_7450_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_69_V_read99_rewind_phi_fu_7450_p6 = data_69_V_read99_phi_reg_15372.read();
    } else {
        ap_phi_mux_data_69_V_read99_rewind_phi_fu_7450_p6 = data_69_V_read99_rewind_reg_7446.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_6_V_read36_phi_phi_fu_14620_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_6_V_read36_phi_phi_fu_14620_p4 = ap_phi_mux_data_6_V_read36_rewind_phi_fu_6568_p6.read();
    } else {
        ap_phi_mux_data_6_V_read36_phi_phi_fu_14620_p4 = ap_phi_reg_pp0_iter1_data_6_V_read36_phi_reg_14616.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_6_V_read36_rewind_phi_fu_6568_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_6_V_read36_rewind_phi_fu_6568_p6 = data_6_V_read36_phi_reg_14616.read();
    } else {
        ap_phi_mux_data_6_V_read36_rewind_phi_fu_6568_p6 = data_6_V_read36_rewind_reg_6564.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_70_V_read100_phi_phi_fu_15388_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_70_V_read100_phi_phi_fu_15388_p4 = ap_phi_mux_data_70_V_read100_rewind_phi_fu_7464_p6.read();
    } else {
        ap_phi_mux_data_70_V_read100_phi_phi_fu_15388_p4 = ap_phi_reg_pp0_iter1_data_70_V_read100_phi_reg_15384.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_70_V_read100_rewind_phi_fu_7464_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_70_V_read100_rewind_phi_fu_7464_p6 = data_70_V_read100_phi_reg_15384.read();
    } else {
        ap_phi_mux_data_70_V_read100_rewind_phi_fu_7464_p6 = data_70_V_read100_rewind_reg_7460.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_71_V_read101_phi_phi_fu_15400_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_71_V_read101_phi_phi_fu_15400_p4 = ap_phi_mux_data_71_V_read101_rewind_phi_fu_7478_p6.read();
    } else {
        ap_phi_mux_data_71_V_read101_phi_phi_fu_15400_p4 = ap_phi_reg_pp0_iter1_data_71_V_read101_phi_reg_15396.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_71_V_read101_rewind_phi_fu_7478_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_71_V_read101_rewind_phi_fu_7478_p6 = data_71_V_read101_phi_reg_15396.read();
    } else {
        ap_phi_mux_data_71_V_read101_rewind_phi_fu_7478_p6 = data_71_V_read101_rewind_reg_7474.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_72_V_read102_phi_phi_fu_15412_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_72_V_read102_phi_phi_fu_15412_p4 = ap_phi_mux_data_72_V_read102_rewind_phi_fu_7492_p6.read();
    } else {
        ap_phi_mux_data_72_V_read102_phi_phi_fu_15412_p4 = ap_phi_reg_pp0_iter1_data_72_V_read102_phi_reg_15408.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_72_V_read102_rewind_phi_fu_7492_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_72_V_read102_rewind_phi_fu_7492_p6 = data_72_V_read102_phi_reg_15408.read();
    } else {
        ap_phi_mux_data_72_V_read102_rewind_phi_fu_7492_p6 = data_72_V_read102_rewind_reg_7488.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_73_V_read103_phi_phi_fu_15424_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_73_V_read103_phi_phi_fu_15424_p4 = ap_phi_mux_data_73_V_read103_rewind_phi_fu_7506_p6.read();
    } else {
        ap_phi_mux_data_73_V_read103_phi_phi_fu_15424_p4 = ap_phi_reg_pp0_iter1_data_73_V_read103_phi_reg_15420.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_73_V_read103_rewind_phi_fu_7506_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_73_V_read103_rewind_phi_fu_7506_p6 = data_73_V_read103_phi_reg_15420.read();
    } else {
        ap_phi_mux_data_73_V_read103_rewind_phi_fu_7506_p6 = data_73_V_read103_rewind_reg_7502.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_74_V_read104_phi_phi_fu_15436_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_74_V_read104_phi_phi_fu_15436_p4 = ap_phi_mux_data_74_V_read104_rewind_phi_fu_7520_p6.read();
    } else {
        ap_phi_mux_data_74_V_read104_phi_phi_fu_15436_p4 = ap_phi_reg_pp0_iter1_data_74_V_read104_phi_reg_15432.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_74_V_read104_rewind_phi_fu_7520_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_74_V_read104_rewind_phi_fu_7520_p6 = data_74_V_read104_phi_reg_15432.read();
    } else {
        ap_phi_mux_data_74_V_read104_rewind_phi_fu_7520_p6 = data_74_V_read104_rewind_reg_7516.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_75_V_read105_phi_phi_fu_15448_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_75_V_read105_phi_phi_fu_15448_p4 = ap_phi_mux_data_75_V_read105_rewind_phi_fu_7534_p6.read();
    } else {
        ap_phi_mux_data_75_V_read105_phi_phi_fu_15448_p4 = ap_phi_reg_pp0_iter1_data_75_V_read105_phi_reg_15444.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_75_V_read105_rewind_phi_fu_7534_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_75_V_read105_rewind_phi_fu_7534_p6 = data_75_V_read105_phi_reg_15444.read();
    } else {
        ap_phi_mux_data_75_V_read105_rewind_phi_fu_7534_p6 = data_75_V_read105_rewind_reg_7530.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_76_V_read106_phi_phi_fu_15460_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_76_V_read106_phi_phi_fu_15460_p4 = ap_phi_mux_data_76_V_read106_rewind_phi_fu_7548_p6.read();
    } else {
        ap_phi_mux_data_76_V_read106_phi_phi_fu_15460_p4 = ap_phi_reg_pp0_iter1_data_76_V_read106_phi_reg_15456.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_76_V_read106_rewind_phi_fu_7548_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_76_V_read106_rewind_phi_fu_7548_p6 = data_76_V_read106_phi_reg_15456.read();
    } else {
        ap_phi_mux_data_76_V_read106_rewind_phi_fu_7548_p6 = data_76_V_read106_rewind_reg_7544.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_77_V_read107_phi_phi_fu_15472_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_77_V_read107_phi_phi_fu_15472_p4 = ap_phi_mux_data_77_V_read107_rewind_phi_fu_7562_p6.read();
    } else {
        ap_phi_mux_data_77_V_read107_phi_phi_fu_15472_p4 = ap_phi_reg_pp0_iter1_data_77_V_read107_phi_reg_15468.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_77_V_read107_rewind_phi_fu_7562_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_77_V_read107_rewind_phi_fu_7562_p6 = data_77_V_read107_phi_reg_15468.read();
    } else {
        ap_phi_mux_data_77_V_read107_rewind_phi_fu_7562_p6 = data_77_V_read107_rewind_reg_7558.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_78_V_read108_phi_phi_fu_15484_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_78_V_read108_phi_phi_fu_15484_p4 = ap_phi_mux_data_78_V_read108_rewind_phi_fu_7576_p6.read();
    } else {
        ap_phi_mux_data_78_V_read108_phi_phi_fu_15484_p4 = ap_phi_reg_pp0_iter1_data_78_V_read108_phi_reg_15480.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_78_V_read108_rewind_phi_fu_7576_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_78_V_read108_rewind_phi_fu_7576_p6 = data_78_V_read108_phi_reg_15480.read();
    } else {
        ap_phi_mux_data_78_V_read108_rewind_phi_fu_7576_p6 = data_78_V_read108_rewind_reg_7572.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_79_V_read109_phi_phi_fu_15496_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_79_V_read109_phi_phi_fu_15496_p4 = ap_phi_mux_data_79_V_read109_rewind_phi_fu_7590_p6.read();
    } else {
        ap_phi_mux_data_79_V_read109_phi_phi_fu_15496_p4 = ap_phi_reg_pp0_iter1_data_79_V_read109_phi_reg_15492.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_79_V_read109_rewind_phi_fu_7590_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_79_V_read109_rewind_phi_fu_7590_p6 = data_79_V_read109_phi_reg_15492.read();
    } else {
        ap_phi_mux_data_79_V_read109_rewind_phi_fu_7590_p6 = data_79_V_read109_rewind_reg_7586.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_7_V_read37_phi_phi_fu_14632_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_7_V_read37_phi_phi_fu_14632_p4 = ap_phi_mux_data_7_V_read37_rewind_phi_fu_6582_p6.read();
    } else {
        ap_phi_mux_data_7_V_read37_phi_phi_fu_14632_p4 = ap_phi_reg_pp0_iter1_data_7_V_read37_phi_reg_14628.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_7_V_read37_rewind_phi_fu_6582_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_7_V_read37_rewind_phi_fu_6582_p6 = data_7_V_read37_phi_reg_14628.read();
    } else {
        ap_phi_mux_data_7_V_read37_rewind_phi_fu_6582_p6 = data_7_V_read37_rewind_reg_6578.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_80_V_read110_phi_phi_fu_15508_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_80_V_read110_phi_phi_fu_15508_p4 = ap_phi_mux_data_80_V_read110_rewind_phi_fu_7604_p6.read();
    } else {
        ap_phi_mux_data_80_V_read110_phi_phi_fu_15508_p4 = ap_phi_reg_pp0_iter1_data_80_V_read110_phi_reg_15504.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_80_V_read110_rewind_phi_fu_7604_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_80_V_read110_rewind_phi_fu_7604_p6 = data_80_V_read110_phi_reg_15504.read();
    } else {
        ap_phi_mux_data_80_V_read110_rewind_phi_fu_7604_p6 = data_80_V_read110_rewind_reg_7600.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_81_V_read111_phi_phi_fu_15520_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_81_V_read111_phi_phi_fu_15520_p4 = ap_phi_mux_data_81_V_read111_rewind_phi_fu_7618_p6.read();
    } else {
        ap_phi_mux_data_81_V_read111_phi_phi_fu_15520_p4 = ap_phi_reg_pp0_iter1_data_81_V_read111_phi_reg_15516.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_81_V_read111_rewind_phi_fu_7618_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_81_V_read111_rewind_phi_fu_7618_p6 = data_81_V_read111_phi_reg_15516.read();
    } else {
        ap_phi_mux_data_81_V_read111_rewind_phi_fu_7618_p6 = data_81_V_read111_rewind_reg_7614.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_82_V_read112_phi_phi_fu_15532_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_82_V_read112_phi_phi_fu_15532_p4 = ap_phi_mux_data_82_V_read112_rewind_phi_fu_7632_p6.read();
    } else {
        ap_phi_mux_data_82_V_read112_phi_phi_fu_15532_p4 = ap_phi_reg_pp0_iter1_data_82_V_read112_phi_reg_15528.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_82_V_read112_rewind_phi_fu_7632_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_82_V_read112_rewind_phi_fu_7632_p6 = data_82_V_read112_phi_reg_15528.read();
    } else {
        ap_phi_mux_data_82_V_read112_rewind_phi_fu_7632_p6 = data_82_V_read112_rewind_reg_7628.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_83_V_read113_phi_phi_fu_15544_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_83_V_read113_phi_phi_fu_15544_p4 = ap_phi_mux_data_83_V_read113_rewind_phi_fu_7646_p6.read();
    } else {
        ap_phi_mux_data_83_V_read113_phi_phi_fu_15544_p4 = ap_phi_reg_pp0_iter1_data_83_V_read113_phi_reg_15540.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_83_V_read113_rewind_phi_fu_7646_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_83_V_read113_rewind_phi_fu_7646_p6 = data_83_V_read113_phi_reg_15540.read();
    } else {
        ap_phi_mux_data_83_V_read113_rewind_phi_fu_7646_p6 = data_83_V_read113_rewind_reg_7642.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_84_V_read114_phi_phi_fu_15556_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_84_V_read114_phi_phi_fu_15556_p4 = ap_phi_mux_data_84_V_read114_rewind_phi_fu_7660_p6.read();
    } else {
        ap_phi_mux_data_84_V_read114_phi_phi_fu_15556_p4 = ap_phi_reg_pp0_iter1_data_84_V_read114_phi_reg_15552.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_84_V_read114_rewind_phi_fu_7660_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_84_V_read114_rewind_phi_fu_7660_p6 = data_84_V_read114_phi_reg_15552.read();
    } else {
        ap_phi_mux_data_84_V_read114_rewind_phi_fu_7660_p6 = data_84_V_read114_rewind_reg_7656.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_85_V_read115_phi_phi_fu_15568_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_85_V_read115_phi_phi_fu_15568_p4 = ap_phi_mux_data_85_V_read115_rewind_phi_fu_7674_p6.read();
    } else {
        ap_phi_mux_data_85_V_read115_phi_phi_fu_15568_p4 = ap_phi_reg_pp0_iter1_data_85_V_read115_phi_reg_15564.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_85_V_read115_rewind_phi_fu_7674_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_85_V_read115_rewind_phi_fu_7674_p6 = data_85_V_read115_phi_reg_15564.read();
    } else {
        ap_phi_mux_data_85_V_read115_rewind_phi_fu_7674_p6 = data_85_V_read115_rewind_reg_7670.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_86_V_read116_phi_phi_fu_15580_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_86_V_read116_phi_phi_fu_15580_p4 = ap_phi_mux_data_86_V_read116_rewind_phi_fu_7688_p6.read();
    } else {
        ap_phi_mux_data_86_V_read116_phi_phi_fu_15580_p4 = ap_phi_reg_pp0_iter1_data_86_V_read116_phi_reg_15576.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_86_V_read116_rewind_phi_fu_7688_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_86_V_read116_rewind_phi_fu_7688_p6 = data_86_V_read116_phi_reg_15576.read();
    } else {
        ap_phi_mux_data_86_V_read116_rewind_phi_fu_7688_p6 = data_86_V_read116_rewind_reg_7684.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_87_V_read117_phi_phi_fu_15592_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_87_V_read117_phi_phi_fu_15592_p4 = ap_phi_mux_data_87_V_read117_rewind_phi_fu_7702_p6.read();
    } else {
        ap_phi_mux_data_87_V_read117_phi_phi_fu_15592_p4 = ap_phi_reg_pp0_iter1_data_87_V_read117_phi_reg_15588.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_87_V_read117_rewind_phi_fu_7702_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_87_V_read117_rewind_phi_fu_7702_p6 = data_87_V_read117_phi_reg_15588.read();
    } else {
        ap_phi_mux_data_87_V_read117_rewind_phi_fu_7702_p6 = data_87_V_read117_rewind_reg_7698.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_88_V_read118_phi_phi_fu_15604_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_88_V_read118_phi_phi_fu_15604_p4 = ap_phi_mux_data_88_V_read118_rewind_phi_fu_7716_p6.read();
    } else {
        ap_phi_mux_data_88_V_read118_phi_phi_fu_15604_p4 = ap_phi_reg_pp0_iter1_data_88_V_read118_phi_reg_15600.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_88_V_read118_rewind_phi_fu_7716_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_88_V_read118_rewind_phi_fu_7716_p6 = data_88_V_read118_phi_reg_15600.read();
    } else {
        ap_phi_mux_data_88_V_read118_rewind_phi_fu_7716_p6 = data_88_V_read118_rewind_reg_7712.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_89_V_read119_phi_phi_fu_15616_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_89_V_read119_phi_phi_fu_15616_p4 = ap_phi_mux_data_89_V_read119_rewind_phi_fu_7730_p6.read();
    } else {
        ap_phi_mux_data_89_V_read119_phi_phi_fu_15616_p4 = ap_phi_reg_pp0_iter1_data_89_V_read119_phi_reg_15612.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_89_V_read119_rewind_phi_fu_7730_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_89_V_read119_rewind_phi_fu_7730_p6 = data_89_V_read119_phi_reg_15612.read();
    } else {
        ap_phi_mux_data_89_V_read119_rewind_phi_fu_7730_p6 = data_89_V_read119_rewind_reg_7726.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_8_V_read38_phi_phi_fu_14644_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_8_V_read38_phi_phi_fu_14644_p4 = ap_phi_mux_data_8_V_read38_rewind_phi_fu_6596_p6.read();
    } else {
        ap_phi_mux_data_8_V_read38_phi_phi_fu_14644_p4 = ap_phi_reg_pp0_iter1_data_8_V_read38_phi_reg_14640.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_8_V_read38_rewind_phi_fu_6596_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_8_V_read38_rewind_phi_fu_6596_p6 = data_8_V_read38_phi_reg_14640.read();
    } else {
        ap_phi_mux_data_8_V_read38_rewind_phi_fu_6596_p6 = data_8_V_read38_rewind_reg_6592.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_90_V_read120_phi_phi_fu_15628_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_90_V_read120_phi_phi_fu_15628_p4 = ap_phi_mux_data_90_V_read120_rewind_phi_fu_7744_p6.read();
    } else {
        ap_phi_mux_data_90_V_read120_phi_phi_fu_15628_p4 = ap_phi_reg_pp0_iter1_data_90_V_read120_phi_reg_15624.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_90_V_read120_rewind_phi_fu_7744_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_90_V_read120_rewind_phi_fu_7744_p6 = data_90_V_read120_phi_reg_15624.read();
    } else {
        ap_phi_mux_data_90_V_read120_rewind_phi_fu_7744_p6 = data_90_V_read120_rewind_reg_7740.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_91_V_read121_phi_phi_fu_15640_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_91_V_read121_phi_phi_fu_15640_p4 = ap_phi_mux_data_91_V_read121_rewind_phi_fu_7758_p6.read();
    } else {
        ap_phi_mux_data_91_V_read121_phi_phi_fu_15640_p4 = ap_phi_reg_pp0_iter1_data_91_V_read121_phi_reg_15636.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_91_V_read121_rewind_phi_fu_7758_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_91_V_read121_rewind_phi_fu_7758_p6 = data_91_V_read121_phi_reg_15636.read();
    } else {
        ap_phi_mux_data_91_V_read121_rewind_phi_fu_7758_p6 = data_91_V_read121_rewind_reg_7754.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_92_V_read122_phi_phi_fu_15652_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_92_V_read122_phi_phi_fu_15652_p4 = ap_phi_mux_data_92_V_read122_rewind_phi_fu_7772_p6.read();
    } else {
        ap_phi_mux_data_92_V_read122_phi_phi_fu_15652_p4 = ap_phi_reg_pp0_iter1_data_92_V_read122_phi_reg_15648.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_92_V_read122_rewind_phi_fu_7772_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_92_V_read122_rewind_phi_fu_7772_p6 = data_92_V_read122_phi_reg_15648.read();
    } else {
        ap_phi_mux_data_92_V_read122_rewind_phi_fu_7772_p6 = data_92_V_read122_rewind_reg_7768.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_93_V_read123_phi_phi_fu_15664_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_93_V_read123_phi_phi_fu_15664_p4 = ap_phi_mux_data_93_V_read123_rewind_phi_fu_7786_p6.read();
    } else {
        ap_phi_mux_data_93_V_read123_phi_phi_fu_15664_p4 = ap_phi_reg_pp0_iter1_data_93_V_read123_phi_reg_15660.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_93_V_read123_rewind_phi_fu_7786_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_93_V_read123_rewind_phi_fu_7786_p6 = data_93_V_read123_phi_reg_15660.read();
    } else {
        ap_phi_mux_data_93_V_read123_rewind_phi_fu_7786_p6 = data_93_V_read123_rewind_reg_7782.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_94_V_read124_phi_phi_fu_15676_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_94_V_read124_phi_phi_fu_15676_p4 = ap_phi_mux_data_94_V_read124_rewind_phi_fu_7800_p6.read();
    } else {
        ap_phi_mux_data_94_V_read124_phi_phi_fu_15676_p4 = ap_phi_reg_pp0_iter1_data_94_V_read124_phi_reg_15672.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_94_V_read124_rewind_phi_fu_7800_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_94_V_read124_rewind_phi_fu_7800_p6 = data_94_V_read124_phi_reg_15672.read();
    } else {
        ap_phi_mux_data_94_V_read124_rewind_phi_fu_7800_p6 = data_94_V_read124_rewind_reg_7796.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_95_V_read125_phi_phi_fu_15688_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_95_V_read125_phi_phi_fu_15688_p4 = ap_phi_mux_data_95_V_read125_rewind_phi_fu_7814_p6.read();
    } else {
        ap_phi_mux_data_95_V_read125_phi_phi_fu_15688_p4 = ap_phi_reg_pp0_iter1_data_95_V_read125_phi_reg_15684.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_95_V_read125_rewind_phi_fu_7814_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_95_V_read125_rewind_phi_fu_7814_p6 = data_95_V_read125_phi_reg_15684.read();
    } else {
        ap_phi_mux_data_95_V_read125_rewind_phi_fu_7814_p6 = data_95_V_read125_rewind_reg_7810.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_96_V_read126_phi_phi_fu_15700_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_96_V_read126_phi_phi_fu_15700_p4 = ap_phi_mux_data_96_V_read126_rewind_phi_fu_7828_p6.read();
    } else {
        ap_phi_mux_data_96_V_read126_phi_phi_fu_15700_p4 = ap_phi_reg_pp0_iter1_data_96_V_read126_phi_reg_15696.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_96_V_read126_rewind_phi_fu_7828_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_96_V_read126_rewind_phi_fu_7828_p6 = data_96_V_read126_phi_reg_15696.read();
    } else {
        ap_phi_mux_data_96_V_read126_rewind_phi_fu_7828_p6 = data_96_V_read126_rewind_reg_7824.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_97_V_read127_phi_phi_fu_15712_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_97_V_read127_phi_phi_fu_15712_p4 = ap_phi_mux_data_97_V_read127_rewind_phi_fu_7842_p6.read();
    } else {
        ap_phi_mux_data_97_V_read127_phi_phi_fu_15712_p4 = ap_phi_reg_pp0_iter1_data_97_V_read127_phi_reg_15708.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_97_V_read127_rewind_phi_fu_7842_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_97_V_read127_rewind_phi_fu_7842_p6 = data_97_V_read127_phi_reg_15708.read();
    } else {
        ap_phi_mux_data_97_V_read127_rewind_phi_fu_7842_p6 = data_97_V_read127_rewind_reg_7838.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_98_V_read128_phi_phi_fu_15724_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_98_V_read128_phi_phi_fu_15724_p4 = ap_phi_mux_data_98_V_read128_rewind_phi_fu_7856_p6.read();
    } else {
        ap_phi_mux_data_98_V_read128_phi_phi_fu_15724_p4 = ap_phi_reg_pp0_iter1_data_98_V_read128_phi_reg_15720.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_98_V_read128_rewind_phi_fu_7856_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_98_V_read128_rewind_phi_fu_7856_p6 = data_98_V_read128_phi_reg_15720.read();
    } else {
        ap_phi_mux_data_98_V_read128_rewind_phi_fu_7856_p6 = data_98_V_read128_rewind_reg_7852.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_99_V_read129_phi_phi_fu_15736_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_99_V_read129_phi_phi_fu_15736_p4 = ap_phi_mux_data_99_V_read129_rewind_phi_fu_7870_p6.read();
    } else {
        ap_phi_mux_data_99_V_read129_phi_phi_fu_15736_p4 = ap_phi_reg_pp0_iter1_data_99_V_read129_phi_reg_15732.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_99_V_read129_rewind_phi_fu_7870_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_99_V_read129_rewind_phi_fu_7870_p6 = data_99_V_read129_phi_reg_15732.read();
    } else {
        ap_phi_mux_data_99_V_read129_rewind_phi_fu_7870_p6 = data_99_V_read129_rewind_reg_7866.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_9_V_read39_phi_phi_fu_14656_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_6449.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_9_V_read39_phi_phi_fu_14656_p4 = ap_phi_mux_data_9_V_read39_rewind_phi_fu_6610_p6.read();
    } else {
        ap_phi_mux_data_9_V_read39_phi_phi_fu_14656_p4 = ap_phi_reg_pp0_iter1_data_9_V_read39_phi_reg_14652.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_data_9_V_read39_rewind_phi_fu_6610_p6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(icmp_ln43_reg_43777_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_9_V_read39_rewind_phi_fu_6610_p6 = data_9_V_read39_phi_reg_14652.read();
    } else {
        ap_phi_mux_data_9_V_read39_rewind_phi_fu_6610_p6 = data_9_V_read39_rewind_reg_6606.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_do_init_phi_fu_6453_p6() {
    if (esl_seteq<1,1,1>(ap_condition_6279.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln43_reg_43777.read())) {
            ap_phi_mux_do_init_phi_fu_6453_p6 = ap_const_lv1_1;
        } else if (esl_seteq<1,1,1>(icmp_ln43_reg_43777.read(), ap_const_lv1_0)) {
            ap_phi_mux_do_init_phi_fu_6453_p6 = ap_const_lv1_0;
        } else {
            ap_phi_mux_do_init_phi_fu_6453_p6 = do_init_reg_6449.read();
        }
    } else {
        ap_phi_mux_do_init_phi_fu_6453_p6 = do_init_reg_6449.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_mux_w_index29_phi_fu_6469_p6() {
    if (esl_seteq<1,1,1>(ap_condition_6279.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln43_reg_43777.read())) {
            ap_phi_mux_w_index29_phi_fu_6469_p6 = ap_const_lv4_0;
        } else if (esl_seteq<1,1,1>(icmp_ln43_reg_43777.read(), ap_const_lv1_0)) {
            ap_phi_mux_w_index29_phi_fu_6469_p6 = w_index_reg_43767.read();
        } else {
            ap_phi_mux_w_index29_phi_fu_6469_p6 = w_index29_reg_6465.read();
        }
    } else {
        ap_phi_mux_w_index29_phi_fu_6469_p6 = w_index29_reg_6465.read();
    }
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_0_V_read30_phi_reg_14544() {
    ap_phi_reg_pp0_iter0_data_0_V_read30_phi_reg_14544 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_100_V_read130_phi_reg_15744() {
    ap_phi_reg_pp0_iter0_data_100_V_read130_phi_reg_15744 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_101_V_read131_phi_reg_15756() {
    ap_phi_reg_pp0_iter0_data_101_V_read131_phi_reg_15756 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_102_V_read132_phi_reg_15768() {
    ap_phi_reg_pp0_iter0_data_102_V_read132_phi_reg_15768 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_103_V_read133_phi_reg_15780() {
    ap_phi_reg_pp0_iter0_data_103_V_read133_phi_reg_15780 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_104_V_read134_phi_reg_15792() {
    ap_phi_reg_pp0_iter0_data_104_V_read134_phi_reg_15792 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_105_V_read135_phi_reg_15804() {
    ap_phi_reg_pp0_iter0_data_105_V_read135_phi_reg_15804 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_106_V_read136_phi_reg_15816() {
    ap_phi_reg_pp0_iter0_data_106_V_read136_phi_reg_15816 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_107_V_read137_phi_reg_15828() {
    ap_phi_reg_pp0_iter0_data_107_V_read137_phi_reg_15828 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_108_V_read138_phi_reg_15840() {
    ap_phi_reg_pp0_iter0_data_108_V_read138_phi_reg_15840 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_109_V_read139_phi_reg_15852() {
    ap_phi_reg_pp0_iter0_data_109_V_read139_phi_reg_15852 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_10_V_read40_phi_reg_14664() {
    ap_phi_reg_pp0_iter0_data_10_V_read40_phi_reg_14664 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_110_V_read140_phi_reg_15864() {
    ap_phi_reg_pp0_iter0_data_110_V_read140_phi_reg_15864 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_111_V_read141_phi_reg_15876() {
    ap_phi_reg_pp0_iter0_data_111_V_read141_phi_reg_15876 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_112_V_read142_phi_reg_15888() {
    ap_phi_reg_pp0_iter0_data_112_V_read142_phi_reg_15888 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_113_V_read143_phi_reg_15900() {
    ap_phi_reg_pp0_iter0_data_113_V_read143_phi_reg_15900 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_114_V_read144_phi_reg_15912() {
    ap_phi_reg_pp0_iter0_data_114_V_read144_phi_reg_15912 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_115_V_read145_phi_reg_15924() {
    ap_phi_reg_pp0_iter0_data_115_V_read145_phi_reg_15924 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_116_V_read146_phi_reg_15936() {
    ap_phi_reg_pp0_iter0_data_116_V_read146_phi_reg_15936 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_117_V_read147_phi_reg_15948() {
    ap_phi_reg_pp0_iter0_data_117_V_read147_phi_reg_15948 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_118_V_read148_phi_reg_15960() {
    ap_phi_reg_pp0_iter0_data_118_V_read148_phi_reg_15960 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_119_V_read149_phi_reg_15972() {
    ap_phi_reg_pp0_iter0_data_119_V_read149_phi_reg_15972 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_11_V_read41_phi_reg_14676() {
    ap_phi_reg_pp0_iter0_data_11_V_read41_phi_reg_14676 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_120_V_read150_phi_reg_15984() {
    ap_phi_reg_pp0_iter0_data_120_V_read150_phi_reg_15984 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_121_V_read151_phi_reg_15996() {
    ap_phi_reg_pp0_iter0_data_121_V_read151_phi_reg_15996 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_122_V_read152_phi_reg_16008() {
    ap_phi_reg_pp0_iter0_data_122_V_read152_phi_reg_16008 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_123_V_read153_phi_reg_16020() {
    ap_phi_reg_pp0_iter0_data_123_V_read153_phi_reg_16020 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_124_V_read154_phi_reg_16032() {
    ap_phi_reg_pp0_iter0_data_124_V_read154_phi_reg_16032 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_125_V_read155_phi_reg_16044() {
    ap_phi_reg_pp0_iter0_data_125_V_read155_phi_reg_16044 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_126_V_read156_phi_reg_16056() {
    ap_phi_reg_pp0_iter0_data_126_V_read156_phi_reg_16056 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_127_V_read157_phi_reg_16068() {
    ap_phi_reg_pp0_iter0_data_127_V_read157_phi_reg_16068 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_128_V_read158_phi_reg_16080() {
    ap_phi_reg_pp0_iter0_data_128_V_read158_phi_reg_16080 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_129_V_read159_phi_reg_16092() {
    ap_phi_reg_pp0_iter0_data_129_V_read159_phi_reg_16092 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_12_V_read42_phi_reg_14688() {
    ap_phi_reg_pp0_iter0_data_12_V_read42_phi_reg_14688 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_130_V_read160_phi_reg_16104() {
    ap_phi_reg_pp0_iter0_data_130_V_read160_phi_reg_16104 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_131_V_read161_phi_reg_16116() {
    ap_phi_reg_pp0_iter0_data_131_V_read161_phi_reg_16116 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_132_V_read162_phi_reg_16128() {
    ap_phi_reg_pp0_iter0_data_132_V_read162_phi_reg_16128 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_133_V_read163_phi_reg_16140() {
    ap_phi_reg_pp0_iter0_data_133_V_read163_phi_reg_16140 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_134_V_read164_phi_reg_16152() {
    ap_phi_reg_pp0_iter0_data_134_V_read164_phi_reg_16152 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_135_V_read165_phi_reg_16164() {
    ap_phi_reg_pp0_iter0_data_135_V_read165_phi_reg_16164 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_136_V_read166_phi_reg_16176() {
    ap_phi_reg_pp0_iter0_data_136_V_read166_phi_reg_16176 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_137_V_read167_phi_reg_16188() {
    ap_phi_reg_pp0_iter0_data_137_V_read167_phi_reg_16188 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_138_V_read168_phi_reg_16200() {
    ap_phi_reg_pp0_iter0_data_138_V_read168_phi_reg_16200 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_139_V_read169_phi_reg_16212() {
    ap_phi_reg_pp0_iter0_data_139_V_read169_phi_reg_16212 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_13_V_read43_phi_reg_14700() {
    ap_phi_reg_pp0_iter0_data_13_V_read43_phi_reg_14700 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_140_V_read170_phi_reg_16224() {
    ap_phi_reg_pp0_iter0_data_140_V_read170_phi_reg_16224 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_141_V_read171_phi_reg_16236() {
    ap_phi_reg_pp0_iter0_data_141_V_read171_phi_reg_16236 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_142_V_read172_phi_reg_16248() {
    ap_phi_reg_pp0_iter0_data_142_V_read172_phi_reg_16248 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_143_V_read173_phi_reg_16260() {
    ap_phi_reg_pp0_iter0_data_143_V_read173_phi_reg_16260 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_144_V_read174_phi_reg_16272() {
    ap_phi_reg_pp0_iter0_data_144_V_read174_phi_reg_16272 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_145_V_read175_phi_reg_16284() {
    ap_phi_reg_pp0_iter0_data_145_V_read175_phi_reg_16284 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_146_V_read176_phi_reg_16296() {
    ap_phi_reg_pp0_iter0_data_146_V_read176_phi_reg_16296 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_147_V_read177_phi_reg_16308() {
    ap_phi_reg_pp0_iter0_data_147_V_read177_phi_reg_16308 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_148_V_read178_phi_reg_16320() {
    ap_phi_reg_pp0_iter0_data_148_V_read178_phi_reg_16320 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_149_V_read179_phi_reg_16332() {
    ap_phi_reg_pp0_iter0_data_149_V_read179_phi_reg_16332 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_14_V_read44_phi_reg_14712() {
    ap_phi_reg_pp0_iter0_data_14_V_read44_phi_reg_14712 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_150_V_read180_phi_reg_16344() {
    ap_phi_reg_pp0_iter0_data_150_V_read180_phi_reg_16344 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_151_V_read181_phi_reg_16356() {
    ap_phi_reg_pp0_iter0_data_151_V_read181_phi_reg_16356 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_152_V_read182_phi_reg_16368() {
    ap_phi_reg_pp0_iter0_data_152_V_read182_phi_reg_16368 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_153_V_read183_phi_reg_16380() {
    ap_phi_reg_pp0_iter0_data_153_V_read183_phi_reg_16380 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_154_V_read184_phi_reg_16392() {
    ap_phi_reg_pp0_iter0_data_154_V_read184_phi_reg_16392 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_155_V_read185_phi_reg_16404() {
    ap_phi_reg_pp0_iter0_data_155_V_read185_phi_reg_16404 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_156_V_read186_phi_reg_16416() {
    ap_phi_reg_pp0_iter0_data_156_V_read186_phi_reg_16416 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_157_V_read187_phi_reg_16428() {
    ap_phi_reg_pp0_iter0_data_157_V_read187_phi_reg_16428 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_158_V_read188_phi_reg_16440() {
    ap_phi_reg_pp0_iter0_data_158_V_read188_phi_reg_16440 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_159_V_read189_phi_reg_16452() {
    ap_phi_reg_pp0_iter0_data_159_V_read189_phi_reg_16452 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_15_V_read45_phi_reg_14724() {
    ap_phi_reg_pp0_iter0_data_15_V_read45_phi_reg_14724 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_160_V_read190_phi_reg_16464() {
    ap_phi_reg_pp0_iter0_data_160_V_read190_phi_reg_16464 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_161_V_read191_phi_reg_16476() {
    ap_phi_reg_pp0_iter0_data_161_V_read191_phi_reg_16476 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_162_V_read192_phi_reg_16488() {
    ap_phi_reg_pp0_iter0_data_162_V_read192_phi_reg_16488 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_163_V_read193_phi_reg_16500() {
    ap_phi_reg_pp0_iter0_data_163_V_read193_phi_reg_16500 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_164_V_read194_phi_reg_16512() {
    ap_phi_reg_pp0_iter0_data_164_V_read194_phi_reg_16512 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_165_V_read195_phi_reg_16524() {
    ap_phi_reg_pp0_iter0_data_165_V_read195_phi_reg_16524 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_166_V_read196_phi_reg_16536() {
    ap_phi_reg_pp0_iter0_data_166_V_read196_phi_reg_16536 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_167_V_read197_phi_reg_16548() {
    ap_phi_reg_pp0_iter0_data_167_V_read197_phi_reg_16548 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_168_V_read198_phi_reg_16560() {
    ap_phi_reg_pp0_iter0_data_168_V_read198_phi_reg_16560 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_169_V_read199_phi_reg_16572() {
    ap_phi_reg_pp0_iter0_data_169_V_read199_phi_reg_16572 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_16_V_read46_phi_reg_14736() {
    ap_phi_reg_pp0_iter0_data_16_V_read46_phi_reg_14736 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_170_V_read200_phi_reg_16584() {
    ap_phi_reg_pp0_iter0_data_170_V_read200_phi_reg_16584 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_171_V_read201_phi_reg_16596() {
    ap_phi_reg_pp0_iter0_data_171_V_read201_phi_reg_16596 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_172_V_read202_phi_reg_16608() {
    ap_phi_reg_pp0_iter0_data_172_V_read202_phi_reg_16608 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_173_V_read203_phi_reg_16620() {
    ap_phi_reg_pp0_iter0_data_173_V_read203_phi_reg_16620 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_174_V_read204_phi_reg_16632() {
    ap_phi_reg_pp0_iter0_data_174_V_read204_phi_reg_16632 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_175_V_read205_phi_reg_16644() {
    ap_phi_reg_pp0_iter0_data_175_V_read205_phi_reg_16644 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_176_V_read206_phi_reg_16656() {
    ap_phi_reg_pp0_iter0_data_176_V_read206_phi_reg_16656 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_177_V_read207_phi_reg_16668() {
    ap_phi_reg_pp0_iter0_data_177_V_read207_phi_reg_16668 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_178_V_read208_phi_reg_16680() {
    ap_phi_reg_pp0_iter0_data_178_V_read208_phi_reg_16680 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_179_V_read209_phi_reg_16692() {
    ap_phi_reg_pp0_iter0_data_179_V_read209_phi_reg_16692 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_17_V_read47_phi_reg_14748() {
    ap_phi_reg_pp0_iter0_data_17_V_read47_phi_reg_14748 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_180_V_read210_phi_reg_16704() {
    ap_phi_reg_pp0_iter0_data_180_V_read210_phi_reg_16704 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_181_V_read211_phi_reg_16716() {
    ap_phi_reg_pp0_iter0_data_181_V_read211_phi_reg_16716 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_182_V_read212_phi_reg_16728() {
    ap_phi_reg_pp0_iter0_data_182_V_read212_phi_reg_16728 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_183_V_read213_phi_reg_16740() {
    ap_phi_reg_pp0_iter0_data_183_V_read213_phi_reg_16740 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_184_V_read214_phi_reg_16752() {
    ap_phi_reg_pp0_iter0_data_184_V_read214_phi_reg_16752 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_185_V_read215_phi_reg_16764() {
    ap_phi_reg_pp0_iter0_data_185_V_read215_phi_reg_16764 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_186_V_read216_phi_reg_16776() {
    ap_phi_reg_pp0_iter0_data_186_V_read216_phi_reg_16776 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_187_V_read217_phi_reg_16788() {
    ap_phi_reg_pp0_iter0_data_187_V_read217_phi_reg_16788 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_188_V_read218_phi_reg_16800() {
    ap_phi_reg_pp0_iter0_data_188_V_read218_phi_reg_16800 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_189_V_read219_phi_reg_16812() {
    ap_phi_reg_pp0_iter0_data_189_V_read219_phi_reg_16812 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_18_V_read48_phi_reg_14760() {
    ap_phi_reg_pp0_iter0_data_18_V_read48_phi_reg_14760 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_190_V_read220_phi_reg_16824() {
    ap_phi_reg_pp0_iter0_data_190_V_read220_phi_reg_16824 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_191_V_read221_phi_reg_16836() {
    ap_phi_reg_pp0_iter0_data_191_V_read221_phi_reg_16836 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_192_V_read222_phi_reg_16848() {
    ap_phi_reg_pp0_iter0_data_192_V_read222_phi_reg_16848 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_193_V_read223_phi_reg_16860() {
    ap_phi_reg_pp0_iter0_data_193_V_read223_phi_reg_16860 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_194_V_read224_phi_reg_16872() {
    ap_phi_reg_pp0_iter0_data_194_V_read224_phi_reg_16872 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_195_V_read225_phi_reg_16884() {
    ap_phi_reg_pp0_iter0_data_195_V_read225_phi_reg_16884 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_196_V_read226_phi_reg_16896() {
    ap_phi_reg_pp0_iter0_data_196_V_read226_phi_reg_16896 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_197_V_read227_phi_reg_16908() {
    ap_phi_reg_pp0_iter0_data_197_V_read227_phi_reg_16908 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_198_V_read228_phi_reg_16920() {
    ap_phi_reg_pp0_iter0_data_198_V_read228_phi_reg_16920 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_199_V_read229_phi_reg_16932() {
    ap_phi_reg_pp0_iter0_data_199_V_read229_phi_reg_16932 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_19_V_read49_phi_reg_14772() {
    ap_phi_reg_pp0_iter0_data_19_V_read49_phi_reg_14772 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_1_V_read31_phi_reg_14556() {
    ap_phi_reg_pp0_iter0_data_1_V_read31_phi_reg_14556 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_200_V_read230_phi_reg_16944() {
    ap_phi_reg_pp0_iter0_data_200_V_read230_phi_reg_16944 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_201_V_read231_phi_reg_16956() {
    ap_phi_reg_pp0_iter0_data_201_V_read231_phi_reg_16956 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_202_V_read232_phi_reg_16968() {
    ap_phi_reg_pp0_iter0_data_202_V_read232_phi_reg_16968 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_203_V_read233_phi_reg_16980() {
    ap_phi_reg_pp0_iter0_data_203_V_read233_phi_reg_16980 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_204_V_read234_phi_reg_16992() {
    ap_phi_reg_pp0_iter0_data_204_V_read234_phi_reg_16992 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_205_V_read235_phi_reg_17004() {
    ap_phi_reg_pp0_iter0_data_205_V_read235_phi_reg_17004 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_206_V_read236_phi_reg_17016() {
    ap_phi_reg_pp0_iter0_data_206_V_read236_phi_reg_17016 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_207_V_read237_phi_reg_17028() {
    ap_phi_reg_pp0_iter0_data_207_V_read237_phi_reg_17028 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_208_V_read238_phi_reg_17040() {
    ap_phi_reg_pp0_iter0_data_208_V_read238_phi_reg_17040 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_209_V_read239_phi_reg_17052() {
    ap_phi_reg_pp0_iter0_data_209_V_read239_phi_reg_17052 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_20_V_read50_phi_reg_14784() {
    ap_phi_reg_pp0_iter0_data_20_V_read50_phi_reg_14784 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_210_V_read240_phi_reg_17064() {
    ap_phi_reg_pp0_iter0_data_210_V_read240_phi_reg_17064 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_211_V_read241_phi_reg_17076() {
    ap_phi_reg_pp0_iter0_data_211_V_read241_phi_reg_17076 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_212_V_read242_phi_reg_17088() {
    ap_phi_reg_pp0_iter0_data_212_V_read242_phi_reg_17088 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_213_V_read243_phi_reg_17100() {
    ap_phi_reg_pp0_iter0_data_213_V_read243_phi_reg_17100 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_214_V_read244_phi_reg_17112() {
    ap_phi_reg_pp0_iter0_data_214_V_read244_phi_reg_17112 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_215_V_read245_phi_reg_17124() {
    ap_phi_reg_pp0_iter0_data_215_V_read245_phi_reg_17124 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_216_V_read246_phi_reg_17136() {
    ap_phi_reg_pp0_iter0_data_216_V_read246_phi_reg_17136 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_217_V_read247_phi_reg_17148() {
    ap_phi_reg_pp0_iter0_data_217_V_read247_phi_reg_17148 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_218_V_read248_phi_reg_17160() {
    ap_phi_reg_pp0_iter0_data_218_V_read248_phi_reg_17160 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_219_V_read249_phi_reg_17172() {
    ap_phi_reg_pp0_iter0_data_219_V_read249_phi_reg_17172 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_21_V_read51_phi_reg_14796() {
    ap_phi_reg_pp0_iter0_data_21_V_read51_phi_reg_14796 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_220_V_read250_phi_reg_17184() {
    ap_phi_reg_pp0_iter0_data_220_V_read250_phi_reg_17184 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_221_V_read251_phi_reg_17196() {
    ap_phi_reg_pp0_iter0_data_221_V_read251_phi_reg_17196 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_222_V_read252_phi_reg_17208() {
    ap_phi_reg_pp0_iter0_data_222_V_read252_phi_reg_17208 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_223_V_read253_phi_reg_17220() {
    ap_phi_reg_pp0_iter0_data_223_V_read253_phi_reg_17220 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_224_V_read254_phi_reg_17232() {
    ap_phi_reg_pp0_iter0_data_224_V_read254_phi_reg_17232 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_225_V_read255_phi_reg_17244() {
    ap_phi_reg_pp0_iter0_data_225_V_read255_phi_reg_17244 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_226_V_read256_phi_reg_17256() {
    ap_phi_reg_pp0_iter0_data_226_V_read256_phi_reg_17256 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_227_V_read257_phi_reg_17268() {
    ap_phi_reg_pp0_iter0_data_227_V_read257_phi_reg_17268 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_228_V_read258_phi_reg_17280() {
    ap_phi_reg_pp0_iter0_data_228_V_read258_phi_reg_17280 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_229_V_read259_phi_reg_17292() {
    ap_phi_reg_pp0_iter0_data_229_V_read259_phi_reg_17292 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_22_V_read52_phi_reg_14808() {
    ap_phi_reg_pp0_iter0_data_22_V_read52_phi_reg_14808 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_230_V_read260_phi_reg_17304() {
    ap_phi_reg_pp0_iter0_data_230_V_read260_phi_reg_17304 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_231_V_read261_phi_reg_17316() {
    ap_phi_reg_pp0_iter0_data_231_V_read261_phi_reg_17316 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_232_V_read262_phi_reg_17328() {
    ap_phi_reg_pp0_iter0_data_232_V_read262_phi_reg_17328 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_233_V_read263_phi_reg_17340() {
    ap_phi_reg_pp0_iter0_data_233_V_read263_phi_reg_17340 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_234_V_read264_phi_reg_17352() {
    ap_phi_reg_pp0_iter0_data_234_V_read264_phi_reg_17352 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_235_V_read265_phi_reg_17364() {
    ap_phi_reg_pp0_iter0_data_235_V_read265_phi_reg_17364 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_236_V_read266_phi_reg_17376() {
    ap_phi_reg_pp0_iter0_data_236_V_read266_phi_reg_17376 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_237_V_read267_phi_reg_17388() {
    ap_phi_reg_pp0_iter0_data_237_V_read267_phi_reg_17388 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_238_V_read268_phi_reg_17400() {
    ap_phi_reg_pp0_iter0_data_238_V_read268_phi_reg_17400 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_239_V_read269_phi_reg_17412() {
    ap_phi_reg_pp0_iter0_data_239_V_read269_phi_reg_17412 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_23_V_read53_phi_reg_14820() {
    ap_phi_reg_pp0_iter0_data_23_V_read53_phi_reg_14820 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_240_V_read270_phi_reg_17424() {
    ap_phi_reg_pp0_iter0_data_240_V_read270_phi_reg_17424 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_241_V_read271_phi_reg_17436() {
    ap_phi_reg_pp0_iter0_data_241_V_read271_phi_reg_17436 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_242_V_read272_phi_reg_17448() {
    ap_phi_reg_pp0_iter0_data_242_V_read272_phi_reg_17448 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_243_V_read273_phi_reg_17460() {
    ap_phi_reg_pp0_iter0_data_243_V_read273_phi_reg_17460 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_244_V_read274_phi_reg_17472() {
    ap_phi_reg_pp0_iter0_data_244_V_read274_phi_reg_17472 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_245_V_read275_phi_reg_17484() {
    ap_phi_reg_pp0_iter0_data_245_V_read275_phi_reg_17484 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_246_V_read276_phi_reg_17496() {
    ap_phi_reg_pp0_iter0_data_246_V_read276_phi_reg_17496 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_247_V_read277_phi_reg_17508() {
    ap_phi_reg_pp0_iter0_data_247_V_read277_phi_reg_17508 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_248_V_read278_phi_reg_17520() {
    ap_phi_reg_pp0_iter0_data_248_V_read278_phi_reg_17520 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_249_V_read279_phi_reg_17532() {
    ap_phi_reg_pp0_iter0_data_249_V_read279_phi_reg_17532 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_24_V_read54_phi_reg_14832() {
    ap_phi_reg_pp0_iter0_data_24_V_read54_phi_reg_14832 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_250_V_read280_phi_reg_17544() {
    ap_phi_reg_pp0_iter0_data_250_V_read280_phi_reg_17544 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_251_V_read281_phi_reg_17556() {
    ap_phi_reg_pp0_iter0_data_251_V_read281_phi_reg_17556 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_252_V_read282_phi_reg_17568() {
    ap_phi_reg_pp0_iter0_data_252_V_read282_phi_reg_17568 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_253_V_read283_phi_reg_17580() {
    ap_phi_reg_pp0_iter0_data_253_V_read283_phi_reg_17580 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_254_V_read284_phi_reg_17592() {
    ap_phi_reg_pp0_iter0_data_254_V_read284_phi_reg_17592 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_255_V_read285_phi_reg_17604() {
    ap_phi_reg_pp0_iter0_data_255_V_read285_phi_reg_17604 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_256_V_read286_phi_reg_17616() {
    ap_phi_reg_pp0_iter0_data_256_V_read286_phi_reg_17616 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_257_V_read287_phi_reg_17628() {
    ap_phi_reg_pp0_iter0_data_257_V_read287_phi_reg_17628 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_258_V_read288_phi_reg_17640() {
    ap_phi_reg_pp0_iter0_data_258_V_read288_phi_reg_17640 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_259_V_read289_phi_reg_17652() {
    ap_phi_reg_pp0_iter0_data_259_V_read289_phi_reg_17652 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_25_V_read55_phi_reg_14844() {
    ap_phi_reg_pp0_iter0_data_25_V_read55_phi_reg_14844 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_260_V_read290_phi_reg_17664() {
    ap_phi_reg_pp0_iter0_data_260_V_read290_phi_reg_17664 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_261_V_read291_phi_reg_17676() {
    ap_phi_reg_pp0_iter0_data_261_V_read291_phi_reg_17676 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_262_V_read292_phi_reg_17688() {
    ap_phi_reg_pp0_iter0_data_262_V_read292_phi_reg_17688 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_263_V_read293_phi_reg_17700() {
    ap_phi_reg_pp0_iter0_data_263_V_read293_phi_reg_17700 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_264_V_read294_phi_reg_17712() {
    ap_phi_reg_pp0_iter0_data_264_V_read294_phi_reg_17712 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_265_V_read295_phi_reg_17724() {
    ap_phi_reg_pp0_iter0_data_265_V_read295_phi_reg_17724 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_266_V_read296_phi_reg_17736() {
    ap_phi_reg_pp0_iter0_data_266_V_read296_phi_reg_17736 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_267_V_read297_phi_reg_17748() {
    ap_phi_reg_pp0_iter0_data_267_V_read297_phi_reg_17748 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_268_V_read298_phi_reg_17760() {
    ap_phi_reg_pp0_iter0_data_268_V_read298_phi_reg_17760 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_269_V_read299_phi_reg_17772() {
    ap_phi_reg_pp0_iter0_data_269_V_read299_phi_reg_17772 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_26_V_read56_phi_reg_14856() {
    ap_phi_reg_pp0_iter0_data_26_V_read56_phi_reg_14856 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_270_V_read300_phi_reg_17784() {
    ap_phi_reg_pp0_iter0_data_270_V_read300_phi_reg_17784 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_271_V_read301_phi_reg_17796() {
    ap_phi_reg_pp0_iter0_data_271_V_read301_phi_reg_17796 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_272_V_read302_phi_reg_17808() {
    ap_phi_reg_pp0_iter0_data_272_V_read302_phi_reg_17808 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_273_V_read303_phi_reg_17820() {
    ap_phi_reg_pp0_iter0_data_273_V_read303_phi_reg_17820 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_274_V_read304_phi_reg_17832() {
    ap_phi_reg_pp0_iter0_data_274_V_read304_phi_reg_17832 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_275_V_read305_phi_reg_17844() {
    ap_phi_reg_pp0_iter0_data_275_V_read305_phi_reg_17844 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_276_V_read306_phi_reg_17856() {
    ap_phi_reg_pp0_iter0_data_276_V_read306_phi_reg_17856 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_277_V_read307_phi_reg_17868() {
    ap_phi_reg_pp0_iter0_data_277_V_read307_phi_reg_17868 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_278_V_read308_phi_reg_17880() {
    ap_phi_reg_pp0_iter0_data_278_V_read308_phi_reg_17880 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_279_V_read309_phi_reg_17892() {
    ap_phi_reg_pp0_iter0_data_279_V_read309_phi_reg_17892 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_27_V_read57_phi_reg_14868() {
    ap_phi_reg_pp0_iter0_data_27_V_read57_phi_reg_14868 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_280_V_read310_phi_reg_17904() {
    ap_phi_reg_pp0_iter0_data_280_V_read310_phi_reg_17904 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_281_V_read311_phi_reg_17916() {
    ap_phi_reg_pp0_iter0_data_281_V_read311_phi_reg_17916 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_282_V_read312_phi_reg_17928() {
    ap_phi_reg_pp0_iter0_data_282_V_read312_phi_reg_17928 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_283_V_read313_phi_reg_17940() {
    ap_phi_reg_pp0_iter0_data_283_V_read313_phi_reg_17940 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_284_V_read314_phi_reg_17952() {
    ap_phi_reg_pp0_iter0_data_284_V_read314_phi_reg_17952 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_285_V_read315_phi_reg_17964() {
    ap_phi_reg_pp0_iter0_data_285_V_read315_phi_reg_17964 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_286_V_read316_phi_reg_17976() {
    ap_phi_reg_pp0_iter0_data_286_V_read316_phi_reg_17976 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_287_V_read317_phi_reg_17988() {
    ap_phi_reg_pp0_iter0_data_287_V_read317_phi_reg_17988 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_288_V_read318_phi_reg_18000() {
    ap_phi_reg_pp0_iter0_data_288_V_read318_phi_reg_18000 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_289_V_read319_phi_reg_18012() {
    ap_phi_reg_pp0_iter0_data_289_V_read319_phi_reg_18012 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_28_V_read58_phi_reg_14880() {
    ap_phi_reg_pp0_iter0_data_28_V_read58_phi_reg_14880 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_290_V_read320_phi_reg_18024() {
    ap_phi_reg_pp0_iter0_data_290_V_read320_phi_reg_18024 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_291_V_read321_phi_reg_18036() {
    ap_phi_reg_pp0_iter0_data_291_V_read321_phi_reg_18036 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_292_V_read322_phi_reg_18048() {
    ap_phi_reg_pp0_iter0_data_292_V_read322_phi_reg_18048 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_293_V_read323_phi_reg_18060() {
    ap_phi_reg_pp0_iter0_data_293_V_read323_phi_reg_18060 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_294_V_read324_phi_reg_18072() {
    ap_phi_reg_pp0_iter0_data_294_V_read324_phi_reg_18072 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_295_V_read325_phi_reg_18084() {
    ap_phi_reg_pp0_iter0_data_295_V_read325_phi_reg_18084 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_296_V_read326_phi_reg_18096() {
    ap_phi_reg_pp0_iter0_data_296_V_read326_phi_reg_18096 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_297_V_read327_phi_reg_18108() {
    ap_phi_reg_pp0_iter0_data_297_V_read327_phi_reg_18108 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_298_V_read328_phi_reg_18120() {
    ap_phi_reg_pp0_iter0_data_298_V_read328_phi_reg_18120 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_299_V_read329_phi_reg_18132() {
    ap_phi_reg_pp0_iter0_data_299_V_read329_phi_reg_18132 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_29_V_read59_phi_reg_14892() {
    ap_phi_reg_pp0_iter0_data_29_V_read59_phi_reg_14892 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_2_V_read32_phi_reg_14568() {
    ap_phi_reg_pp0_iter0_data_2_V_read32_phi_reg_14568 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_300_V_read330_phi_reg_18144() {
    ap_phi_reg_pp0_iter0_data_300_V_read330_phi_reg_18144 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_301_V_read331_phi_reg_18156() {
    ap_phi_reg_pp0_iter0_data_301_V_read331_phi_reg_18156 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_302_V_read332_phi_reg_18168() {
    ap_phi_reg_pp0_iter0_data_302_V_read332_phi_reg_18168 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_303_V_read333_phi_reg_18180() {
    ap_phi_reg_pp0_iter0_data_303_V_read333_phi_reg_18180 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_304_V_read334_phi_reg_18192() {
    ap_phi_reg_pp0_iter0_data_304_V_read334_phi_reg_18192 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_305_V_read335_phi_reg_18204() {
    ap_phi_reg_pp0_iter0_data_305_V_read335_phi_reg_18204 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_306_V_read336_phi_reg_18216() {
    ap_phi_reg_pp0_iter0_data_306_V_read336_phi_reg_18216 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_307_V_read337_phi_reg_18228() {
    ap_phi_reg_pp0_iter0_data_307_V_read337_phi_reg_18228 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_308_V_read338_phi_reg_18240() {
    ap_phi_reg_pp0_iter0_data_308_V_read338_phi_reg_18240 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_309_V_read339_phi_reg_18252() {
    ap_phi_reg_pp0_iter0_data_309_V_read339_phi_reg_18252 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_30_V_read60_phi_reg_14904() {
    ap_phi_reg_pp0_iter0_data_30_V_read60_phi_reg_14904 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_310_V_read340_phi_reg_18264() {
    ap_phi_reg_pp0_iter0_data_310_V_read340_phi_reg_18264 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_311_V_read341_phi_reg_18276() {
    ap_phi_reg_pp0_iter0_data_311_V_read341_phi_reg_18276 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_312_V_read342_phi_reg_18288() {
    ap_phi_reg_pp0_iter0_data_312_V_read342_phi_reg_18288 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_313_V_read343_phi_reg_18300() {
    ap_phi_reg_pp0_iter0_data_313_V_read343_phi_reg_18300 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_314_V_read344_phi_reg_18312() {
    ap_phi_reg_pp0_iter0_data_314_V_read344_phi_reg_18312 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_315_V_read345_phi_reg_18324() {
    ap_phi_reg_pp0_iter0_data_315_V_read345_phi_reg_18324 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_316_V_read346_phi_reg_18336() {
    ap_phi_reg_pp0_iter0_data_316_V_read346_phi_reg_18336 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_317_V_read347_phi_reg_18348() {
    ap_phi_reg_pp0_iter0_data_317_V_read347_phi_reg_18348 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_318_V_read348_phi_reg_18360() {
    ap_phi_reg_pp0_iter0_data_318_V_read348_phi_reg_18360 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_319_V_read349_phi_reg_18372() {
    ap_phi_reg_pp0_iter0_data_319_V_read349_phi_reg_18372 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_31_V_read61_phi_reg_14916() {
    ap_phi_reg_pp0_iter0_data_31_V_read61_phi_reg_14916 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_320_V_read350_phi_reg_18384() {
    ap_phi_reg_pp0_iter0_data_320_V_read350_phi_reg_18384 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_321_V_read351_phi_reg_18396() {
    ap_phi_reg_pp0_iter0_data_321_V_read351_phi_reg_18396 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_322_V_read352_phi_reg_18408() {
    ap_phi_reg_pp0_iter0_data_322_V_read352_phi_reg_18408 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_323_V_read353_phi_reg_18420() {
    ap_phi_reg_pp0_iter0_data_323_V_read353_phi_reg_18420 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_324_V_read354_phi_reg_18432() {
    ap_phi_reg_pp0_iter0_data_324_V_read354_phi_reg_18432 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_325_V_read355_phi_reg_18444() {
    ap_phi_reg_pp0_iter0_data_325_V_read355_phi_reg_18444 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_326_V_read356_phi_reg_18456() {
    ap_phi_reg_pp0_iter0_data_326_V_read356_phi_reg_18456 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_327_V_read357_phi_reg_18468() {
    ap_phi_reg_pp0_iter0_data_327_V_read357_phi_reg_18468 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_328_V_read358_phi_reg_18480() {
    ap_phi_reg_pp0_iter0_data_328_V_read358_phi_reg_18480 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_329_V_read359_phi_reg_18492() {
    ap_phi_reg_pp0_iter0_data_329_V_read359_phi_reg_18492 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_32_V_read62_phi_reg_14928() {
    ap_phi_reg_pp0_iter0_data_32_V_read62_phi_reg_14928 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_330_V_read360_phi_reg_18504() {
    ap_phi_reg_pp0_iter0_data_330_V_read360_phi_reg_18504 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_331_V_read361_phi_reg_18516() {
    ap_phi_reg_pp0_iter0_data_331_V_read361_phi_reg_18516 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_332_V_read362_phi_reg_18528() {
    ap_phi_reg_pp0_iter0_data_332_V_read362_phi_reg_18528 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_333_V_read363_phi_reg_18540() {
    ap_phi_reg_pp0_iter0_data_333_V_read363_phi_reg_18540 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_334_V_read364_phi_reg_18552() {
    ap_phi_reg_pp0_iter0_data_334_V_read364_phi_reg_18552 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_335_V_read365_phi_reg_18564() {
    ap_phi_reg_pp0_iter0_data_335_V_read365_phi_reg_18564 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_336_V_read366_phi_reg_18576() {
    ap_phi_reg_pp0_iter0_data_336_V_read366_phi_reg_18576 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_337_V_read367_phi_reg_18588() {
    ap_phi_reg_pp0_iter0_data_337_V_read367_phi_reg_18588 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_338_V_read368_phi_reg_18600() {
    ap_phi_reg_pp0_iter0_data_338_V_read368_phi_reg_18600 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_339_V_read369_phi_reg_18612() {
    ap_phi_reg_pp0_iter0_data_339_V_read369_phi_reg_18612 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_33_V_read63_phi_reg_14940() {
    ap_phi_reg_pp0_iter0_data_33_V_read63_phi_reg_14940 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_340_V_read370_phi_reg_18624() {
    ap_phi_reg_pp0_iter0_data_340_V_read370_phi_reg_18624 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_341_V_read371_phi_reg_18636() {
    ap_phi_reg_pp0_iter0_data_341_V_read371_phi_reg_18636 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_342_V_read372_phi_reg_18648() {
    ap_phi_reg_pp0_iter0_data_342_V_read372_phi_reg_18648 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_343_V_read373_phi_reg_18660() {
    ap_phi_reg_pp0_iter0_data_343_V_read373_phi_reg_18660 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_344_V_read374_phi_reg_18672() {
    ap_phi_reg_pp0_iter0_data_344_V_read374_phi_reg_18672 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_345_V_read375_phi_reg_18684() {
    ap_phi_reg_pp0_iter0_data_345_V_read375_phi_reg_18684 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_346_V_read376_phi_reg_18696() {
    ap_phi_reg_pp0_iter0_data_346_V_read376_phi_reg_18696 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_347_V_read377_phi_reg_18708() {
    ap_phi_reg_pp0_iter0_data_347_V_read377_phi_reg_18708 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_348_V_read378_phi_reg_18720() {
    ap_phi_reg_pp0_iter0_data_348_V_read378_phi_reg_18720 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_349_V_read379_phi_reg_18732() {
    ap_phi_reg_pp0_iter0_data_349_V_read379_phi_reg_18732 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_34_V_read64_phi_reg_14952() {
    ap_phi_reg_pp0_iter0_data_34_V_read64_phi_reg_14952 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_350_V_read380_phi_reg_18744() {
    ap_phi_reg_pp0_iter0_data_350_V_read380_phi_reg_18744 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_351_V_read381_phi_reg_18756() {
    ap_phi_reg_pp0_iter0_data_351_V_read381_phi_reg_18756 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_352_V_read382_phi_reg_18768() {
    ap_phi_reg_pp0_iter0_data_352_V_read382_phi_reg_18768 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_353_V_read383_phi_reg_18780() {
    ap_phi_reg_pp0_iter0_data_353_V_read383_phi_reg_18780 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_354_V_read384_phi_reg_18792() {
    ap_phi_reg_pp0_iter0_data_354_V_read384_phi_reg_18792 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_355_V_read385_phi_reg_18804() {
    ap_phi_reg_pp0_iter0_data_355_V_read385_phi_reg_18804 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_356_V_read386_phi_reg_18816() {
    ap_phi_reg_pp0_iter0_data_356_V_read386_phi_reg_18816 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_357_V_read387_phi_reg_18828() {
    ap_phi_reg_pp0_iter0_data_357_V_read387_phi_reg_18828 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_358_V_read388_phi_reg_18840() {
    ap_phi_reg_pp0_iter0_data_358_V_read388_phi_reg_18840 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_359_V_read389_phi_reg_18852() {
    ap_phi_reg_pp0_iter0_data_359_V_read389_phi_reg_18852 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_35_V_read65_phi_reg_14964() {
    ap_phi_reg_pp0_iter0_data_35_V_read65_phi_reg_14964 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_360_V_read390_phi_reg_18864() {
    ap_phi_reg_pp0_iter0_data_360_V_read390_phi_reg_18864 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_361_V_read391_phi_reg_18876() {
    ap_phi_reg_pp0_iter0_data_361_V_read391_phi_reg_18876 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_362_V_read392_phi_reg_18888() {
    ap_phi_reg_pp0_iter0_data_362_V_read392_phi_reg_18888 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_363_V_read393_phi_reg_18900() {
    ap_phi_reg_pp0_iter0_data_363_V_read393_phi_reg_18900 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_364_V_read394_phi_reg_18912() {
    ap_phi_reg_pp0_iter0_data_364_V_read394_phi_reg_18912 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_365_V_read395_phi_reg_18924() {
    ap_phi_reg_pp0_iter0_data_365_V_read395_phi_reg_18924 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_366_V_read396_phi_reg_18936() {
    ap_phi_reg_pp0_iter0_data_366_V_read396_phi_reg_18936 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_367_V_read397_phi_reg_18948() {
    ap_phi_reg_pp0_iter0_data_367_V_read397_phi_reg_18948 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_368_V_read398_phi_reg_18960() {
    ap_phi_reg_pp0_iter0_data_368_V_read398_phi_reg_18960 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_369_V_read399_phi_reg_18972() {
    ap_phi_reg_pp0_iter0_data_369_V_read399_phi_reg_18972 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_36_V_read66_phi_reg_14976() {
    ap_phi_reg_pp0_iter0_data_36_V_read66_phi_reg_14976 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_370_V_read400_phi_reg_18984() {
    ap_phi_reg_pp0_iter0_data_370_V_read400_phi_reg_18984 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_371_V_read401_phi_reg_18996() {
    ap_phi_reg_pp0_iter0_data_371_V_read401_phi_reg_18996 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_372_V_read402_phi_reg_19008() {
    ap_phi_reg_pp0_iter0_data_372_V_read402_phi_reg_19008 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_373_V_read403_phi_reg_19020() {
    ap_phi_reg_pp0_iter0_data_373_V_read403_phi_reg_19020 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_374_V_read404_phi_reg_19032() {
    ap_phi_reg_pp0_iter0_data_374_V_read404_phi_reg_19032 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_375_V_read405_phi_reg_19044() {
    ap_phi_reg_pp0_iter0_data_375_V_read405_phi_reg_19044 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_376_V_read406_phi_reg_19056() {
    ap_phi_reg_pp0_iter0_data_376_V_read406_phi_reg_19056 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_377_V_read407_phi_reg_19068() {
    ap_phi_reg_pp0_iter0_data_377_V_read407_phi_reg_19068 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_378_V_read408_phi_reg_19080() {
    ap_phi_reg_pp0_iter0_data_378_V_read408_phi_reg_19080 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_379_V_read409_phi_reg_19092() {
    ap_phi_reg_pp0_iter0_data_379_V_read409_phi_reg_19092 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_37_V_read67_phi_reg_14988() {
    ap_phi_reg_pp0_iter0_data_37_V_read67_phi_reg_14988 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_380_V_read410_phi_reg_19104() {
    ap_phi_reg_pp0_iter0_data_380_V_read410_phi_reg_19104 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_381_V_read411_phi_reg_19116() {
    ap_phi_reg_pp0_iter0_data_381_V_read411_phi_reg_19116 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_382_V_read412_phi_reg_19128() {
    ap_phi_reg_pp0_iter0_data_382_V_read412_phi_reg_19128 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_383_V_read413_phi_reg_19140() {
    ap_phi_reg_pp0_iter0_data_383_V_read413_phi_reg_19140 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_384_V_read414_phi_reg_19152() {
    ap_phi_reg_pp0_iter0_data_384_V_read414_phi_reg_19152 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_385_V_read415_phi_reg_19164() {
    ap_phi_reg_pp0_iter0_data_385_V_read415_phi_reg_19164 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_386_V_read416_phi_reg_19176() {
    ap_phi_reg_pp0_iter0_data_386_V_read416_phi_reg_19176 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_387_V_read417_phi_reg_19188() {
    ap_phi_reg_pp0_iter0_data_387_V_read417_phi_reg_19188 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_388_V_read418_phi_reg_19200() {
    ap_phi_reg_pp0_iter0_data_388_V_read418_phi_reg_19200 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_389_V_read419_phi_reg_19212() {
    ap_phi_reg_pp0_iter0_data_389_V_read419_phi_reg_19212 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_38_V_read68_phi_reg_15000() {
    ap_phi_reg_pp0_iter0_data_38_V_read68_phi_reg_15000 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_390_V_read420_phi_reg_19224() {
    ap_phi_reg_pp0_iter0_data_390_V_read420_phi_reg_19224 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_391_V_read421_phi_reg_19236() {
    ap_phi_reg_pp0_iter0_data_391_V_read421_phi_reg_19236 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_392_V_read422_phi_reg_19248() {
    ap_phi_reg_pp0_iter0_data_392_V_read422_phi_reg_19248 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_393_V_read423_phi_reg_19260() {
    ap_phi_reg_pp0_iter0_data_393_V_read423_phi_reg_19260 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_394_V_read424_phi_reg_19272() {
    ap_phi_reg_pp0_iter0_data_394_V_read424_phi_reg_19272 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_395_V_read425_phi_reg_19284() {
    ap_phi_reg_pp0_iter0_data_395_V_read425_phi_reg_19284 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_396_V_read426_phi_reg_19296() {
    ap_phi_reg_pp0_iter0_data_396_V_read426_phi_reg_19296 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_397_V_read427_phi_reg_19308() {
    ap_phi_reg_pp0_iter0_data_397_V_read427_phi_reg_19308 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_398_V_read428_phi_reg_19320() {
    ap_phi_reg_pp0_iter0_data_398_V_read428_phi_reg_19320 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_399_V_read429_phi_reg_19332() {
    ap_phi_reg_pp0_iter0_data_399_V_read429_phi_reg_19332 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_39_V_read69_phi_reg_15012() {
    ap_phi_reg_pp0_iter0_data_39_V_read69_phi_reg_15012 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_3_V_read33_phi_reg_14580() {
    ap_phi_reg_pp0_iter0_data_3_V_read33_phi_reg_14580 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_400_V_read430_phi_reg_19344() {
    ap_phi_reg_pp0_iter0_data_400_V_read430_phi_reg_19344 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_401_V_read431_phi_reg_19356() {
    ap_phi_reg_pp0_iter0_data_401_V_read431_phi_reg_19356 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_402_V_read432_phi_reg_19368() {
    ap_phi_reg_pp0_iter0_data_402_V_read432_phi_reg_19368 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_403_V_read433_phi_reg_19380() {
    ap_phi_reg_pp0_iter0_data_403_V_read433_phi_reg_19380 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_404_V_read434_phi_reg_19392() {
    ap_phi_reg_pp0_iter0_data_404_V_read434_phi_reg_19392 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_405_V_read435_phi_reg_19404() {
    ap_phi_reg_pp0_iter0_data_405_V_read435_phi_reg_19404 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_406_V_read436_phi_reg_19416() {
    ap_phi_reg_pp0_iter0_data_406_V_read436_phi_reg_19416 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_407_V_read437_phi_reg_19428() {
    ap_phi_reg_pp0_iter0_data_407_V_read437_phi_reg_19428 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_408_V_read438_phi_reg_19440() {
    ap_phi_reg_pp0_iter0_data_408_V_read438_phi_reg_19440 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_409_V_read439_phi_reg_19452() {
    ap_phi_reg_pp0_iter0_data_409_V_read439_phi_reg_19452 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_40_V_read70_phi_reg_15024() {
    ap_phi_reg_pp0_iter0_data_40_V_read70_phi_reg_15024 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_410_V_read440_phi_reg_19464() {
    ap_phi_reg_pp0_iter0_data_410_V_read440_phi_reg_19464 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_411_V_read441_phi_reg_19476() {
    ap_phi_reg_pp0_iter0_data_411_V_read441_phi_reg_19476 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_412_V_read442_phi_reg_19488() {
    ap_phi_reg_pp0_iter0_data_412_V_read442_phi_reg_19488 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_413_V_read443_phi_reg_19500() {
    ap_phi_reg_pp0_iter0_data_413_V_read443_phi_reg_19500 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_414_V_read444_phi_reg_19512() {
    ap_phi_reg_pp0_iter0_data_414_V_read444_phi_reg_19512 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_415_V_read445_phi_reg_19524() {
    ap_phi_reg_pp0_iter0_data_415_V_read445_phi_reg_19524 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_416_V_read446_phi_reg_19536() {
    ap_phi_reg_pp0_iter0_data_416_V_read446_phi_reg_19536 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_417_V_read447_phi_reg_19548() {
    ap_phi_reg_pp0_iter0_data_417_V_read447_phi_reg_19548 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_418_V_read448_phi_reg_19560() {
    ap_phi_reg_pp0_iter0_data_418_V_read448_phi_reg_19560 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_419_V_read449_phi_reg_19572() {
    ap_phi_reg_pp0_iter0_data_419_V_read449_phi_reg_19572 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_41_V_read71_phi_reg_15036() {
    ap_phi_reg_pp0_iter0_data_41_V_read71_phi_reg_15036 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_420_V_read450_phi_reg_19584() {
    ap_phi_reg_pp0_iter0_data_420_V_read450_phi_reg_19584 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_421_V_read451_phi_reg_19596() {
    ap_phi_reg_pp0_iter0_data_421_V_read451_phi_reg_19596 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_422_V_read452_phi_reg_19608() {
    ap_phi_reg_pp0_iter0_data_422_V_read452_phi_reg_19608 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_423_V_read453_phi_reg_19620() {
    ap_phi_reg_pp0_iter0_data_423_V_read453_phi_reg_19620 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_424_V_read454_phi_reg_19632() {
    ap_phi_reg_pp0_iter0_data_424_V_read454_phi_reg_19632 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_425_V_read455_phi_reg_19644() {
    ap_phi_reg_pp0_iter0_data_425_V_read455_phi_reg_19644 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_426_V_read456_phi_reg_19656() {
    ap_phi_reg_pp0_iter0_data_426_V_read456_phi_reg_19656 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_427_V_read457_phi_reg_19668() {
    ap_phi_reg_pp0_iter0_data_427_V_read457_phi_reg_19668 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_428_V_read458_phi_reg_19680() {
    ap_phi_reg_pp0_iter0_data_428_V_read458_phi_reg_19680 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_429_V_read459_phi_reg_19692() {
    ap_phi_reg_pp0_iter0_data_429_V_read459_phi_reg_19692 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_42_V_read72_phi_reg_15048() {
    ap_phi_reg_pp0_iter0_data_42_V_read72_phi_reg_15048 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_430_V_read460_phi_reg_19704() {
    ap_phi_reg_pp0_iter0_data_430_V_read460_phi_reg_19704 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_431_V_read461_phi_reg_19716() {
    ap_phi_reg_pp0_iter0_data_431_V_read461_phi_reg_19716 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_432_V_read462_phi_reg_19728() {
    ap_phi_reg_pp0_iter0_data_432_V_read462_phi_reg_19728 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_433_V_read463_phi_reg_19740() {
    ap_phi_reg_pp0_iter0_data_433_V_read463_phi_reg_19740 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_434_V_read464_phi_reg_19752() {
    ap_phi_reg_pp0_iter0_data_434_V_read464_phi_reg_19752 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_435_V_read465_phi_reg_19764() {
    ap_phi_reg_pp0_iter0_data_435_V_read465_phi_reg_19764 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_436_V_read466_phi_reg_19776() {
    ap_phi_reg_pp0_iter0_data_436_V_read466_phi_reg_19776 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_437_V_read467_phi_reg_19788() {
    ap_phi_reg_pp0_iter0_data_437_V_read467_phi_reg_19788 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_438_V_read468_phi_reg_19800() {
    ap_phi_reg_pp0_iter0_data_438_V_read468_phi_reg_19800 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_439_V_read469_phi_reg_19812() {
    ap_phi_reg_pp0_iter0_data_439_V_read469_phi_reg_19812 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_43_V_read73_phi_reg_15060() {
    ap_phi_reg_pp0_iter0_data_43_V_read73_phi_reg_15060 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_440_V_read470_phi_reg_19824() {
    ap_phi_reg_pp0_iter0_data_440_V_read470_phi_reg_19824 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_441_V_read471_phi_reg_19836() {
    ap_phi_reg_pp0_iter0_data_441_V_read471_phi_reg_19836 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_442_V_read472_phi_reg_19848() {
    ap_phi_reg_pp0_iter0_data_442_V_read472_phi_reg_19848 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_443_V_read473_phi_reg_19860() {
    ap_phi_reg_pp0_iter0_data_443_V_read473_phi_reg_19860 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_444_V_read474_phi_reg_19872() {
    ap_phi_reg_pp0_iter0_data_444_V_read474_phi_reg_19872 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_445_V_read475_phi_reg_19884() {
    ap_phi_reg_pp0_iter0_data_445_V_read475_phi_reg_19884 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_446_V_read476_phi_reg_19896() {
    ap_phi_reg_pp0_iter0_data_446_V_read476_phi_reg_19896 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_447_V_read477_phi_reg_19908() {
    ap_phi_reg_pp0_iter0_data_447_V_read477_phi_reg_19908 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_448_V_read478_phi_reg_19920() {
    ap_phi_reg_pp0_iter0_data_448_V_read478_phi_reg_19920 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_449_V_read479_phi_reg_19932() {
    ap_phi_reg_pp0_iter0_data_449_V_read479_phi_reg_19932 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_44_V_read74_phi_reg_15072() {
    ap_phi_reg_pp0_iter0_data_44_V_read74_phi_reg_15072 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_450_V_read480_phi_reg_19944() {
    ap_phi_reg_pp0_iter0_data_450_V_read480_phi_reg_19944 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_451_V_read481_phi_reg_19956() {
    ap_phi_reg_pp0_iter0_data_451_V_read481_phi_reg_19956 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_452_V_read482_phi_reg_19968() {
    ap_phi_reg_pp0_iter0_data_452_V_read482_phi_reg_19968 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_453_V_read483_phi_reg_19980() {
    ap_phi_reg_pp0_iter0_data_453_V_read483_phi_reg_19980 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_16_8_5_3_0_ap_fixed_16_8_5_3_0_config6_s::thread_ap_phi_reg_pp0_iter0_data_454_V_read484_phi_reg_19992() {
    ap_phi_reg_pp0_iter0_data_454_V_read484_phi_reg_19992 =  (sc_lv<16>) ("XXXXXXXXXXXXXXXX");
}

}

