//Numpy array shape [3]
//Min -0.129516601562
//Max 0.191162109375
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[3];
#else
model_default_t b4[3] = {-0.1295166016, 0.1911621094, -0.1252441406};
#endif

#endif
