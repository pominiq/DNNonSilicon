//Numpy array shape [3]
//Min -0.133911132812
//Max 0.107543945312
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
model_default_t b6[3];
#else
model_default_t b6[3] = {-0.1339111328, 0.1075439453, -0.0617370605};
#endif

#endif
