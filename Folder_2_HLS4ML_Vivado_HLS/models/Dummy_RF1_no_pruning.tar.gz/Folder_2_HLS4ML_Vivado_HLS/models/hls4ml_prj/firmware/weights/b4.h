//Numpy array shape [3]
//Min -0.116210937500
//Max 0.138671875000
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[3];
#else
model_default_t b4[3] = {-0.1162109375, 0.1386718750, -0.0966796875};
#endif

#endif
