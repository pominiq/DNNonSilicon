//Numpy array shape [3]
//Min -0.167846679688
//Max 0.168823242188
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[3];
#else
model_default_t b4[3] = {-0.1678466797, 0.1688232422, -0.1042480469};
#endif

#endif
