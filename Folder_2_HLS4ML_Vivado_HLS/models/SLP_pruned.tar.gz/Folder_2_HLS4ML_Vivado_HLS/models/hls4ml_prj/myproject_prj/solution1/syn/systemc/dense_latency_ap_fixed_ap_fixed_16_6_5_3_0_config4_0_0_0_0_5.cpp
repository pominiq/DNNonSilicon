#include "dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_117_fu_29731_p1() {
    tmp_117_fu_29731_p1 =  (sc_lv<22>) (grp_fu_1577_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_117_fu_29731_p4() {
    tmp_117_fu_29731_p4 = tmp_117_fu_29731_p1.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_123_fu_31026_p1() {
    tmp_123_fu_31026_p1 =  (sc_lv<24>) (grp_fu_1596_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_123_fu_31026_p4() {
    tmp_123_fu_31026_p4 = tmp_123_fu_31026_p1.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_125_fu_31094_p4() {
    tmp_125_fu_31094_p4 = sub_ln1118_64_fu_31088_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_13_fu_24815_p4() {
    tmp_13_fu_24815_p4 = sub_ln1118_1_fu_24809_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_15_fu_24886_p4() {
    tmp_15_fu_24886_p4 = sub_ln1118_3_fu_24880_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_17_fu_24972_p4() {
    tmp_17_fu_24972_p4 = sub_ln1118_4_fu_24966_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_1_fu_30601_p3() {
    tmp_1_fu_30601_p3 = esl_concat<16,5>(data_77_V_read_2_reg_33497.read(), ap_const_lv5_0);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_23_fu_25248_p1() {
    tmp_23_fu_25248_p1 =  (sc_lv<23>) (grp_fu_1554_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_23_fu_25248_p4() {
    tmp_23_fu_25248_p4 = tmp_23_fu_25248_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_27_fu_25308_p1() {
    tmp_27_fu_25308_p1 =  (sc_lv<24>) (grp_fu_1590_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_27_fu_25308_p4() {
    tmp_27_fu_25308_p4 = tmp_27_fu_25308_p1.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_29_fu_25344_p1() {
    tmp_29_fu_25344_p1 =  (sc_lv<23>) (grp_fu_1556_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_29_fu_25344_p4() {
    tmp_29_fu_25344_p4 = tmp_29_fu_25344_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_2_fu_31955_p3() {
    tmp_2_fu_31955_p3 = esl_concat<16,3>(data_109_V_read_2_reg_33470.read(), ap_const_lv3_0);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_30_fu_25490_p4() {
    tmp_30_fu_25490_p4 = add_ln1118_2_fu_25484_p2.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_32_fu_25573_p4() {
    tmp_32_fu_25573_p4 = sub_ln1118_11_fu_25567_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_34_fu_25639_p4() {
    tmp_34_fu_25639_p4 = sub_ln1118_12_fu_25633_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_39_fu_26315_p4() {
    tmp_39_fu_26315_p4 = add_ln1118_3_fu_26309_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_43_fu_26370_p1() {
    tmp_43_fu_26370_p1 =  (sc_lv<24>) (grp_fu_1560_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_43_fu_26370_p4() {
    tmp_43_fu_26370_p4 = tmp_43_fu_26370_p1.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_44_fu_26402_p4() {
    tmp_44_fu_26402_p4 = sub_ln1118_16_fu_26396_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_50_fu_26868_p4() {
    tmp_50_fu_26868_p4 = sub_ln1118_21_fu_26862_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_52_fu_26952_p4() {
    tmp_52_fu_26952_p4 = sub_ln1118_24_fu_26946_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_53_fu_26998_p4() {
    tmp_53_fu_26998_p4 = sub_ln1118_25_fu_26992_p2.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_55_fu_30225_p1() {
    tmp_55_fu_30225_p1 =  (sc_lv<24>) (grp_fu_1565_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_55_fu_30225_p4() {
    tmp_55_fu_30225_p4 = tmp_55_fu_30225_p1.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_60_fu_30318_p4() {
    tmp_60_fu_30318_p4 = add_ln1118_5_fu_30312_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_62_fu_27695_p1() {
    tmp_62_fu_27695_p1 =  (sc_lv<23>) (grp_fu_1576_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_62_fu_27695_p4() {
    tmp_62_fu_27695_p4 = tmp_62_fu_27695_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_71_fu_27840_p1() {
    tmp_71_fu_27840_p1 =  (sc_lv<24>) (grp_fu_1557_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_71_fu_27840_p4() {
    tmp_71_fu_27840_p4 = tmp_71_fu_27840_p1.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_75_fu_28154_p4() {
    tmp_75_fu_28154_p4 = sub_ln1118_35_fu_28148_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_77_fu_28278_p1() {
    tmp_77_fu_28278_p1 =  (sc_lv<23>) (grp_fu_1593_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_77_fu_28278_p4() {
    tmp_77_fu_28278_p4 = tmp_77_fu_28278_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_78_fu_28352_p4() {
    tmp_78_fu_28352_p4 = sub_ln1118_69_fu_28346_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_81_fu_28413_p4() {
    tmp_81_fu_28413_p4 = sub_ln1118_38_fu_28407_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_82_fu_28463_p4() {
    tmp_82_fu_28463_p4 = sub_ln1118_40_fu_28457_p2.read().range(19, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_84_fu_28525_p4() {
    tmp_84_fu_28525_p4 = sub_ln1118_41_fu_28519_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_87_fu_29057_p4() {
    tmp_87_fu_29057_p4 = sub_ln1118_43_fu_29051_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_88_fu_29071_p1() {
    tmp_88_fu_29071_p1 =  (sc_lv<23>) (grp_fu_1565_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_89_fu_30572_p4() {
    tmp_89_fu_30572_p4 = sub_ln1118_45_fu_30566_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_92_fu_30618_p4() {
    tmp_92_fu_30618_p4 = sub_ln1118_70_fu_30612_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_95_fu_29227_p1() {
    tmp_95_fu_29227_p1 =  (sc_lv<23>) (grp_fu_1566_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_95_fu_29227_p4() {
    tmp_95_fu_29227_p4 = tmp_95_fu_29227_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_96_fu_30749_p4() {
    tmp_96_fu_30749_p4 = add_ln1118_9_fu_30743_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_98_fu_30841_p4() {
    tmp_98_fu_30841_p4 = sub_ln1118_49_fu_30835_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_99_fu_30903_p4() {
    tmp_99_fu_30903_p4 = add_ln1118_10_fu_30897_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_fu_28334_p1() {
    tmp_fu_28334_p1 = ap_port_reg_data_66_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_tmp_fu_28334_p3() {
    tmp_fu_28334_p3 = esl_concat<16,5>(tmp_fu_28334_p1.read(), ap_const_lv5_0);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_100_fu_27950_p4() {
    trunc_ln708_100_fu_27950_p4 = sub_ln1118_32_fu_27944_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_103_fu_28008_p4() {
    trunc_ln708_103_fu_28008_p4 = sub_ln1118_33_fu_28002_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_104_fu_28032_p1() {
    trunc_ln708_104_fu_28032_p1 =  (sc_lv<21>) (grp_fu_1569_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_104_fu_28032_p4() {
    trunc_ln708_104_fu_28032_p4 = trunc_ln708_104_fu_28032_p1.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_105_fu_28076_p4() {
    trunc_ln708_105_fu_28076_p4 = sub_ln1118_34_fu_28070_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_108_fu_28117_p1() {
    trunc_ln708_108_fu_28117_p1 =  (sc_lv<24>) (grp_fu_1599_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_108_fu_28117_p4() {
    trunc_ln708_108_fu_28117_p4 = trunc_ln708_108_fu_28117_p1.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_114_fu_30412_p4() {
    trunc_ln708_114_fu_30412_p4 = sub_ln1118_37_fu_30406_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_118_fu_30437_p1() {
    trunc_ln708_118_fu_30437_p1 =  (sc_lv<22>) (grp_fu_1595_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_118_fu_30437_p4() {
    trunc_ln708_118_fu_30437_p4 = trunc_ln708_118_fu_30437_p1.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_120_fu_30463_p1() {
    trunc_ln708_120_fu_30463_p1 =  (sc_lv<22>) (grp_fu_1584_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_120_fu_30463_p4() {
    trunc_ln708_120_fu_30463_p4 = trunc_ln708_120_fu_30463_p1.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_123_fu_28246_p1() {
    trunc_ln708_123_fu_28246_p1 = ap_port_reg_data_63_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_136_fu_28598_p4() {
    trunc_ln708_136_fu_28598_p4 = sub_ln1118_42_fu_28592_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_137_fu_28623_p1() {
    trunc_ln708_137_fu_28623_p1 =  (sc_lv<24>) (grp_fu_1594_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_139_fu_28637_p4() {
    trunc_ln708_139_fu_28637_p4 = grp_fu_1558_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_140_fu_28656_p1() {
    trunc_ln708_140_fu_28656_p1 = ap_port_reg_data_72_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_141_fu_28666_p1() {
    trunc_ln708_141_fu_28666_p1 =  (sc_lv<23>) (grp_fu_1563_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_141_fu_28666_p4() {
    trunc_ln708_141_fu_28666_p4 = trunc_ln708_141_fu_28666_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_149_fu_29090_p1() {
    trunc_ln708_149_fu_29090_p1 = ap_port_reg_data_76_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_14_fu_25207_p4() {
    trunc_ln708_14_fu_25207_p4 = add_ln1118_1_fu_25201_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_162_fu_30705_p4() {
    trunc_ln708_162_fu_30705_p4 = sub_ln1118_47_fu_30699_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_163_fu_30769_p4() {
    trunc_ln708_163_fu_30769_p4 = sub_ln1118_48_fu_30763_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_177_fu_31673_p4() {
    trunc_ln708_177_fu_31673_p4 = grp_fu_1572_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_179_fu_31687_p4() {
    trunc_ln708_179_fu_31687_p4 = grp_fu_1574_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_180_fu_29288_p4() {
    trunc_ln708_180_fu_29288_p4 = sub_ln1118_51_fu_29282_p2.read().range(19, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_186_fu_31729_p1() {
    trunc_ln708_186_fu_31729_p1 =  (sc_lv<24>) (grp_fu_1593_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_186_fu_31729_p4() {
    trunc_ln708_186_fu_31729_p4 = trunc_ln708_186_fu_31729_p1.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_187_fu_31787_p4() {
    trunc_ln708_187_fu_31787_p4 = grp_fu_1579_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_188_fu_31816_p1() {
    trunc_ln708_188_fu_31816_p1 =  (sc_lv<23>) (grp_fu_1587_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_188_fu_31816_p4() {
    trunc_ln708_188_fu_31816_p4 = trunc_ln708_188_fu_31816_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_19_fu_25376_p4() {
    trunc_ln708_19_fu_25376_p4 = sub_ln1118_7_fu_25370_p2.read().range(19, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_201_fu_29510_p1() {
    trunc_ln708_201_fu_29510_p1 = ap_port_reg_data_102_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_201_fu_29510_p4() {
    trunc_ln708_201_fu_29510_p4 = trunc_ln708_201_fu_29510_p1.read().range(15, 9);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_202_fu_29542_p4() {
    trunc_ln708_202_fu_29542_p4 = sub_ln1118_56_fu_29536_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_203_fu_29619_p1() {
    trunc_ln708_203_fu_29619_p1 =  (sc_lv<22>) (grp_fu_1558_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_203_fu_29619_p4() {
    trunc_ln708_203_fu_29619_p4 = trunc_ln708_203_fu_29619_p1.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_208_fu_29684_p4() {
    trunc_ln708_208_fu_29684_p4 = sub_ln1118_58_fu_29678_p2.read().range(18, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_209_fu_29698_p1() {
    trunc_ln708_209_fu_29698_p1 =  (sc_lv<24>) (grp_fu_1592_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_209_fu_29698_p4() {
    trunc_ln708_209_fu_29698_p4 = trunc_ln708_209_fu_29698_p1.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_213_fu_29814_p4() {
    trunc_ln708_213_fu_29814_p4 = sub_ln1118_60_fu_29808_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_217_fu_31972_p4() {
    trunc_ln708_217_fu_31972_p4 = sub_ln1118_71_fu_31966_p2.read().range(19, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_218_fu_32007_p4() {
    trunc_ln708_218_fu_32007_p4 = add_ln1118_13_fu_32001_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_219_fu_32027_p1() {
    trunc_ln708_219_fu_32027_p1 = ap_port_reg_data_110_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_235_fu_32107_p1() {
    trunc_ln708_235_fu_32107_p1 =  (sc_lv<23>) (grp_fu_1582_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_235_fu_32107_p4() {
    trunc_ln708_235_fu_32107_p4 = trunc_ln708_235_fu_32107_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_236_fu_32138_p4() {
    trunc_ln708_236_fu_32138_p4 = sub_ln1118_65_fu_32132_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_23_fu_25454_p4() {
    trunc_ln708_23_fu_25454_p4 = sub_ln1118_9_fu_25448_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_242_fu_32215_p4() {
    trunc_ln708_242_fu_32215_p4 = sub_ln1118_66_fu_32209_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_246_fu_32291_p4() {
    trunc_ln708_246_fu_32291_p4 = sub_ln1118_68_fu_32285_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_253_fu_32785_p1() {
    trunc_ln708_253_fu_32785_p1 = ap_port_reg_data_124_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_253_fu_32785_p4() {
    trunc_ln708_253_fu_32785_p4 = trunc_ln708_253_fu_32785_p1.read().range(15, 6);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_256_fu_32865_p4() {
    trunc_ln708_256_fu_32865_p4 = add_ln1118_14_fu_32859_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_258_fu_32883_p1() {
    trunc_ln708_258_fu_32883_p1 = ap_port_reg_data_126_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_258_fu_32883_p4() {
    trunc_ln708_258_fu_32883_p4 = trunc_ln708_258_fu_32883_p1.read().range(15, 3);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_31_fu_25676_p1() {
    trunc_ln708_31_fu_25676_p1 =  (sc_lv<24>) (grp_fu_1586_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_31_fu_25676_p4() {
    trunc_ln708_31_fu_25676_p4 = trunc_ln708_31_fu_25676_p1.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_34_fu_25713_p1() {
    trunc_ln708_34_fu_25713_p1 = data_20_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_38_fu_26177_p4() {
    trunc_ln708_38_fu_26177_p4 = sub_ln1118_14_fu_26171_p2.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_39_fu_26191_p1() {
    trunc_ln708_39_fu_26191_p1 =  (sc_lv<23>) (grp_fu_1578_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_39_fu_26191_p4() {
    trunc_ln708_39_fu_26191_p4 = trunc_ln708_39_fu_26191_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_3_fu_25047_p4() {
    trunc_ln708_3_fu_25047_p4 = sub_ln1118_5_fu_25041_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_44_fu_26271_p4() {
    trunc_ln708_44_fu_26271_p4 = sub_ln1118_15_fu_26265_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_46_fu_26456_p4() {
    trunc_ln708_46_fu_26456_p4 = sub_ln1118_17_fu_26450_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_4_fu_25079_p4() {
    trunc_ln708_4_fu_25079_p4 = sub_ln1118_6_fu_25073_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_51_fu_26508_p4() {
    trunc_ln708_51_fu_26508_p4 = grp_fu_1566_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_55_fu_26548_p1() {
    trunc_ln708_55_fu_26548_p1 = ap_port_reg_data_30_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_56_fu_26568_p1() {
    trunc_ln708_56_fu_26568_p1 =  (sc_lv<24>) (grp_fu_1571_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_56_fu_26568_p4() {
    trunc_ln708_56_fu_26568_p4 = trunc_ln708_56_fu_26568_p1.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_57_fu_26612_p4() {
    trunc_ln708_57_fu_26612_p4 = sub_ln1118_18_fu_26606_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_58_fu_26662_p4() {
    trunc_ln708_58_fu_26662_p4 = sub_ln1118_19_fu_26656_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_5_fu_24844_p4() {
    trunc_ln708_5_fu_24844_p4 = sub_ln1118_fu_24838_p2.read().range(16, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_64_fu_26755_p4() {
    trunc_ln708_64_fu_26755_p4 = sub_ln1118_20_fu_26749_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_6_fu_25111_p4() {
    trunc_ln708_6_fu_25111_p4 = add_ln1118_fu_25105_p2.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_71_fu_26824_p1() {
    trunc_ln708_71_fu_26824_p1 =  (sc_lv<23>) (grp_fu_1569_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_71_fu_26824_p4() {
    trunc_ln708_71_fu_26824_p4 = trunc_ln708_71_fu_26824_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_72_fu_26894_p4() {
    trunc_ln708_72_fu_26894_p4 = sub_ln1118_23_fu_26888_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_76_fu_27093_p4() {
    trunc_ln708_76_fu_27093_p4 = sub_ln1118_28_fu_27087_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_91_fu_27666_p1() {
    trunc_ln708_91_fu_27666_p1 = ap_port_reg_data_47_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_91_fu_27666_p4() {
    trunc_ln708_91_fu_27666_p4 = trunc_ln708_91_fu_27666_p1.read().range(15, 8);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_95_fu_30355_p1() {
    trunc_ln708_95_fu_30355_p1 =  (sc_lv<21>) (grp_fu_1588_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_95_fu_30355_p4() {
    trunc_ln708_95_fu_30355_p4 = trunc_ln708_95_fu_30355_p1.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_96_fu_27785_p4() {
    trunc_ln708_96_fu_27785_p4 = add_ln1118_6_fu_27779_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_98_fu_27888_p4() {
    trunc_ln708_98_fu_27888_p4 = sub_ln1118_31_fu_27882_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_trunc_ln708_9_fu_24914_p1() {
    trunc_ln708_9_fu_24914_p1 = data_2_V_read.read();
}

}

