#include "dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_ap_clk_no_reset_() {
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_CS_fsm = ap_ST_fsm_state1;
    } else {
        ap_CS_fsm = ap_NS_fsm.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()))) {
        add_ln703_100_reg_33610 = add_ln703_100_fu_30006_p2.read();
        add_ln703_101_reg_33615 = add_ln703_101_fu_30012_p2.read();
        add_ln703_121_reg_33620 = add_ln703_121_fu_30034_p2.read();
        add_ln703_196_reg_33625 = add_ln703_196_fu_30055_p2.read();
        add_ln703_201_reg_33630 = add_ln703_201_fu_30060_p2.read();
        add_ln703_227_reg_33635 = add_ln703_227_fu_30106_p2.read();
        add_ln703_228_reg_33640 = add_ln703_228_fu_30112_p2.read();
        add_ln703_231_reg_33645 = add_ln703_231_fu_30118_p2.read();
        add_ln703_323_reg_33650 = add_ln703_323_fu_30135_p2.read();
        add_ln703_327_reg_33655 = add_ln703_327_fu_30140_p2.read();
        add_ln703_339_reg_33660 = add_ln703_339_fu_30146_p2.read();
        add_ln703_354_reg_33665 = add_ln703_354_fu_30200_p2.read();
        add_ln703_355_reg_33670 = add_ln703_355_fu_30206_p2.read();
        add_ln703_358_reg_33675 = add_ln703_358_fu_30212_p2.read();
        add_ln703_69_reg_33590 = add_ln703_69_fu_29939_p2.read();
        add_ln703_71_reg_33595 = add_ln703_71_fu_29944_p2.read();
        add_ln703_73_reg_33600 = add_ln703_73_fu_29950_p2.read();
        add_ln703_85_reg_33605 = add_ln703_85_fu_29956_p2.read();
        data_109_V_read_2_reg_33470 = ap_port_reg_data_109_V_read.read();
        data_111_V_read_2_reg_33465 = ap_port_reg_data_111_V_read.read();
        data_112_V_read_2_reg_33460 = ap_port_reg_data_112_V_read.read();
        data_74_V_read_2_reg_33509 = ap_port_reg_data_74_V_read.read();
        data_76_V_read81_reg_33504 = ap_port_reg_data_76_V_read.read();
        data_77_V_read_2_reg_33497 = ap_port_reg_data_77_V_read.read();
        data_81_V_read_2_reg_33492 = ap_port_reg_data_81_V_read.read();
        data_82_V_read_2_reg_33487 = ap_port_reg_data_82_V_read.read();
        data_84_V_read_2_reg_33482 = ap_port_reg_data_84_V_read.read();
        data_93_V_read_2_reg_33477 = ap_port_reg_data_93_V_read.read();
        sext_ln1118_222_reg_33524 = sext_ln1118_222_fu_29113_p1.read();
        sext_ln1118_227_reg_33539 = sext_ln1118_227_fu_29204_p1.read();
        sext_ln1118_257_reg_33555 = sext_ln1118_257_fu_29251_p1.read();
        sext_ln1118_263_reg_33565 = sext_ln1118_263_fu_29356_p1.read();
        sext_ln1118_319_reg_33575 = sext_ln1118_319_fu_29877_p1.read();
        tmp_104_reg_33570 = grp_fu_24447_p1.read().range(23, 10);
        tmp_122_reg_33580 = sub_ln1118_62_fu_29912_p2.read().range(23, 10);
        tmp_88_reg_33514 = tmp_88_fu_29071_p1.read().range(22, 10);
        tmp_93_reg_33529 = add_ln1118_8_fu_29134_p2.read().range(19, 10);
        trunc_ln708_149_reg_33519 = trunc_ln708_149_fu_29090_p1.read().range(15, 3);
        trunc_ln708_154_reg_33534 = sub_ln1118_46_fu_29184_p2.read().range(19, 10);
        trunc_ln708_164_reg_33545 = grp_fu_1591_p2.read().range(24, 10);
        trunc_ln708_165_reg_33550 = grp_fu_24277_p1.read().range(20, 10);
        trunc_ln708_182_reg_33560 = sub_ln1118_52_fu_29336_p2.read().range(23, 10);
        trunc_ln708_232_reg_33585 = grp_fu_24757_p1.read().range(23, 10);
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state5.read()))) {
        add_ln703_105_reg_33712 = add_ln703_105_fu_31297_p2.read();
        add_ln703_109_reg_33717 = add_ln703_109_fu_31303_p2.read();
        add_ln703_189_reg_33722 = add_ln703_189_fu_31385_p2.read();
        add_ln703_204_reg_33727 = add_ln703_204_fu_31433_p2.read();
        add_ln703_207_reg_33732 = add_ln703_207_fu_31458_p2.read();
        add_ln703_208_reg_33737 = add_ln703_208_fu_31464_p2.read();
        add_ln703_236_reg_33742 = add_ln703_236_fu_31470_p2.read();
        add_ln703_316_reg_33747 = add_ln703_316_fu_31556_p2.read();
        add_ln703_331_reg_33752 = add_ln703_331_fu_31600_p2.read();
        add_ln703_334_reg_33757 = add_ln703_334_fu_31617_p2.read();
        add_ln703_335_reg_33762 = add_ln703_335_fu_31623_p2.read();
        add_ln703_363_reg_33767 = add_ln703_363_fu_31629_p2.read();
        add_ln703_62_reg_33692 = add_ln703_62_fu_31231_p2.read();
        add_ln703_77_reg_33697 = add_ln703_77_fu_31268_p2.read();
        add_ln703_80_reg_33702 = add_ln703_80_fu_31285_p2.read();
        add_ln703_81_reg_33707 = add_ln703_81_fu_31291_p2.read();
        data_117_V_read_2_reg_33680 = ap_port_reg_data_117_V_read.read();
        sext_ln1118_329_reg_33686 = sext_ln1118_329_fu_31117_p1.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()))) {
        add_ln703_108_reg_33797 = add_ln703_108_fu_32437_p2.read();
        add_ln703_111_reg_33802 = add_ln703_111_fu_32448_p2.read();
        add_ln703_112_reg_33807 = add_ln703_112_fu_32453_p2.read();
        add_ln703_220_reg_33812 = add_ln703_220_fu_32531_p2.read();
        add_ln703_235_reg_33817 = add_ln703_235_fu_32568_p2.read();
        add_ln703_242_reg_33822 = add_ln703_242_fu_32606_p2.read();
        add_ln703_347_reg_33827 = add_ln703_347_fu_32673_p2.read();
        add_ln703_362_reg_33832 = add_ln703_362_fu_32706_p2.read();
        add_ln703_369_reg_33837 = add_ln703_369_fu_32744_p2.read();
        add_ln703_93_reg_33792 = add_ln703_93_fu_32400_p2.read();
        tmp_128_reg_33782 = grp_fu_24747_p1.read().range(23, 10);
        trunc_ln708_219_reg_33772 = trunc_ln708_219_fu_32027_p1.read().range(15, 5);
        trunc_ln708_250_reg_33777 = grp_fu_1552_p2.read().range(23, 10);
        trunc_ln708_251_reg_33787 = grp_fu_1563_p2.read().range(24, 10);
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1))) {
        add_ln703_141_reg_33187 = add_ln703_141_fu_25991_p2.read();
        add_ln703_142_reg_33192 = add_ln703_142_fu_25997_p2.read();
        add_ln703_14_reg_33172 = add_ln703_14_fu_25853_p2.read();
        add_ln703_17_reg_33177 = add_ln703_17_fu_25875_p2.read();
        add_ln703_18_reg_33182 = add_ln703_18_fu_25881_p2.read();
        add_ln703_268_reg_33197 = add_ln703_268_fu_26103_p2.read();
        add_ln703_271_reg_33202 = add_ln703_271_fu_26121_p2.read();
        ap_port_reg_data_100_V_read = data_100_V_read.read();
        ap_port_reg_data_101_V_read = data_101_V_read.read();
        ap_port_reg_data_102_V_read = data_102_V_read.read();
        ap_port_reg_data_103_V_read = data_103_V_read.read();
        ap_port_reg_data_104_V_read = data_104_V_read.read();
        ap_port_reg_data_105_V_read = data_105_V_read.read();
        ap_port_reg_data_106_V_read = data_106_V_read.read();
        ap_port_reg_data_107_V_read = data_107_V_read.read();
        ap_port_reg_data_108_V_read = data_108_V_read.read();
        ap_port_reg_data_109_V_read = data_109_V_read.read();
        ap_port_reg_data_110_V_read = data_110_V_read.read();
        ap_port_reg_data_111_V_read = data_111_V_read.read();
        ap_port_reg_data_112_V_read = data_112_V_read.read();
        ap_port_reg_data_113_V_read = data_113_V_read.read();
        ap_port_reg_data_114_V_read = data_114_V_read.read();
        ap_port_reg_data_115_V_read = data_115_V_read.read();
        ap_port_reg_data_116_V_read = data_116_V_read.read();
        ap_port_reg_data_117_V_read = data_117_V_read.read();
        ap_port_reg_data_118_V_read = data_118_V_read.read();
        ap_port_reg_data_119_V_read = data_119_V_read.read();
        ap_port_reg_data_120_V_read = data_120_V_read.read();
        ap_port_reg_data_121_V_read = data_121_V_read.read();
        ap_port_reg_data_122_V_read = data_122_V_read.read();
        ap_port_reg_data_123_V_read = data_123_V_read.read();
        ap_port_reg_data_124_V_read = data_124_V_read.read();
        ap_port_reg_data_125_V_read = data_125_V_read.read();
        ap_port_reg_data_126_V_read = data_126_V_read.read();
        ap_port_reg_data_127_V_read = data_127_V_read.read();
        ap_port_reg_data_22_V_read = data_22_V_read.read();
        ap_port_reg_data_23_V_read = data_23_V_read.read();
        ap_port_reg_data_24_V_read = data_24_V_read.read();
        ap_port_reg_data_25_V_read = data_25_V_read.read();
        ap_port_reg_data_26_V_read = data_26_V_read.read();
        ap_port_reg_data_27_V_read = data_27_V_read.read();
        ap_port_reg_data_28_V_read = data_28_V_read.read();
        ap_port_reg_data_29_V_read = data_29_V_read.read();
        ap_port_reg_data_30_V_read = data_30_V_read.read();
        ap_port_reg_data_31_V_read = data_31_V_read.read();
        ap_port_reg_data_32_V_read = data_32_V_read.read();
        ap_port_reg_data_33_V_read = data_33_V_read.read();
        ap_port_reg_data_34_V_read = data_34_V_read.read();
        ap_port_reg_data_35_V_read = data_35_V_read.read();
        ap_port_reg_data_36_V_read = data_36_V_read.read();
        ap_port_reg_data_37_V_read = data_37_V_read.read();
        ap_port_reg_data_38_V_read = data_38_V_read.read();
        ap_port_reg_data_39_V_read = data_39_V_read.read();
        ap_port_reg_data_40_V_read = data_40_V_read.read();
        ap_port_reg_data_41_V_read = data_41_V_read.read();
        ap_port_reg_data_42_V_read = data_42_V_read.read();
        ap_port_reg_data_43_V_read = data_43_V_read.read();
        ap_port_reg_data_44_V_read = data_44_V_read.read();
        ap_port_reg_data_45_V_read = data_45_V_read.read();
        ap_port_reg_data_46_V_read = data_46_V_read.read();
        ap_port_reg_data_47_V_read = data_47_V_read.read();
        ap_port_reg_data_48_V_read = data_48_V_read.read();
        ap_port_reg_data_49_V_read = data_49_V_read.read();
        ap_port_reg_data_50_V_read = data_50_V_read.read();
        ap_port_reg_data_51_V_read = data_51_V_read.read();
        ap_port_reg_data_52_V_read = data_52_V_read.read();
        ap_port_reg_data_53_V_read = data_53_V_read.read();
        ap_port_reg_data_54_V_read = data_54_V_read.read();
        ap_port_reg_data_55_V_read = data_55_V_read.read();
        ap_port_reg_data_56_V_read = data_56_V_read.read();
        ap_port_reg_data_57_V_read = data_57_V_read.read();
        ap_port_reg_data_58_V_read = data_58_V_read.read();
        ap_port_reg_data_59_V_read = data_59_V_read.read();
        ap_port_reg_data_60_V_read = data_60_V_read.read();
        ap_port_reg_data_61_V_read = data_61_V_read.read();
        ap_port_reg_data_62_V_read = data_62_V_read.read();
        ap_port_reg_data_63_V_read = data_63_V_read.read();
        ap_port_reg_data_64_V_read = data_64_V_read.read();
        ap_port_reg_data_65_V_read = data_65_V_read.read();
        ap_port_reg_data_66_V_read = data_66_V_read.read();
        ap_port_reg_data_67_V_read = data_67_V_read.read();
        ap_port_reg_data_68_V_read = data_68_V_read.read();
        ap_port_reg_data_69_V_read = data_69_V_read.read();
        ap_port_reg_data_70_V_read = data_70_V_read.read();
        ap_port_reg_data_71_V_read = data_71_V_read.read();
        ap_port_reg_data_72_V_read = data_72_V_read.read();
        ap_port_reg_data_73_V_read = data_73_V_read.read();
        ap_port_reg_data_74_V_read = data_74_V_read.read();
        ap_port_reg_data_75_V_read = data_75_V_read.read();
        ap_port_reg_data_76_V_read = data_76_V_read.read();
        ap_port_reg_data_77_V_read = data_77_V_read.read();
        ap_port_reg_data_78_V_read = data_78_V_read.read();
        ap_port_reg_data_79_V_read = data_79_V_read.read();
        ap_port_reg_data_80_V_read = data_80_V_read.read();
        ap_port_reg_data_81_V_read = data_81_V_read.read();
        ap_port_reg_data_82_V_read = data_82_V_read.read();
        ap_port_reg_data_83_V_read = data_83_V_read.read();
        ap_port_reg_data_84_V_read = data_84_V_read.read();
        ap_port_reg_data_85_V_read = data_85_V_read.read();
        ap_port_reg_data_86_V_read = data_86_V_read.read();
        ap_port_reg_data_87_V_read = data_87_V_read.read();
        ap_port_reg_data_88_V_read = data_88_V_read.read();
        ap_port_reg_data_89_V_read = data_89_V_read.read();
        ap_port_reg_data_90_V_read = data_90_V_read.read();
        ap_port_reg_data_91_V_read = data_91_V_read.read();
        ap_port_reg_data_92_V_read = data_92_V_read.read();
        ap_port_reg_data_93_V_read = data_93_V_read.read();
        ap_port_reg_data_94_V_read = data_94_V_read.read();
        ap_port_reg_data_95_V_read = data_95_V_read.read();
        ap_port_reg_data_96_V_read = data_96_V_read.read();
        ap_port_reg_data_97_V_read = data_97_V_read.read();
        ap_port_reg_data_98_V_read = data_98_V_read.read();
        ap_port_reg_data_99_V_read = data_99_V_read.read();
        sext_ln1118_60_reg_33162 = sext_ln1118_60_fu_25751_p1.read();
        trunc_ln708_34_reg_33152 = trunc_ln708_34_fu_25713_p1.read().range(15, 10);
        trunc_ln708_35_reg_33157 = sub_ln1118_13_fu_25735_p2.read().range(19, 10);
        trunc_ln708_36_reg_33167 = grp_fu_1595_p2.read().range(24, 10);
        trunc_ln708_9_reg_33147 = trunc_ln708_9_fu_24914_p1.read().range(15, 8);
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
        add_ln703_157_reg_33262 = add_ln703_157_fu_27410_p2.read();
        add_ln703_164_reg_33267 = add_ln703_164_fu_27455_p2.read();
        add_ln703_165_reg_33272 = add_ln703_165_fu_27461_p2.read();
        add_ln703_284_reg_33277 = add_ln703_284_fu_27546_p2.read();
        add_ln703_291_reg_33282 = add_ln703_291_fu_27591_p2.read();
        add_ln703_30_reg_33252 = add_ln703_30_fu_27268_p2.read();
        add_ln703_37_reg_33257 = add_ln703_37_fu_27313_p2.read();
        data_41_V_read_2_reg_33217 = ap_port_reg_data_41_V_read.read();
        data_42_V_read_2_reg_33212 = ap_port_reg_data_42_V_read.read();
        data_44_V_read_2_reg_33207 = ap_port_reg_data_44_V_read.read();
        sext_ln1118_120_reg_33232 = sext_ln1118_120_fu_27111_p1.read();
        sext_ln1118_129_reg_33247 = sext_ln1118_129_fu_27183_p1.read();
        tmp_54_reg_33227 = sub_ln1118_27_fu_27059_p2.read().range(21, 10);
        tmp_57_reg_33237 = add_ln1118_4_fu_27163_p2.read().range(23, 10);
        tmp_58_reg_33242 = grp_fu_24347_p1.read().range(23, 10);
        trunc_ln708_55_reg_33222 = trunc_ln708_55_fu_26548_p1.read().range(15, 8);
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()))) {
        add_ln703_168_reg_33390 = add_ln703_168_fu_28764_p2.read();
        add_ln703_179_reg_33395 = add_ln703_179_fu_28818_p2.read();
        add_ln703_180_reg_33400 = add_ln703_180_fu_28824_p2.read();
        add_ln703_184_reg_33405 = add_ln703_184_fu_28830_p2.read();
        add_ln703_192_reg_33410 = add_ln703_192_fu_28852_p2.read();
        add_ln703_193_reg_33415 = add_ln703_193_fu_28858_p2.read();
        add_ln703_293_reg_33420 = add_ln703_293_fu_28864_p2.read();
        add_ln703_296_reg_33425 = add_ln703_296_fu_28870_p2.read();
        add_ln703_306_reg_33430 = add_ln703_306_fu_28916_p2.read();
        add_ln703_307_reg_33435 = add_ln703_307_fu_28922_p2.read();
        add_ln703_310_reg_33440 = add_ln703_310_fu_28928_p2.read();
        add_ln703_319_reg_33445 = add_ln703_319_fu_28954_p2.read();
        add_ln703_320_reg_33450 = add_ln703_320_fu_28960_p2.read();
        add_ln703_375_reg_33455 = add_ln703_375_fu_28976_p2.read();
        add_ln703_52_reg_33370 = add_ln703_52_fu_28724_p2.read();
        add_ln703_53_reg_33375 = add_ln703_53_fu_28730_p2.read();
        add_ln703_65_reg_33380 = add_ln703_65_fu_28752_p2.read();
        add_ln703_66_reg_33385 = add_ln703_66_fu_28758_p2.read();
        data_49_V_read_2_reg_33325 = ap_port_reg_data_49_V_read.read();
        data_50_V_read_2_reg_33320 = ap_port_reg_data_50_V_read.read();
        data_58_V_read_2_reg_33315 = ap_port_reg_data_58_V_read.read();
        data_60_V_read_2_reg_33308 = ap_port_reg_data_60_V_read.read();
        data_61_V_read_2_reg_33303 = ap_port_reg_data_61_V_read.read();
        data_62_V_read_2_reg_33297 = ap_port_reg_data_62_V_read.read();
        data_63_V_read_2_reg_33292 = ap_port_reg_data_63_V_read.read();
        data_72_V_read_2_reg_33287 = ap_port_reg_data_72_V_read.read();
        sext_ln1118_179_reg_33340 = sext_ln1118_179_fu_28227_p1.read();
        tmp_61_reg_33330 = sub_ln1118_30_fu_27646_p2.read().range(20, 10);
        trunc_ln708_111_reg_33335 = sub_ln1118_36_fu_28194_p2.read().range(24, 10);
        trunc_ln708_117_reg_33345 = grp_fu_1591_p2.read().range(24, 10);
        trunc_ln708_123_reg_33350 = trunc_ln708_123_fu_28246_p1.read().range(15, 9);
        trunc_ln708_129_reg_33355 = add_ln1118_7_fu_28304_p2.read().range(19, 10);
        trunc_ln708_137_reg_33360 = trunc_ln708_137_fu_28623_p1.read().range(23, 10);
        trunc_ln708_140_reg_33365 = trunc_ln708_140_fu_28656_p1.read().range(15, 7);
    }
}

void dense_latency_ap_fixed_ap_fixed_16_6_5_3_0_config4_0_0_0_0::thread_ap_NS_fsm() {
    switch (ap_CS_fsm.read().to_uint64()) {
        case 1 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1))) {
                ap_NS_fsm = ap_ST_fsm_state2;
            } else {
                ap_NS_fsm = ap_ST_fsm_state1;
            }
            break;
        case 2 : 
            if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()))) {
                ap_NS_fsm = ap_ST_fsm_state3;
            } else {
                ap_NS_fsm = ap_ST_fsm_state2;
            }
            break;
        case 4 : 
            if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()))) {
                ap_NS_fsm = ap_ST_fsm_state4;
            } else {
                ap_NS_fsm = ap_ST_fsm_state3;
            }
            break;
        case 8 : 
            if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()))) {
                ap_NS_fsm = ap_ST_fsm_state5;
            } else {
                ap_NS_fsm = ap_ST_fsm_state4;
            }
            break;
        case 16 : 
            if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state5.read()))) {
                ap_NS_fsm = ap_ST_fsm_state6;
            } else {
                ap_NS_fsm = ap_ST_fsm_state5;
            }
            break;
        case 32 : 
            if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()))) {
                ap_NS_fsm = ap_ST_fsm_state7;
            } else {
                ap_NS_fsm = ap_ST_fsm_state6;
            }
            break;
        case 64 : 
            if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state7.read()))) {
                ap_NS_fsm = ap_ST_fsm_state1;
            } else {
                ap_NS_fsm = ap_ST_fsm_state7;
            }
            break;
        default : 
            ap_NS_fsm =  (sc_lv<7>) ("XXXXXXX");
            break;
    }
}

}

