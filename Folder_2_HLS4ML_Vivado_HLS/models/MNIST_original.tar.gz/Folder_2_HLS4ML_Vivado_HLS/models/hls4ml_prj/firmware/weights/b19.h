//Numpy array shape [10]
//Min -0.028228759766
//Max 0.000000000000
//Number of zeros 2

#ifndef B19_H_
#define B19_H_

#ifndef __SYNTHESIS__
model_default_t b19[10];
#else
model_default_t b19[10] = {0.0000000000, -0.0165405273, 0.0000000000, -0.0270233154, -0.0282287598, -0.0236816406, -0.0167846680, -0.0208892822, -0.0169982910, -0.0204162598};
#endif

#endif
