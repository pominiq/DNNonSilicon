//Numpy array shape [8]
//Min -0.180541992188
//Max 0.554199218750
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {0.0006866455, 0.1015625000, 0.1795654297, 0.2851562500, 0.2465820312, 0.5541992188, -0.0329895020, -0.1805419922};
#endif

#endif
