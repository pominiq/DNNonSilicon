//Numpy array shape [10]
//Min -0.247070312500
//Max 0.090148925781
//Number of zeros 0

#ifndef B15_H_
#define B15_H_

#ifndef __SYNTHESIS__
model_default_t b15[10];
#else
model_default_t b15[10] = {-0.2470703125, -0.0676269531, 0.0621948242, 0.0806884766, 0.0769042969, 0.0867309570, -0.2054443359, 0.0553588867, 0.0151290894, 0.0901489258};
#endif

#endif
