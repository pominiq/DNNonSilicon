//Numpy array shape [64]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 64

#ifndef Z10_H_
#define Z10_H_

#ifndef __SYNTHESIS__
zero_bias10_t z10[64];
#else
zero_bias10_t z10[64] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#endif

#endif
