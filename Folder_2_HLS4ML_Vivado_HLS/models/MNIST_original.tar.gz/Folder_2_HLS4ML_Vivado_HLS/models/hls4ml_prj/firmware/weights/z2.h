//Numpy array shape [3]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 3

#ifndef Z2_H_
#define Z2_H_

#ifndef __SYNTHESIS__
zero_bias2_t z2[3];
#else
zero_bias2_t z2[3] = {0, 0, 0};
#endif

#endif
