//Numpy array shape [4]
//Min -0.066955566406
//Max 0.003335952759
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {0.0033359528, -0.0669555664, 0.0008192062, -0.0091323853};
#endif

#endif
