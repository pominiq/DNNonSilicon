//Numpy array shape [10]
//Min -0.285400390625
//Max 0.500000000000
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
model_default_t b9[10];
#else
model_default_t b9[10] = {-0.0165557861, 0.2308349609, -0.2322998047, 0.0179443359, -0.1911621094, -0.1507568359, 0.1192016602, -0.2854003906, 0.5000000000, -0.0549926758};
#endif

#endif
