#include "dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_acc_1_V_fu_296321_p2() {
    acc_1_V_fu_296321_p2 = (!add_ln703_370_fu_296171_p2.read().is_01() || !add_ln703_388_fu_296315_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_370_fu_296171_p2.read()) + sc_biguint<16>(add_ln703_388_fu_296315_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_acc_2_V_fu_296565_p2() {
    acc_2_V_fu_296565_p2 = (!add_ln703_406_fu_296423_p2.read().is_01() || !add_ln703_424_fu_296559_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_406_fu_296423_p2.read()) + sc_biguint<16>(add_ln703_424_fu_296559_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_acc_3_V_fu_296813_p2() {
    acc_3_V_fu_296813_p2 = (!add_ln703_442_fu_296667_p2.read().is_01() || !add_ln703_460_fu_296807_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_442_fu_296667_p2.read()) + sc_biguint<16>(add_ln703_460_fu_296807_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_acc_4_V_fu_297061_p2() {
    acc_4_V_fu_297061_p2 = (!add_ln703_478_fu_296915_p2.read().is_01() || !add_ln703_496_fu_297055_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_478_fu_296915_p2.read()) + sc_biguint<16>(add_ln703_496_fu_297055_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_acc_5_V_fu_297309_p2() {
    acc_5_V_fu_297309_p2 = (!add_ln703_514_fu_297163_p2.read().is_01() || !add_ln703_532_fu_297303_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_514_fu_297163_p2.read()) + sc_biguint<16>(add_ln703_532_fu_297303_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_acc_6_V_fu_297557_p2() {
    acc_6_V_fu_297557_p2 = (!add_ln703_550_fu_297411_p2.read().is_01() || !add_ln703_568_fu_297551_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_550_fu_297411_p2.read()) + sc_biguint<16>(add_ln703_568_fu_297551_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_acc_7_V_fu_297793_p2() {
    acc_7_V_fu_297793_p2 = (!add_ln703_586_fu_297659_p2.read().is_01() || !add_ln703_604_fu_297787_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_586_fu_297659_p2.read()) + sc_biguint<16>(add_ln703_604_fu_297787_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln1118_5_fu_292499_p2() {
    add_ln1118_5_fu_292499_p2 = (!sext_ln1118_179_fu_292483_p1.read().is_01() || !sext_ln1118_180_fu_292495_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_179_fu_292483_p1.read()) + sc_bigint<21>(sext_ln1118_180_fu_292495_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln1118_6_fu_294530_p2() {
    add_ln1118_6_fu_294530_p2 = (!sext_ln1118_197_fu_294526_p1.read().is_01() || !sext_ln1118_196_fu_294522_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_197_fu_294526_p1.read()) + sc_bigint<20>(sext_ln1118_196_fu_294522_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln1118_7_fu_295813_p2() {
    add_ln1118_7_fu_295813_p2 = (!sext_ln1118_213_fu_295809_p1.read().is_01() || !sext_ln1118_212_fu_295797_p1.read().is_01())? sc_lv<24>(): (sc_bigint<24>(sext_ln1118_213_fu_295809_p1.read()) + sc_bigint<24>(sext_ln1118_212_fu_295797_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln1118_fu_292050_p2() {
    add_ln1118_fu_292050_p2 = (!sext_ln1118_178_fu_292046_p1.read().is_01() || !sext_ln1118_176_fu_291944_p1.read().is_01())? sc_lv<24>(): (sc_bigint<24>(sext_ln1118_178_fu_292046_p1.read()) + sc_bigint<24>(sext_ln1118_176_fu_291944_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_320_fu_295839_p2() {
    add_ln703_320_fu_295839_p2 = (!mult_96_V_fu_292681_p4.read().is_01() || !mult_72_V_fu_292236_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_96_V_fu_292681_p4.read()) + sc_biguint<16>(mult_72_V_fu_292236_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_321_fu_295845_p2() {
    add_ln703_321_fu_295845_p2 = (!add_ln703_fu_295833_p2.read().is_01() || !add_ln703_320_fu_295839_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_fu_295833_p2.read()) + sc_biguint<16>(add_ln703_320_fu_295839_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_322_fu_295851_p2() {
    add_ln703_322_fu_295851_p2 = (!mult_144_V_fu_293480_p4.read().is_01() || !mult_104_V_fu_292800_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_144_V_fu_293480_p4.read()) + sc_biguint<16>(mult_104_V_fu_292800_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_323_fu_295857_p2() {
    add_ln703_323_fu_295857_p2 = (!mult_176_V_fu_293936_p4.read().is_01() || !mult_168_V_fu_293792_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_176_V_fu_293936_p4.read()) + sc_biguint<16>(mult_168_V_fu_293792_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_324_fu_295863_p2() {
    add_ln703_324_fu_295863_p2 = (!mult_152_V_fu_293583_p4.read().is_01() || !add_ln703_323_fu_295857_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_152_V_fu_293583_p4.read()) + sc_biguint<16>(add_ln703_323_fu_295857_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_325_fu_295869_p2() {
    add_ln703_325_fu_295869_p2 = (!add_ln703_322_fu_295851_p2.read().is_01() || !add_ln703_324_fu_295863_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_322_fu_295851_p2.read()) + sc_biguint<16>(add_ln703_324_fu_295863_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_326_fu_295875_p2() {
    add_ln703_326_fu_295875_p2 = (!add_ln703_321_fu_295845_p2.read().is_01() || !add_ln703_325_fu_295869_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_321_fu_295845_p2.read()) + sc_biguint<16>(add_ln703_325_fu_295869_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_327_fu_295881_p2() {
    add_ln703_327_fu_295881_p2 = (!mult_240_V_fu_295035_p4.read().is_01() || !mult_224_V_fu_294773_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_240_V_fu_295035_p4.read()) + sc_biguint<16>(mult_224_V_fu_294773_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_328_fu_295887_p2() {
    add_ln703_328_fu_295887_p2 = (!mult_264_V_fu_295428_p4.read().is_01() || !mult_256_V_fu_295295_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_264_V_fu_295428_p4.read()) + sc_biguint<16>(mult_256_V_fu_295295_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_329_fu_295893_p2() {
    add_ln703_329_fu_295893_p2 = (!add_ln703_327_fu_295881_p2.read().is_01() || !add_ln703_328_fu_295887_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_327_fu_295881_p2.read()) + sc_biguint<16>(add_ln703_328_fu_295887_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_330_fu_295899_p2() {
    add_ln703_330_fu_295899_p2 = (!mult_40_V_fu_291660_p1.read().is_01() || !trunc_ln708_220_fu_295579_p4.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_40_V_fu_291660_p1.read()) + sc_biguint<16>(trunc_ln708_220_fu_295579_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_331_fu_295905_p2() {
    add_ln703_331_fu_295905_p2 = (!mult_160_V_fu_293691_p1.read().is_01() || !mult_128_V_fu_293207_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_160_V_fu_293691_p1.read()) + sc_bigint<16>(mult_128_V_fu_293207_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_332_fu_295911_p2() {
    add_ln703_332_fu_295911_p2 = (!mult_56_V_fu_291982_p1.read().is_01() || !add_ln703_331_fu_295905_p2.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_56_V_fu_291982_p1.read()) + sc_biguint<16>(add_ln703_331_fu_295905_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_333_fu_295917_p2() {
    add_ln703_333_fu_295917_p2 = (!add_ln703_330_fu_295899_p2.read().is_01() || !add_ln703_332_fu_295911_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_330_fu_295899_p2.read()) + sc_biguint<16>(add_ln703_332_fu_295911_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_334_fu_295923_p2() {
    add_ln703_334_fu_295923_p2 = (!add_ln703_329_fu_295893_p2.read().is_01() || !add_ln703_333_fu_295917_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_329_fu_295893_p2.read()) + sc_biguint<16>(add_ln703_333_fu_295917_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_335_fu_295929_p2() {
    add_ln703_335_fu_295929_p2 = (!add_ln703_326_fu_295875_p2.read().is_01() || !add_ln703_334_fu_295923_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_326_fu_295875_p2.read()) + sc_biguint<16>(add_ln703_334_fu_295923_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_336_fu_295935_p2() {
    add_ln703_336_fu_295935_p2 = (!mult_232_V_fu_294902_p1.read().is_01() || !mult_200_V_fu_294344_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_232_V_fu_294902_p1.read()) + sc_bigint<16>(mult_200_V_fu_294344_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_337_fu_295941_p2() {
    add_ln703_337_fu_295941_p2 = (!mult_8_V_fu_291101_p1.read().is_01() || !mult_248_V_fu_295204_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_8_V_fu_291101_p1.read()) + sc_bigint<16>(mult_248_V_fu_295204_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_338_fu_295947_p2() {
    add_ln703_338_fu_295947_p2 = (!add_ln703_336_fu_295935_p2.read().is_01() || !add_ln703_337_fu_295941_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_336_fu_295935_p2.read()) + sc_biguint<16>(add_ln703_337_fu_295941_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_339_fu_295953_p2() {
    add_ln703_339_fu_295953_p2 = (!sext_ln203_98_fu_292377_p1.read().is_01() || !sext_ln203_77_fu_291255_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_98_fu_292377_p1.read()) + sc_bigint<15>(sext_ln203_77_fu_291255_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_340_fu_295963_p2() {
    add_ln703_340_fu_295963_p2 = (!sext_ln203_133_fu_294637_p1.read().is_01() || !sext_ln203_122_fu_294192_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_133_fu_294637_p1.read()) + sc_bigint<15>(sext_ln203_122_fu_294192_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_341_fu_295973_p2() {
    add_ln703_341_fu_295973_p2 = (!mult_120_V_fu_293072_p1.read().is_01() || !sext_ln703_70_fu_295969_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_120_V_fu_293072_p1.read()) + sc_bigint<16>(sext_ln703_70_fu_295969_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_342_fu_295979_p2() {
    add_ln703_342_fu_295979_p2 = (!sext_ln703_fu_295959_p1.read().is_01() || !add_ln703_341_fu_295973_p2.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_fu_295959_p1.read()) + sc_biguint<16>(add_ln703_341_fu_295973_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_343_fu_295985_p2() {
    add_ln703_343_fu_295985_p2 = (!add_ln703_338_fu_295947_p2.read().is_01() || !add_ln703_342_fu_295979_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_338_fu_295947_p2.read()) + sc_biguint<16>(add_ln703_342_fu_295979_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_344_fu_295991_p2() {
    add_ln703_344_fu_295991_p2 = (!sext_ln203_fu_290974_p1.read().is_01() || !sext_ln1118_210_fu_295713_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_fu_290974_p1.read()) + sc_bigint<15>(sext_ln1118_210_fu_295713_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_345_fu_296001_p2() {
    add_ln703_345_fu_296001_p2 = (!sext_ln203_115_fu_293348_p1.read().is_01() || !sext_ln203_109_fu_292954_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_115_fu_293348_p1.read()) + sc_bigint<14>(sext_ln203_109_fu_292954_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_346_fu_296011_p2() {
    add_ln703_346_fu_296011_p2 = (!sext_ln703_71_fu_295997_p1.read().is_01() || !sext_ln703_72_fu_296007_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_71_fu_295997_p1.read()) + sc_bigint<16>(sext_ln703_72_fu_296007_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_347_fu_296017_p2() {
    add_ln703_347_fu_296017_p2 = (!sext_ln203_130_fu_294466_p1.read().is_01() || !sext_ln203_119_fu_294058_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_130_fu_294466_p1.read()) + sc_bigint<14>(sext_ln203_119_fu_294058_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_348_fu_296027_p2() {
    add_ln703_348_fu_296027_p2 = (!sext_ln203_102_fu_292515_p1.read().is_01() || !sext_ln203_90_fu_291824_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_102_fu_292515_p1.read()) + sc_bigint<13>(sext_ln203_90_fu_291824_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_349_fu_296037_p2() {
    add_ln703_349_fu_296037_p2 = (!sext_ln203_81_fu_291397_p1.read().is_01() || !sext_ln703_74_fu_296033_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_81_fu_291397_p1.read()) + sc_bigint<14>(sext_ln703_74_fu_296033_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_350_fu_296047_p2() {
    add_ln703_350_fu_296047_p2 = (!sext_ln703_73_fu_296023_p1.read().is_01() || !sext_ln703_75_fu_296043_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_73_fu_296023_p1.read()) + sc_bigint<15>(sext_ln703_75_fu_296043_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_351_fu_296057_p2() {
    add_ln703_351_fu_296057_p2 = (!add_ln703_346_fu_296011_p2.read().is_01() || !sext_ln703_76_fu_296053_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_346_fu_296011_p2.read()) + sc_bigint<16>(sext_ln703_76_fu_296053_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_352_fu_296063_p2() {
    add_ln703_352_fu_296063_p2 = (!add_ln703_343_fu_295985_p2.read().is_01() || !add_ln703_351_fu_296057_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_343_fu_295985_p2.read()) + sc_biguint<16>(add_ln703_351_fu_296057_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_354_fu_296075_p2() {
    add_ln703_354_fu_296075_p2 = (!mult_33_V_fu_291512_p4.read().is_01() || !mult_9_V_fu_291105_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_33_V_fu_291512_p4.read()) + sc_biguint<16>(mult_9_V_fu_291105_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_355_fu_296081_p2() {
    add_ln703_355_fu_296081_p2 = (!mult_105_V_fu_292810_p4.read().is_01() || !mult_41_V_fu_291664_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_105_V_fu_292810_p4.read()) + sc_biguint<16>(mult_41_V_fu_291664_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_356_fu_296087_p2() {
    add_ln703_356_fu_296087_p2 = (!add_ln703_354_fu_296075_p2.read().is_01() || !add_ln703_355_fu_296081_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_354_fu_296075_p2.read()) + sc_biguint<16>(add_ln703_355_fu_296081_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_357_fu_296093_p2() {
    add_ln703_357_fu_296093_p2 = (!mult_129_V_fu_293211_p4.read().is_01() || !mult_113_V_fu_292958_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_129_V_fu_293211_p4.read()) + sc_biguint<16>(mult_113_V_fu_292958_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_358_fu_296099_p2() {
    add_ln703_358_fu_296099_p2 = (!mult_161_V_fu_293695_p4.read().is_01() || !mult_145_V_fu_293490_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_161_V_fu_293695_p4.read()) + sc_biguint<16>(mult_145_V_fu_293490_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_359_fu_296105_p2() {
    add_ln703_359_fu_296105_p2 = (!mult_137_V_fu_293352_p4.read().is_01() || !add_ln703_358_fu_296099_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_137_V_fu_293352_p4.read()) + sc_biguint<16>(add_ln703_358_fu_296099_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_360_fu_296111_p2() {
    add_ln703_360_fu_296111_p2 = (!add_ln703_357_fu_296093_p2.read().is_01() || !add_ln703_359_fu_296105_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_357_fu_296093_p2.read()) + sc_biguint<16>(add_ln703_359_fu_296105_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_361_fu_296117_p2() {
    add_ln703_361_fu_296117_p2 = (!add_ln703_356_fu_296087_p2.read().is_01() || !add_ln703_360_fu_296111_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_356_fu_296087_p2.read()) + sc_biguint<16>(add_ln703_360_fu_296111_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_362_fu_296123_p2() {
    add_ln703_362_fu_296123_p2 = (!mult_233_V_fu_294906_p4.read().is_01() || !mult_177_V_fu_293946_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_233_V_fu_294906_p4.read()) + sc_biguint<16>(mult_177_V_fu_293946_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_363_fu_296129_p2() {
    add_ln703_363_fu_296129_p2 = (!trunc_ln708_221_fu_295589_p4.read().is_01() || !mult_257_V_fu_295305_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln708_221_fu_295589_p4.read()) + sc_biguint<16>(mult_257_V_fu_295305_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_364_fu_296135_p2() {
    add_ln703_364_fu_296135_p2 = (!add_ln703_362_fu_296123_p2.read().is_01() || !add_ln703_363_fu_296129_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_362_fu_296123_p2.read()) + sc_biguint<16>(add_ln703_363_fu_296129_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_365_fu_296141_p2() {
    add_ln703_365_fu_296141_p2 = (!mult_49_V_fu_291838_p1.read().is_01() || !mult_17_V_fu_291269_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_49_V_fu_291838_p1.read()) + sc_bigint<16>(mult_17_V_fu_291269_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_366_fu_296147_p2() {
    add_ln703_366_fu_296147_p2 = (!mult_153_V_fu_293603_p1.read().is_01() || !mult_97_V_fu_292701_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_153_V_fu_293603_p1.read()) + sc_bigint<16>(mult_97_V_fu_292701_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_367_fu_296153_p2() {
    add_ln703_367_fu_296153_p2 = (!mult_73_V_fu_292256_p1.read().is_01() || !add_ln703_366_fu_296147_p2.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_73_V_fu_292256_p1.read()) + sc_biguint<16>(add_ln703_366_fu_296147_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_368_fu_296159_p2() {
    add_ln703_368_fu_296159_p2 = (!add_ln703_365_fu_296141_p2.read().is_01() || !add_ln703_367_fu_296153_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_365_fu_296141_p2.read()) + sc_biguint<16>(add_ln703_367_fu_296153_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_369_fu_296165_p2() {
    add_ln703_369_fu_296165_p2 = (!add_ln703_364_fu_296135_p2.read().is_01() || !add_ln703_368_fu_296159_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_364_fu_296135_p2.read()) + sc_biguint<16>(add_ln703_368_fu_296159_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_370_fu_296171_p2() {
    add_ln703_370_fu_296171_p2 = (!add_ln703_361_fu_296117_p2.read().is_01() || !add_ln703_369_fu_296165_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_361_fu_296117_p2.read()) + sc_biguint<16>(add_ln703_369_fu_296165_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_371_fu_296177_p2() {
    add_ln703_371_fu_296177_p2 = (!mult_241_V_fu_295055_p1.read().is_01() || !mult_185_V_fu_294072_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_241_V_fu_295055_p1.read()) + sc_bigint<16>(mult_185_V_fu_294072_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_372_fu_296183_p2() {
    add_ln703_372_fu_296183_p2 = (!mult_1_V_fu_290988_p1.read().is_01() || !sext_ln708_1_fu_295727_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_1_V_fu_290988_p1.read()) + sc_bigint<16>(sext_ln708_1_fu_295727_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_373_fu_296189_p2() {
    add_ln703_373_fu_296189_p2 = (!add_ln703_371_fu_296177_p2.read().is_01() || !add_ln703_372_fu_296183_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_371_fu_296177_p2.read()) + sc_biguint<16>(add_ln703_372_fu_296183_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_374_fu_296195_p2() {
    add_ln703_374_fu_296195_p2 = (!sext_ln203_131_fu_294510_p1.read().is_01() || !sext_ln203_127_fu_294358_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_131_fu_294510_p1.read()) + sc_bigint<15>(sext_ln203_127_fu_294358_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_375_fu_296205_p2() {
    add_ln703_375_fu_296205_p2 = (!sext_ln203_82_fu_291411_p1.read().is_01() || !sext_ln203_146_fu_295448_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_82_fu_291411_p1.read()) + sc_bigint<15>(sext_ln203_146_fu_295448_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_376_fu_296215_p2() {
    add_ln703_376_fu_296215_p2 = (!mult_217_V_fu_294651_p1.read().is_01() || !sext_ln703_78_fu_296211_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_217_V_fu_294651_p1.read()) + sc_bigint<16>(sext_ln703_78_fu_296211_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_377_fu_296221_p2() {
    add_ln703_377_fu_296221_p2 = (!sext_ln703_77_fu_296201_p1.read().is_01() || !add_ln703_376_fu_296215_p2.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_77_fu_296201_p1.read()) + sc_biguint<16>(add_ln703_376_fu_296215_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_378_fu_296227_p2() {
    add_ln703_378_fu_296227_p2 = (!add_ln703_373_fu_296189_p2.read().is_01() || !add_ln703_377_fu_296221_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_373_fu_296189_p2.read()) + sc_biguint<16>(add_ln703_377_fu_296221_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_379_fu_296233_p2() {
    add_ln703_379_fu_296233_p2 = (!sext_ln203_112_fu_293086_p1.read().is_01() || !sext_ln203_92_fu_291996_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_112_fu_293086_p1.read()) + sc_bigint<14>(sext_ln203_92_fu_291996_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_380_fu_296243_p2() {
    add_ln703_380_fu_296243_p2 = (!sext_ln203_143_fu_295218_p1.read().is_01() || !sext_ln203_117_fu_293812_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_143_fu_295218_p1.read()) + sc_bigint<13>(sext_ln203_117_fu_293812_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_381_fu_296253_p2() {
    add_ln703_381_fu_296253_p2 = (!sext_ln203_137_fu_294793_p1.read().is_01() || !sext_ln703_80_fu_296249_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_137_fu_294793_p1.read()) + sc_bigint<14>(sext_ln703_80_fu_296249_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_382_fu_296263_p2() {
    add_ln703_382_fu_296263_p2 = (!sext_ln703_79_fu_296239_p1.read().is_01() || !sext_ln703_81_fu_296259_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_79_fu_296239_p1.read()) + sc_bigint<15>(sext_ln703_81_fu_296259_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_383_fu_296273_p2() {
    add_ln703_383_fu_296273_p2 = (!sext_ln203_123_fu_294206_p1.read().is_01() || !sext_ln203_103_fu_292529_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_123_fu_294206_p1.read()) + sc_bigint<12>(sext_ln203_103_fu_292529_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_384_fu_296283_p2() {
    add_ln703_384_fu_296283_p2 = (!sext_ln203_99_fu_292391_p1.read().is_01() || !sext_ln203_94_fu_292150_p1.read().is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln203_99_fu_292391_p1.read()) + sc_bigint<8>(sext_ln203_94_fu_292150_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_385_fu_296289_p2() {
    add_ln703_385_fu_296289_p2 = (!add_ln703_384_fu_296283_p2.read().is_01() || !ap_const_lv8_68.is_01())? sc_lv<8>(): (sc_biguint<8>(add_ln703_384_fu_296283_p2.read()) + sc_biguint<8>(ap_const_lv8_68));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_386_fu_296299_p2() {
    add_ln703_386_fu_296299_p2 = (!sext_ln703_83_fu_296279_p1.read().is_01() || !zext_ln703_fu_296295_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln703_83_fu_296279_p1.read()) + sc_biguint<13>(zext_ln703_fu_296295_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_387_fu_296309_p2() {
    add_ln703_387_fu_296309_p2 = (!sext_ln703_82_fu_296269_p1.read().is_01() || !sext_ln703_84_fu_296305_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_82_fu_296269_p1.read()) + sc_bigint<16>(sext_ln703_84_fu_296305_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_388_fu_296315_p2() {
    add_ln703_388_fu_296315_p2 = (!add_ln703_378_fu_296227_p2.read().is_01() || !add_ln703_387_fu_296309_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_378_fu_296227_p2.read()) + sc_biguint<16>(add_ln703_387_fu_296309_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_389_fu_296069_p2() {
    add_ln703_389_fu_296069_p2 = (!add_ln703_335_fu_295929_p2.read().is_01() || !add_ln703_352_fu_296063_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_335_fu_295929_p2.read()) + sc_biguint<16>(add_ln703_352_fu_296063_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_390_fu_296327_p2() {
    add_ln703_390_fu_296327_p2 = (!mult_34_V_fu_291522_p4.read().is_01() || !mult_10_V_fu_291115_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_34_V_fu_291522_p4.read()) + sc_biguint<16>(mult_10_V_fu_291115_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_391_fu_296333_p2() {
    add_ln703_391_fu_296333_p2 = (!mult_90_V_fu_292533_p4.read().is_01() || !mult_42_V_fu_291674_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_90_V_fu_292533_p4.read()) + sc_biguint<16>(mult_42_V_fu_291674_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_392_fu_296339_p2() {
    add_ln703_392_fu_296339_p2 = (!add_ln703_390_fu_296327_p2.read().is_01() || !add_ln703_391_fu_296333_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_390_fu_296327_p2.read()) + sc_biguint<16>(add_ln703_391_fu_296333_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_393_fu_296345_p2() {
    add_ln703_393_fu_296345_p2 = (!mult_114_V_fu_292968_p4.read().is_01() || !mult_106_V_fu_292820_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_114_V_fu_292968_p4.read()) + sc_biguint<16>(mult_106_V_fu_292820_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_394_fu_296351_p2() {
    add_ln703_394_fu_296351_p2 = (!mult_162_V_fu_293705_p4.read().is_01() || !mult_154_V_fu_293607_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_162_V_fu_293705_p4.read()) + sc_biguint<16>(mult_154_V_fu_293607_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_395_fu_296357_p2() {
    add_ln703_395_fu_296357_p2 = (!mult_146_V_fu_293500_p4.read().is_01() || !add_ln703_394_fu_296351_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_146_V_fu_293500_p4.read()) + sc_biguint<16>(add_ln703_394_fu_296351_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_396_fu_296363_p2() {
    add_ln703_396_fu_296363_p2 = (!add_ln703_393_fu_296345_p2.read().is_01() || !add_ln703_395_fu_296357_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_393_fu_296345_p2.read()) + sc_biguint<16>(add_ln703_395_fu_296357_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_397_fu_296369_p2() {
    add_ln703_397_fu_296369_p2 = (!add_ln703_392_fu_296339_p2.read().is_01() || !add_ln703_396_fu_296363_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_392_fu_296339_p2.read()) + sc_biguint<16>(add_ln703_396_fu_296363_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_398_fu_296375_p2() {
    add_ln703_398_fu_296375_p2 = (!mult_178_V_fu_293956_p4.read().is_01() || !mult_170_V_fu_293816_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_178_V_fu_293956_p4.read()) + sc_biguint<16>(mult_170_V_fu_293816_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_399_fu_296381_p2() {
    add_ln703_399_fu_296381_p2 = (!mult_242_V_fu_295059_p4.read().is_01() || !mult_234_V_fu_294916_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_242_V_fu_295059_p4.read()) + sc_biguint<16>(mult_234_V_fu_294916_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_400_fu_296387_p2() {
    add_ln703_400_fu_296387_p2 = (!add_ln703_398_fu_296375_p2.read().is_01() || !add_ln703_399_fu_296381_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_398_fu_296375_p2.read()) + sc_biguint<16>(add_ln703_399_fu_296381_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_401_fu_296393_p2() {
    add_ln703_401_fu_296393_p2 = (!mult_266_V_fu_295452_p4.read().is_01() || !mult_250_V_fu_295222_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_266_V_fu_295452_p4.read()) + sc_biguint<16>(mult_250_V_fu_295222_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_402_fu_296399_p2() {
    add_ln703_402_fu_296399_p2 = (!mult_66_V_fu_292164_p1.read().is_01() || !mult_26_V_fu_291425_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_66_V_fu_292164_p1.read()) + sc_bigint<16>(mult_26_V_fu_291425_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_403_fu_296405_p2() {
    add_ln703_403_fu_296405_p2 = (!trunc_ln708_222_fu_295599_p4.read().is_01() || !add_ln703_402_fu_296399_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln708_222_fu_295599_p4.read()) + sc_biguint<16>(add_ln703_402_fu_296399_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_404_fu_296411_p2() {
    add_ln703_404_fu_296411_p2 = (!add_ln703_401_fu_296393_p2.read().is_01() || !add_ln703_403_fu_296405_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_401_fu_296393_p2.read()) + sc_biguint<16>(add_ln703_403_fu_296405_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_405_fu_296417_p2() {
    add_ln703_405_fu_296417_p2 = (!add_ln703_400_fu_296387_p2.read().is_01() || !add_ln703_404_fu_296411_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_400_fu_296387_p2.read()) + sc_biguint<16>(add_ln703_404_fu_296411_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_406_fu_296423_p2() {
    add_ln703_406_fu_296423_p2 = (!add_ln703_397_fu_296369_p2.read().is_01() || !add_ln703_405_fu_296417_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_397_fu_296369_p2.read()) + sc_biguint<16>(add_ln703_405_fu_296417_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_407_fu_296429_p2() {
    add_ln703_407_fu_296429_p2 = (!mult_82_V_fu_292405_p1.read().is_01() || !mult_74_V_fu_292270_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_82_V_fu_292405_p1.read()) + sc_bigint<16>(mult_74_V_fu_292270_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_408_fu_296435_p2() {
    add_ln703_408_fu_296435_p2 = (!mult_130_V_fu_293231_p1.read().is_01() || !mult_98_V_fu_292715_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_130_V_fu_293231_p1.read()) + sc_bigint<16>(mult_98_V_fu_292715_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_409_fu_296441_p2() {
    add_ln703_409_fu_296441_p2 = (!add_ln703_407_fu_296429_p2.read().is_01() || !add_ln703_408_fu_296435_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_407_fu_296429_p2.read()) + sc_biguint<16>(add_ln703_408_fu_296435_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_410_fu_296447_p2() {
    add_ln703_410_fu_296447_p2 = (!mult_186_V_fu_294086_p1.read().is_01() || !mult_138_V_fu_293372_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_186_V_fu_294086_p1.read()) + sc_bigint<16>(mult_138_V_fu_293372_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_411_fu_296453_p2() {
    add_ln703_411_fu_296453_p2 = (!sext_ln708_2_fu_295741_p1.read().is_01() || !mult_258_V_fu_295325_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln708_2_fu_295741_p1.read()) + sc_bigint<16>(mult_258_V_fu_295325_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_412_fu_296459_p2() {
    add_ln703_412_fu_296459_p2 = (!mult_226_V_fu_294807_p1.read().is_01() || !add_ln703_411_fu_296453_p2.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_226_V_fu_294807_p1.read()) + sc_biguint<16>(add_ln703_411_fu_296453_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_413_fu_296465_p2() {
    add_ln703_413_fu_296465_p2 = (!add_ln703_410_fu_296447_p2.read().is_01() || !add_ln703_412_fu_296459_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_410_fu_296447_p2.read()) + sc_biguint<16>(add_ln703_412_fu_296459_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_414_fu_296471_p2() {
    add_ln703_414_fu_296471_p2 = (!add_ln703_409_fu_296441_p2.read().is_01() || !add_ln703_413_fu_296465_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_409_fu_296441_p2.read()) + sc_biguint<16>(add_ln703_413_fu_296465_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_415_fu_296477_p2() {
    add_ln703_415_fu_296477_p2 = (!sext_ln203_93_fu_292010_p1.read().is_01() || !sext_ln203_91_fu_291852_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_93_fu_292010_p1.read()) + sc_bigint<15>(sext_ln203_91_fu_291852_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_416_fu_296487_p2() {
    add_ln703_416_fu_296487_p2 = (!sext_ln203_128_fu_294372_p1.read().is_01() || !sext_ln203_74_fu_291002_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_128_fu_294372_p1.read()) + sc_bigint<12>(sext_ln203_74_fu_291002_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_417_fu_296497_p2() {
    add_ln703_417_fu_296497_p2 = (!sext_ln203_134_fu_294665_p1.read().is_01() || !sext_ln703_86_fu_296493_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_134_fu_294665_p1.read()) + sc_bigint<15>(sext_ln703_86_fu_296493_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_418_fu_296507_p2() {
    add_ln703_418_fu_296507_p2 = (!sext_ln703_85_fu_296483_p1.read().is_01() || !sext_ln703_87_fu_296503_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_85_fu_296483_p1.read()) + sc_bigint<16>(sext_ln703_87_fu_296503_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_419_fu_296513_p2() {
    add_ln703_419_fu_296513_p2 = (!sext_ln1118_219_fu_293130_p1.read().is_01() || !sext_ln1118_220_fu_294546_p1.read().is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln1118_219_fu_293130_p1.read()) + sc_bigint<11>(sext_ln1118_220_fu_294546_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_420_fu_296523_p2() {
    add_ln703_420_fu_296523_p2 = (!sext_ln203_124_fu_294226_p1.read().is_01() || !ap_const_lv8_B7.is_01())? sc_lv<8>(): (sc_bigint<8>(sext_ln203_124_fu_294226_p1.read()) + sc_bigint<8>(ap_const_lv8_B7));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_421_fu_296533_p2() {
    add_ln703_421_fu_296533_p2 = (!sext_ln203_78_fu_291301_p1.read().is_01() || !zext_ln703_1_fu_296529_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_78_fu_291301_p1.read()) + sc_biguint<10>(zext_ln703_1_fu_296529_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_422_fu_296543_p2() {
    add_ln703_422_fu_296543_p2 = (!sext_ln703_111_fu_296519_p1.read().is_01() || !sext_ln703_88_fu_296539_p1.read().is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln703_111_fu_296519_p1.read()) + sc_bigint<12>(sext_ln703_88_fu_296539_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_423_fu_296553_p2() {
    add_ln703_423_fu_296553_p2 = (!add_ln703_418_fu_296507_p2.read().is_01() || !sext_ln703_89_fu_296549_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_418_fu_296507_p2.read()) + sc_bigint<16>(sext_ln703_89_fu_296549_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_424_fu_296559_p2() {
    add_ln703_424_fu_296559_p2 = (!add_ln703_414_fu_296471_p2.read().is_01() || !add_ln703_423_fu_296553_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_414_fu_296471_p2.read()) + sc_biguint<16>(add_ln703_423_fu_296553_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_426_fu_296571_p2() {
    add_ln703_426_fu_296571_p2 = (!mult_11_V_fu_291125_p4.read().is_01() || !mult_3_V_fu_291006_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_11_V_fu_291125_p4.read()) + sc_biguint<16>(mult_3_V_fu_291006_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_427_fu_296577_p2() {
    add_ln703_427_fu_296577_p2 = (!mult_27_V_fu_291429_p4.read().is_01() || !mult_19_V_fu_291305_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_27_V_fu_291429_p4.read()) + sc_biguint<16>(mult_19_V_fu_291305_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_428_fu_296583_p2() {
    add_ln703_428_fu_296583_p2 = (!add_ln703_426_fu_296571_p2.read().is_01() || !add_ln703_427_fu_296577_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_426_fu_296571_p2.read()) + sc_biguint<16>(add_ln703_427_fu_296577_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_429_fu_296589_p2() {
    add_ln703_429_fu_296589_p2 = (!mult_59_V_fu_292014_p4.read().is_01() || !mult_51_V_fu_291856_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_59_V_fu_292014_p4.read()) + sc_biguint<16>(mult_51_V_fu_291856_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_430_fu_296595_p2() {
    add_ln703_430_fu_296595_p2 = (!mult_107_V_fu_292866_p4.read().is_01() || !mult_91_V_fu_292573_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_107_V_fu_292866_p4.read()) + sc_biguint<16>(mult_91_V_fu_292573_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_431_fu_296601_p2() {
    add_ln703_431_fu_296601_p2 = (!mult_75_V_fu_292274_p4.read().is_01() || !add_ln703_430_fu_296595_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_75_V_fu_292274_p4.read()) + sc_biguint<16>(add_ln703_430_fu_296595_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_432_fu_296607_p2() {
    add_ln703_432_fu_296607_p2 = (!add_ln703_429_fu_296589_p2.read().is_01() || !add_ln703_431_fu_296601_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_429_fu_296589_p2.read()) + sc_biguint<16>(add_ln703_431_fu_296601_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_433_fu_296613_p2() {
    add_ln703_433_fu_296613_p2 = (!add_ln703_428_fu_296583_p2.read().is_01() || !add_ln703_432_fu_296607_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_428_fu_296583_p2.read()) + sc_biguint<16>(add_ln703_432_fu_296607_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_434_fu_296619_p2() {
    add_ln703_434_fu_296619_p2 = (!mult_171_V_fu_293826_p4.read().is_01() || !mult_139_V_fu_293376_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_171_V_fu_293826_p4.read()) + sc_biguint<16>(mult_139_V_fu_293376_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_435_fu_296625_p2() {
    add_ln703_435_fu_296625_p2 = (!mult_211_V_fu_294550_p4.read().is_01() || !mult_195_V_fu_294230_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_211_V_fu_294550_p4.read()) + sc_biguint<16>(mult_195_V_fu_294230_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_436_fu_296631_p2() {
    add_ln703_436_fu_296631_p2 = (!add_ln703_434_fu_296619_p2.read().is_01() || !add_ln703_435_fu_296625_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_434_fu_296619_p2.read()) + sc_biguint<16>(add_ln703_435_fu_296625_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_437_fu_296637_p2() {
    add_ln703_437_fu_296637_p2 = (!mult_243_V_fu_295069_p4.read().is_01() || !mult_227_V_fu_294811_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_243_V_fu_295069_p4.read()) + sc_biguint<16>(mult_227_V_fu_294811_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_438_fu_296643_p2() {
    add_ln703_438_fu_296643_p2 = (!mult_83_V_fu_292419_p1.read().is_01() || !mult_267_V_fu_295462_p4.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_83_V_fu_292419_p1.read()) + sc_biguint<16>(mult_267_V_fu_295462_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_439_fu_296649_p2() {
    add_ln703_439_fu_296649_p2 = (!mult_259_V_fu_295329_p4.read().is_01() || !add_ln703_438_fu_296643_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_259_V_fu_295329_p4.read()) + sc_biguint<16>(add_ln703_438_fu_296643_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_440_fu_296655_p2() {
    add_ln703_440_fu_296655_p2 = (!add_ln703_437_fu_296637_p2.read().is_01() || !add_ln703_439_fu_296649_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_437_fu_296637_p2.read()) + sc_biguint<16>(add_ln703_439_fu_296649_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_441_fu_296661_p2() {
    add_ln703_441_fu_296661_p2 = (!add_ln703_436_fu_296631_p2.read().is_01() || !add_ln703_440_fu_296655_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_436_fu_296631_p2.read()) + sc_biguint<16>(add_ln703_440_fu_296655_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_442_fu_296667_p2() {
    add_ln703_442_fu_296667_p2 = (!add_ln703_433_fu_296613_p2.read().is_01() || !add_ln703_441_fu_296661_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_433_fu_296613_p2.read()) + sc_biguint<16>(add_ln703_441_fu_296661_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_443_fu_296673_p2() {
    add_ln703_443_fu_296673_p2 = (!mult_147_V_fu_293520_p1.read().is_01() || !mult_131_V_fu_293245_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_147_V_fu_293520_p1.read()) + sc_bigint<16>(mult_131_V_fu_293245_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_444_fu_296679_p2() {
    add_ln703_444_fu_296679_p2 = (!mult_179_V_fu_293976_p1.read().is_01() || !mult_155_V_fu_293627_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_179_V_fu_293976_p1.read()) + sc_bigint<16>(mult_155_V_fu_293627_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_445_fu_296685_p2() {
    add_ln703_445_fu_296685_p2 = (!add_ln703_443_fu_296673_p2.read().is_01() || !add_ln703_444_fu_296679_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_443_fu_296673_p2.read()) + sc_biguint<16>(add_ln703_444_fu_296679_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_446_fu_296691_p2() {
    add_ln703_446_fu_296691_p2 = (!mult_203_V_fu_294386_p1.read().is_01() || !mult_187_V_fu_294100_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_203_V_fu_294386_p1.read()) + sc_bigint<16>(mult_187_V_fu_294100_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_447_fu_296697_p2() {
    add_ln703_447_fu_296697_p2 = (!sext_ln203_113_fu_293144_p1.read().is_01() || !sext_ln203_106_fu_292729_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_113_fu_293144_p1.read()) + sc_bigint<15>(sext_ln203_106_fu_292729_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_448_fu_296707_p2() {
    add_ln703_448_fu_296707_p2 = (!mult_248_V_fu_295204_p1.read().is_01() || !sext_ln703_90_fu_296703_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_248_V_fu_295204_p1.read()) + sc_bigint<16>(sext_ln703_90_fu_296703_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_449_fu_296713_p2() {
    add_ln703_449_fu_296713_p2 = (!add_ln703_446_fu_296691_p2.read().is_01() || !add_ln703_448_fu_296707_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_446_fu_296691_p2.read()) + sc_biguint<16>(add_ln703_448_fu_296707_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_450_fu_296719_p2() {
    add_ln703_450_fu_296719_p2 = (!add_ln703_445_fu_296685_p2.read().is_01() || !add_ln703_449_fu_296713_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_445_fu_296685_p2.read()) + sc_biguint<16>(add_ln703_449_fu_296713_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_451_fu_296725_p2() {
    add_ln703_451_fu_296725_p2 = (!sext_ln203_110_fu_292988_p1.read().is_01() || !sext_ln203_84_fu_291572_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_110_fu_292988_p1.read()) + sc_bigint<14>(sext_ln203_84_fu_291572_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_452_fu_296735_p2() {
    add_ln703_452_fu_296735_p2 = (!sext_ln1118_208_fu_295619_p1.read().is_01() || !sext_ln203_140_fu_294936_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln1118_208_fu_295619_p1.read()) + sc_bigint<14>(sext_ln203_140_fu_294936_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_453_fu_296745_p2() {
    add_ln703_453_fu_296745_p2 = (!sext_ln203_116_fu_293725_p1.read().is_01() || !sext_ln703_92_fu_296741_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_116_fu_293725_p1.read()) + sc_bigint<15>(sext_ln703_92_fu_296741_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_454_fu_296755_p2() {
    add_ln703_454_fu_296755_p2 = (!sext_ln703_91_fu_296731_p1.read().is_01() || !sext_ln703_93_fu_296751_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_91_fu_296731_p1.read()) + sc_bigint<16>(sext_ln703_93_fu_296751_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_455_fu_296761_p2() {
    add_ln703_455_fu_296761_p2 = (!sext_ln203_135_fu_294697_p1.read().is_01() || !sext_ln203_95_fu_292178_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_135_fu_294697_p1.read()) + sc_bigint<13>(sext_ln203_95_fu_292178_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_456_fu_296771_p2() {
    add_ln703_456_fu_296771_p2 = (!sext_ln1118_211_fu_295755_p1.read().is_01() || !sext_ln203_86_fu_291712_p1.read().is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln1118_211_fu_295755_p1.read()) + sc_bigint<10>(sext_ln203_86_fu_291712_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_457_fu_296781_p2() {
    add_ln703_457_fu_296781_p2 = (!sext_ln703_95_fu_296777_p1.read().is_01() || !ap_const_lv11_124.is_01())? sc_lv<11>(): (sc_bigint<11>(sext_ln703_95_fu_296777_p1.read()) + sc_biguint<11>(ap_const_lv11_124));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_458_fu_296791_p2() {
    add_ln703_458_fu_296791_p2 = (!sext_ln703_94_fu_296767_p1.read().is_01() || !sext_ln703_96_fu_296787_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_94_fu_296767_p1.read()) + sc_bigint<14>(sext_ln703_96_fu_296787_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_459_fu_296801_p2() {
    add_ln703_459_fu_296801_p2 = (!add_ln703_454_fu_296755_p2.read().is_01() || !sext_ln703_97_fu_296797_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_454_fu_296755_p2.read()) + sc_bigint<16>(sext_ln703_97_fu_296797_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_460_fu_296807_p2() {
    add_ln703_460_fu_296807_p2 = (!add_ln703_450_fu_296719_p2.read().is_01() || !add_ln703_459_fu_296801_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_450_fu_296719_p2.read()) + sc_biguint<16>(add_ln703_459_fu_296801_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_462_fu_296819_p2() {
    add_ln703_462_fu_296819_p2 = (!mult_28_V_fu_291439_p4.read().is_01() || !mult_20_V_fu_291315_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_28_V_fu_291439_p4.read()) + sc_biguint<16>(mult_20_V_fu_291315_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_463_fu_296825_p2() {
    add_ln703_463_fu_296825_p2 = (!mult_92_V_fu_292583_p4.read().is_01() || !mult_68_V_fu_292182_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_92_V_fu_292583_p4.read()) + sc_biguint<16>(mult_68_V_fu_292182_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_464_fu_296831_p2() {
    add_ln703_464_fu_296831_p2 = (!add_ln703_462_fu_296819_p2.read().is_01() || !add_ln703_463_fu_296825_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_462_fu_296819_p2.read()) + sc_biguint<16>(add_ln703_463_fu_296825_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_465_fu_296837_p2() {
    add_ln703_465_fu_296837_p2 = (!mult_140_V_fu_293386_p4.read().is_01() || !mult_108_V_fu_292876_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_140_V_fu_293386_p4.read()) + sc_biguint<16>(mult_108_V_fu_292876_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_466_fu_296843_p2() {
    add_ln703_466_fu_296843_p2 = (!mult_180_V_fu_293980_p4.read().is_01() || !mult_172_V_fu_293836_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_180_V_fu_293980_p4.read()) + sc_biguint<16>(mult_172_V_fu_293836_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_467_fu_296849_p2() {
    add_ln703_467_fu_296849_p2 = (!mult_156_V_fu_293631_p4.read().is_01() || !add_ln703_466_fu_296843_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_156_V_fu_293631_p4.read()) + sc_biguint<16>(add_ln703_466_fu_296843_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_468_fu_296855_p2() {
    add_ln703_468_fu_296855_p2 = (!add_ln703_465_fu_296837_p2.read().is_01() || !add_ln703_467_fu_296849_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_465_fu_296837_p2.read()) + sc_biguint<16>(add_ln703_467_fu_296849_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_469_fu_296861_p2() {
    add_ln703_469_fu_296861_p2 = (!add_ln703_464_fu_296831_p2.read().is_01() || !add_ln703_468_fu_296855_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_464_fu_296831_p2.read()) + sc_biguint<16>(add_ln703_468_fu_296855_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_470_fu_296867_p2() {
    add_ln703_470_fu_296867_p2 = (!mult_204_V_fu_294390_p4.read().is_01() || !mult_188_V_fu_294104_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_204_V_fu_294390_p4.read()) + sc_biguint<16>(mult_188_V_fu_294104_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_471_fu_296873_p2() {
    add_ln703_471_fu_296873_p2 = (!mult_220_V_fu_294701_p4.read().is_01() || !mult_212_V_fu_294560_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_220_V_fu_294701_p4.read()) + sc_biguint<16>(mult_212_V_fu_294560_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_472_fu_296879_p2() {
    add_ln703_472_fu_296879_p2 = (!add_ln703_470_fu_296867_p2.read().is_01() || !add_ln703_471_fu_296873_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_470_fu_296867_p2.read()) + sc_biguint<16>(add_ln703_471_fu_296873_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_473_fu_296885_p2() {
    add_ln703_473_fu_296885_p2 = (!mult_236_V_fu_294940_p4.read().is_01() || !mult_228_V_fu_294821_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_236_V_fu_294940_p4.read()) + sc_biguint<16>(mult_228_V_fu_294821_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_474_fu_296891_p2() {
    add_ln703_474_fu_296891_p2 = (!mult_4_V_fu_291026_p1.read().is_01() || !trunc_ln708_232_fu_295759_p4.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_4_V_fu_291026_p1.read()) + sc_biguint<16>(trunc_ln708_232_fu_295759_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_475_fu_296897_p2() {
    add_ln703_475_fu_296897_p2 = (!trunc_ln708_224_fu_295623_p4.read().is_01() || !add_ln703_474_fu_296891_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln708_224_fu_295623_p4.read()) + sc_biguint<16>(add_ln703_474_fu_296891_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_476_fu_296903_p2() {
    add_ln703_476_fu_296903_p2 = (!add_ln703_473_fu_296885_p2.read().is_01() || !add_ln703_475_fu_296897_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_473_fu_296885_p2.read()) + sc_biguint<16>(add_ln703_475_fu_296897_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_477_fu_296909_p2() {
    add_ln703_477_fu_296909_p2 = (!add_ln703_472_fu_296879_p2.read().is_01() || !add_ln703_476_fu_296903_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_472_fu_296879_p2.read()) + sc_biguint<16>(add_ln703_476_fu_296903_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_478_fu_296915_p2() {
    add_ln703_478_fu_296915_p2 = (!add_ln703_469_fu_296861_p2.read().is_01() || !add_ln703_477_fu_296909_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_469_fu_296861_p2.read()) + sc_biguint<16>(add_ln703_477_fu_296909_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_479_fu_296921_p2() {
    add_ln703_479_fu_296921_p2 = (!mult_52_V_fu_291876_p1.read().is_01() || !mult_36_V_fu_291586_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_52_V_fu_291876_p1.read()) + sc_bigint<16>(mult_36_V_fu_291586_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_480_fu_296927_p2() {
    add_ln703_480_fu_296927_p2 = (!mult_116_V_fu_293002_p1.read().is_01() || !mult_60_V_fu_292034_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_116_V_fu_293002_p1.read()) + sc_bigint<16>(mult_60_V_fu_292034_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_481_fu_296933_p2() {
    add_ln703_481_fu_296933_p2 = (!add_ln703_479_fu_296921_p2.read().is_01() || !add_ln703_480_fu_296927_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_479_fu_296921_p2.read()) + sc_biguint<16>(add_ln703_480_fu_296927_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_482_fu_296939_p2() {
    add_ln703_482_fu_296939_p2 = (!mult_164_V_fu_293739_p1.read().is_01() || !mult_148_V_fu_293534_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_164_V_fu_293739_p1.read()) + sc_bigint<16>(mult_148_V_fu_293534_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_483_fu_296945_p2() {
    add_ln703_483_fu_296945_p2 = (!sext_ln203_141_fu_295089_p1.read().is_01() || !sext_ln203_113_fu_293144_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_141_fu_295089_p1.read()) + sc_bigint<15>(sext_ln203_113_fu_293144_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_484_fu_296955_p2() {
    add_ln703_484_fu_296955_p2 = (!mult_100_V_fu_292743_p1.read().is_01() || !sext_ln703_98_fu_296951_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_100_V_fu_292743_p1.read()) + sc_bigint<16>(sext_ln703_98_fu_296951_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_485_fu_296961_p2() {
    add_ln703_485_fu_296961_p2 = (!add_ln703_482_fu_296939_p2.read().is_01() || !add_ln703_484_fu_296955_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_482_fu_296939_p2.read()) + sc_biguint<16>(add_ln703_484_fu_296955_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_486_fu_296967_p2() {
    add_ln703_486_fu_296967_p2 = (!add_ln703_481_fu_296933_p2.read().is_01() || !add_ln703_485_fu_296961_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_481_fu_296933_p2.read()) + sc_biguint<16>(add_ln703_485_fu_296961_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_487_fu_296973_p2() {
    add_ln703_487_fu_296973_p2 = (!sext_ln203_145_fu_295379_p1.read().is_01() || !sext_ln203_144_fu_295242_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_145_fu_295379_p1.read()) + sc_bigint<15>(sext_ln203_144_fu_295242_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_488_fu_296983_p2() {
    add_ln703_488_fu_296983_p2 = (!sext_ln203_100_fu_292433_p1.read().is_01() || !sext_ln203_97_fu_292294_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_100_fu_292433_p1.read()) + sc_bigint<14>(sext_ln203_97_fu_292294_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_489_fu_296993_p2() {
    add_ln703_489_fu_296993_p2 = (!sext_ln1118_204_fu_295482_p1.read().is_01() || !sext_ln703_100_fu_296989_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_204_fu_295482_p1.read()) + sc_bigint<15>(sext_ln703_100_fu_296989_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_490_fu_297003_p2() {
    add_ln703_490_fu_297003_p2 = (!sext_ln703_99_fu_296979_p1.read().is_01() || !sext_ln703_101_fu_296999_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_99_fu_296979_p1.read()) + sc_bigint<16>(sext_ln703_101_fu_296999_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_491_fu_297009_p2() {
    add_ln703_491_fu_297009_p2 = (!sext_ln203_87_fu_291748_p1.read().is_01() || !sext_ln203_114_fu_293259_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_87_fu_291748_p1.read()) + sc_bigint<14>(sext_ln203_114_fu_293259_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_492_fu_297019_p2() {
    add_ln703_492_fu_297019_p2 = (!sext_ln203_75_fu_291145_p1.read().is_01() || !ap_const_lv12_FC.is_01())? sc_lv<12>(): (sc_bigint<12>(sext_ln203_75_fu_291145_p1.read()) + sc_biguint<12>(ap_const_lv12_FC));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_493_fu_297029_p2() {
    add_ln703_493_fu_297029_p2 = (!sext_ln203_125_fu_294268_p1.read().is_01() || !sext_ln703_103_fu_297025_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_125_fu_294268_p1.read()) + sc_bigint<13>(sext_ln703_103_fu_297025_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_494_fu_297039_p2() {
    add_ln703_494_fu_297039_p2 = (!sext_ln703_102_fu_297015_p1.read().is_01() || !sext_ln703_104_fu_297035_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_102_fu_297015_p1.read()) + sc_bigint<15>(sext_ln703_104_fu_297035_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_495_fu_297049_p2() {
    add_ln703_495_fu_297049_p2 = (!add_ln703_490_fu_297003_p2.read().is_01() || !sext_ln703_105_fu_297045_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_490_fu_297003_p2.read()) + sc_bigint<16>(sext_ln703_105_fu_297045_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_496_fu_297055_p2() {
    add_ln703_496_fu_297055_p2 = (!add_ln703_486_fu_296967_p2.read().is_01() || !add_ln703_495_fu_297049_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_486_fu_296967_p2.read()) + sc_biguint<16>(add_ln703_495_fu_297049_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_498_fu_297067_p2() {
    add_ln703_498_fu_297067_p2 = (!mult_29_V_fu_291449_p4.read().is_01() || !mult_5_V_fu_291030_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_29_V_fu_291449_p4.read()) + sc_biguint<16>(mult_5_V_fu_291030_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_499_fu_297073_p2() {
    add_ln703_499_fu_297073_p2 = (!mult_53_V_fu_291880_p4.read().is_01() || !mult_45_V_fu_291752_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_53_V_fu_291880_p4.read()) + sc_biguint<16>(mult_45_V_fu_291752_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_500_fu_297079_p2() {
    add_ln703_500_fu_297079_p2 = (!add_ln703_498_fu_297067_p2.read().is_01() || !add_ln703_499_fu_297073_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_498_fu_297067_p2.read()) + sc_biguint<16>(add_ln703_499_fu_297073_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_501_fu_297085_p2() {
    add_ln703_501_fu_297085_p2 = (!mult_77_V_fu_292298_p4.read().is_01() || !mult_69_V_fu_292192_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_77_V_fu_292298_p4.read()) + sc_biguint<16>(mult_69_V_fu_292192_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_502_fu_297091_p2() {
    add_ln703_502_fu_297091_p2 = (!mult_133_V_fu_293263_p4.read().is_01() || !mult_125_V_fu_293148_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_133_V_fu_293263_p4.read()) + sc_biguint<16>(mult_125_V_fu_293148_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_503_fu_297097_p2() {
    add_ln703_503_fu_297097_p2 = (!mult_85_V_fu_292437_p4.read().is_01() || !add_ln703_502_fu_297091_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_85_V_fu_292437_p4.read()) + sc_biguint<16>(add_ln703_502_fu_297091_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_504_fu_297103_p2() {
    add_ln703_504_fu_297103_p2 = (!add_ln703_501_fu_297085_p2.read().is_01() || !add_ln703_503_fu_297097_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_501_fu_297085_p2.read()) + sc_biguint<16>(add_ln703_503_fu_297097_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_505_fu_297109_p2() {
    add_ln703_505_fu_297109_p2 = (!add_ln703_500_fu_297079_p2.read().is_01() || !add_ln703_504_fu_297103_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_500_fu_297079_p2.read()) + sc_biguint<16>(add_ln703_504_fu_297103_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_506_fu_297115_p2() {
    add_ln703_506_fu_297115_p2 = (!mult_165_V_fu_293743_p4.read().is_01() || !mult_149_V_fu_293538_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_165_V_fu_293743_p4.read()) + sc_biguint<16>(mult_149_V_fu_293538_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_507_fu_297121_p2() {
    add_ln703_507_fu_297121_p2 = (!mult_181_V_fu_293990_p4.read().is_01() || !mult_173_V_fu_293846_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_181_V_fu_293990_p4.read()) + sc_biguint<16>(mult_173_V_fu_293846_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_508_fu_297127_p2() {
    add_ln703_508_fu_297127_p2 = (!add_ln703_506_fu_297115_p2.read().is_01() || !add_ln703_507_fu_297121_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_506_fu_297115_p2.read()) + sc_biguint<16>(add_ln703_507_fu_297121_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_509_fu_297133_p2() {
    add_ln703_509_fu_297133_p2 = (!mult_253_V_fu_295246_p4.read().is_01() || !mult_213_V_fu_294570_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_253_V_fu_295246_p4.read()) + sc_biguint<16>(mult_213_V_fu_294570_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_510_fu_297139_p2() {
    add_ln703_510_fu_297139_p2 = (!trunc_ln708_233_fu_295769_p4.read().is_01() || !trunc_ln708_225_fu_295633_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln708_233_fu_295769_p4.read()) + sc_biguint<16>(trunc_ln708_225_fu_295633_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_511_fu_297145_p2() {
    add_ln703_511_fu_297145_p2 = (!mult_261_V_fu_295383_p4.read().is_01() || !add_ln703_510_fu_297139_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_261_V_fu_295383_p4.read()) + sc_biguint<16>(add_ln703_510_fu_297139_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_512_fu_297151_p2() {
    add_ln703_512_fu_297151_p2 = (!add_ln703_509_fu_297133_p2.read().is_01() || !add_ln703_511_fu_297145_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_509_fu_297133_p2.read()) + sc_biguint<16>(add_ln703_511_fu_297145_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_513_fu_297157_p2() {
    add_ln703_513_fu_297157_p2 = (!add_ln703_508_fu_297127_p2.read().is_01() || !add_ln703_512_fu_297151_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_508_fu_297127_p2.read()) + sc_biguint<16>(add_ln703_512_fu_297151_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_514_fu_297163_p2() {
    add_ln703_514_fu_297163_p2 = (!add_ln703_505_fu_297109_p2.read().is_01() || !add_ln703_513_fu_297157_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_505_fu_297109_p2.read()) + sc_biguint<16>(add_ln703_513_fu_297157_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_515_fu_297169_p2() {
    add_ln703_515_fu_297169_p2 = (!mult_109_V_fu_292896_p1.read().is_01() || !mult_61_V_fu_292066_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_109_V_fu_292896_p1.read()) + sc_bigint<16>(mult_61_V_fu_292066_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_516_fu_297175_p2() {
    add_ln703_516_fu_297175_p2 = (!mult_153_V_fu_293603_p1.read().is_01() || !mult_141_V_fu_293436_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_153_V_fu_293603_p1.read()) + sc_bigint<16>(mult_141_V_fu_293436_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_517_fu_297181_p2() {
    add_ln703_517_fu_297181_p2 = (!add_ln703_515_fu_297169_p2.read().is_01() || !add_ln703_516_fu_297175_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_515_fu_297169_p2.read()) + sc_biguint<16>(add_ln703_516_fu_297175_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_518_fu_297187_p2() {
    add_ln703_518_fu_297187_p2 = (!mult_221_V_fu_294721_p1.read().is_01() || !mult_197_V_fu_294282_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_221_V_fu_294721_p1.read()) + sc_bigint<16>(mult_197_V_fu_294282_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_519_fu_297193_p2() {
    add_ln703_519_fu_297193_p2 = (!sext_ln203_107_fu_292757_p1.read().is_01() || !sext_ln203_85_fu_291600_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_107_fu_292757_p1.read()) + sc_bigint<15>(sext_ln203_85_fu_291600_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_520_fu_297203_p2() {
    add_ln703_520_fu_297203_p2 = (!mult_245_V_fu_295103_p1.read().is_01() || !sext_ln703_106_fu_297199_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_245_V_fu_295103_p1.read()) + sc_bigint<16>(sext_ln703_106_fu_297199_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_521_fu_297209_p2() {
    add_ln703_521_fu_297209_p2 = (!add_ln703_518_fu_297187_p2.read().is_01() || !add_ln703_520_fu_297203_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_518_fu_297187_p2.read()) + sc_biguint<16>(add_ln703_520_fu_297203_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_522_fu_297215_p2() {
    add_ln703_522_fu_297215_p2 = (!add_ln703_517_fu_297181_p2.read().is_01() || !add_ln703_521_fu_297209_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_517_fu_297181_p2.read()) + sc_biguint<16>(add_ln703_521_fu_297209_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_523_fu_297221_p2() {
    add_ln703_523_fu_297221_p2 = (!sext_ln203_129_fu_294410_p1.read().is_01() || !sext_ln203_120_fu_294124_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_129_fu_294410_p1.read()) + sc_bigint<15>(sext_ln203_120_fu_294124_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_524_fu_297231_p2() {
    add_ln703_524_fu_297231_p2 = (!sext_ln203_138_fu_294841_p1.read().is_01() || !sext_ln203_111_fu_293016_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_138_fu_294841_p1.read()) + sc_bigint<14>(sext_ln203_111_fu_293016_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_525_fu_297241_p2() {
    add_ln703_525_fu_297241_p2 = (!sext_ln1118_205_fu_295496_p1.read().is_01() || !sext_ln703_108_fu_297237_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln1118_205_fu_295496_p1.read()) + sc_bigint<15>(sext_ln703_108_fu_297237_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_526_fu_297251_p2() {
    add_ln703_526_fu_297251_p2 = (!sext_ln703_107_fu_297227_p1.read().is_01() || !sext_ln703_109_fu_297247_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_107_fu_297227_p1.read()) + sc_bigint<16>(sext_ln703_109_fu_297247_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_527_fu_297257_p2() {
    add_ln703_527_fu_297257_p2 = (!sext_ln1118_218_fu_291195_p1.read().is_01() || !sext_ln1118_221_fu_294984_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_218_fu_291195_p1.read()) + sc_bigint<13>(sext_ln1118_221_fu_294984_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_528_fu_297267_p2() {
    add_ln703_528_fu_297267_p2 = (!sext_ln203_79_fu_291335_p1.read().is_01() || !ap_const_lv10_237.is_01())? sc_lv<10>(): (sc_bigint<10>(sext_ln203_79_fu_291335_p1.read()) + sc_bigint<10>(ap_const_lv10_237));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_529_fu_297277_p2() {
    add_ln703_529_fu_297277_p2 = (!sext_ln203_104_fu_292633_p1.read().is_01() || !zext_ln703_2_fu_297273_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_104_fu_292633_p1.read()) + sc_biguint<13>(zext_ln703_2_fu_297273_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_530_fu_297287_p2() {
    add_ln703_530_fu_297287_p2 = (!sext_ln703_122_fu_297263_p1.read().is_01() || !sext_ln703_123_fu_297283_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln703_122_fu_297263_p1.read()) + sc_bigint<14>(sext_ln703_123_fu_297283_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_531_fu_297297_p2() {
    add_ln703_531_fu_297297_p2 = (!add_ln703_526_fu_297251_p2.read().is_01() || !sext_ln703_112_fu_297293_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_526_fu_297251_p2.read()) + sc_bigint<16>(sext_ln703_112_fu_297293_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_532_fu_297303_p2() {
    add_ln703_532_fu_297303_p2 = (!add_ln703_522_fu_297215_p2.read().is_01() || !add_ln703_531_fu_297297_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_522_fu_297215_p2.read()) + sc_biguint<16>(add_ln703_531_fu_297297_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_534_fu_297315_p2() {
    add_ln703_534_fu_297315_p2 = (!mult_78_V_fu_292308_p4.read().is_01() || !mult_54_V_fu_291890_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_78_V_fu_292308_p4.read()) + sc_biguint<16>(mult_54_V_fu_291890_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_535_fu_297321_p2() {
    add_ln703_535_fu_297321_p2 = (!mult_110_V_fu_292900_p4.read().is_01() || !mult_86_V_fu_292447_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_110_V_fu_292900_p4.read()) + sc_biguint<16>(mult_86_V_fu_292447_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_536_fu_297327_p2() {
    add_ln703_536_fu_297327_p2 = (!add_ln703_534_fu_297315_p2.read().is_01() || !add_ln703_535_fu_297321_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_534_fu_297315_p2.read()) + sc_biguint<16>(add_ln703_535_fu_297321_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_537_fu_297333_p2() {
    add_ln703_537_fu_297333_p2 = (!mult_126_V_fu_293158_p4.read().is_01() || !mult_118_V_fu_293020_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_126_V_fu_293158_p4.read()) + sc_biguint<16>(mult_118_V_fu_293020_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_538_fu_297339_p2() {
    add_ln703_538_fu_297339_p2 = (!mult_158_V_fu_293641_p4.read().is_01() || !mult_150_V_fu_293548_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_158_V_fu_293641_p4.read()) + sc_biguint<16>(mult_150_V_fu_293548_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_539_fu_297345_p2() {
    add_ln703_539_fu_297345_p2 = (!mult_142_V_fu_293440_p4.read().is_01() || !add_ln703_538_fu_297339_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_142_V_fu_293440_p4.read()) + sc_biguint<16>(add_ln703_538_fu_297339_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_540_fu_297351_p2() {
    add_ln703_540_fu_297351_p2 = (!add_ln703_537_fu_297333_p2.read().is_01() || !add_ln703_539_fu_297345_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_537_fu_297333_p2.read()) + sc_biguint<16>(add_ln703_539_fu_297345_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_541_fu_297357_p2() {
    add_ln703_541_fu_297357_p2 = (!add_ln703_536_fu_297327_p2.read().is_01() || !add_ln703_540_fu_297351_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_536_fu_297327_p2.read()) + sc_biguint<16>(add_ln703_540_fu_297351_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_542_fu_297363_p2() {
    add_ln703_542_fu_297363_p2 = (!mult_174_V_fu_293856_p4.read().is_01() || !mult_166_V_fu_293753_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_174_V_fu_293856_p4.read()) + sc_biguint<16>(mult_166_V_fu_293753_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_543_fu_297369_p2() {
    add_ln703_543_fu_297369_p2 = (!mult_198_V_fu_294286_p4.read().is_01() || !mult_182_V_fu_294000_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_198_V_fu_294286_p4.read()) + sc_biguint<16>(mult_182_V_fu_294000_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_544_fu_297375_p2() {
    add_ln703_544_fu_297375_p2 = (!add_ln703_542_fu_297363_p2.read().is_01() || !add_ln703_543_fu_297369_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_542_fu_297363_p2.read()) + sc_biguint<16>(add_ln703_543_fu_297369_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_545_fu_297381_p2() {
    add_ln703_545_fu_297381_p2 = (!mult_246_V_fu_295153_p1.read().is_01() || !mult_206_V_fu_294414_p4.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_246_V_fu_295153_p1.read()) + sc_biguint<16>(mult_206_V_fu_294414_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_546_fu_297387_p2() {
    add_ln703_546_fu_297387_p2 = (!trunc_ln708_234_fu_295779_p4.read().is_01() || !mult_262_V_fu_295393_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln708_234_fu_295779_p4.read()) + sc_biguint<16>(mult_262_V_fu_295393_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_547_fu_297393_p2() {
    add_ln703_547_fu_297393_p2 = (!mult_254_V_fu_295256_p4.read().is_01() || !add_ln703_546_fu_297387_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_254_V_fu_295256_p4.read()) + sc_biguint<16>(add_ln703_546_fu_297387_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_548_fu_297399_p2() {
    add_ln703_548_fu_297399_p2 = (!add_ln703_545_fu_297381_p2.read().is_01() || !add_ln703_547_fu_297393_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_545_fu_297381_p2.read()) + sc_biguint<16>(add_ln703_547_fu_297393_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_549_fu_297405_p2() {
    add_ln703_549_fu_297405_p2 = (!add_ln703_544_fu_297375_p2.read().is_01() || !add_ln703_548_fu_297399_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_544_fu_297375_p2.read()) + sc_biguint<16>(add_ln703_548_fu_297399_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_550_fu_297411_p2() {
    add_ln703_550_fu_297411_p2 = (!add_ln703_541_fu_297357_p2.read().is_01() || !add_ln703_549_fu_297405_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_541_fu_297357_p2.read()) + sc_biguint<16>(add_ln703_549_fu_297405_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_551_fu_297417_p2() {
    add_ln703_551_fu_297417_p2 = (!mult_14_V_fu_291209_p1.read().is_01() || !mult_6_V_fu_291050_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_14_V_fu_291209_p1.read()) + sc_bigint<16>(mult_6_V_fu_291050_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_552_fu_297423_p2() {
    add_ln703_552_fu_297423_p2 = (!mult_62_V_fu_292080_p1.read().is_01() || !mult_38_V_fu_291614_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_62_V_fu_292080_p1.read()) + sc_bigint<16>(mult_38_V_fu_291614_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_553_fu_297429_p2() {
    add_ln703_553_fu_297429_p2 = (!add_ln703_551_fu_297417_p2.read().is_01() || !add_ln703_552_fu_297423_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_551_fu_297417_p2.read()) + sc_biguint<16>(add_ln703_552_fu_297423_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_554_fu_297435_p2() {
    add_ln703_554_fu_297435_p2 = (!mult_238_V_fu_294998_p1.read().is_01() || !mult_134_V_fu_293301_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_238_V_fu_294998_p1.read()) + sc_bigint<16>(mult_134_V_fu_293301_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_555_fu_297441_p2() {
    add_ln703_555_fu_297441_p2 = (!sext_ln203_96_fu_292212_p1.read().is_01() || !sext_ln203_80_fu_291349_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_96_fu_292212_p1.read()) + sc_bigint<15>(sext_ln203_80_fu_291349_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_556_fu_297451_p2() {
    add_ln703_556_fu_297451_p2 = (!sext_ln708_fu_295546_p1.read().is_01() || !sext_ln703_113_fu_297447_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln708_fu_295546_p1.read()) + sc_bigint<16>(sext_ln703_113_fu_297447_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_557_fu_297457_p2() {
    add_ln703_557_fu_297457_p2 = (!add_ln703_554_fu_297435_p2.read().is_01() || !add_ln703_556_fu_297451_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_554_fu_297435_p2.read()) + sc_biguint<16>(add_ln703_556_fu_297451_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_558_fu_297463_p2() {
    add_ln703_558_fu_297463_p2 = (!add_ln703_553_fu_297429_p2.read().is_01() || !add_ln703_557_fu_297457_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_553_fu_297429_p2.read()) + sc_biguint<16>(add_ln703_557_fu_297457_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_559_fu_297469_p2() {
    add_ln703_559_fu_297469_p2 = (!sext_ln203_136_fu_294735_p1.read().is_01() || !sext_ln203_108_fu_292771_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_136_fu_294735_p1.read()) + sc_bigint<15>(sext_ln203_108_fu_292771_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_560_fu_297479_p2() {
    add_ln703_560_fu_297479_p2 = (!sext_ln203_121_fu_294138_p1.read().is_01() || !sext_ln203_88_fu_291772_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_121_fu_294138_p1.read()) + sc_bigint<14>(sext_ln203_88_fu_291772_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_561_fu_297489_p2() {
    add_ln703_561_fu_297489_p2 = (!sext_ln203_83_fu_291469_p1.read().is_01() || !sext_ln703_115_fu_297485_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_83_fu_291469_p1.read()) + sc_bigint<15>(sext_ln703_115_fu_297485_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_562_fu_297499_p2() {
    add_ln703_562_fu_297499_p2 = (!sext_ln703_114_fu_297475_p1.read().is_01() || !sext_ln703_116_fu_297495_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_114_fu_297475_p1.read()) + sc_bigint<16>(sext_ln703_116_fu_297495_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_563_fu_297505_p2() {
    add_ln703_563_fu_297505_p2 = (!sext_ln203_139_fu_294855_p1.read().is_01() || !sext_ln203_132_fu_294590_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_139_fu_294855_p1.read()) + sc_bigint<14>(sext_ln203_132_fu_294590_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_564_fu_297515_p2() {
    add_ln703_564_fu_297515_p2 = (!sext_ln1118_209_fu_295671_p1.read().is_01() || !ap_const_lv13_1FDE.is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln1118_209_fu_295671_p1.read()) + sc_bigint<13>(ap_const_lv13_1FDE));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_565_fu_297525_p2() {
    add_ln703_565_fu_297525_p2 = (!sext_ln203_105_fu_292647_p1.read().is_01() || !sext_ln703_118_fu_297521_p1.read().is_01())? sc_lv<14>(): (sc_bigint<14>(sext_ln203_105_fu_292647_p1.read()) + sc_bigint<14>(sext_ln703_118_fu_297521_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_566_fu_297535_p2() {
    add_ln703_566_fu_297535_p2 = (!sext_ln703_117_fu_297511_p1.read().is_01() || !sext_ln703_119_fu_297531_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln703_117_fu_297511_p1.read()) + sc_bigint<15>(sext_ln703_119_fu_297531_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_567_fu_297545_p2() {
    add_ln703_567_fu_297545_p2 = (!add_ln703_562_fu_297499_p2.read().is_01() || !sext_ln703_120_fu_297541_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_562_fu_297499_p2.read()) + sc_bigint<16>(sext_ln703_120_fu_297541_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_568_fu_297551_p2() {
    add_ln703_568_fu_297551_p2 = (!add_ln703_558_fu_297463_p2.read().is_01() || !add_ln703_567_fu_297545_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_558_fu_297463_p2.read()) + sc_biguint<16>(add_ln703_567_fu_297545_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_570_fu_297563_p2() {
    add_ln703_570_fu_297563_p2 = (!mult_23_V_fu_291353_p4.read().is_01() || !mult_15_V_fu_291213_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_23_V_fu_291353_p4.read()) + sc_biguint<16>(mult_15_V_fu_291213_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_571_fu_297569_p2() {
    add_ln703_571_fu_297569_p2 = (!mult_39_V_fu_291618_p4.read().is_01() || !mult_31_V_fu_291473_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_39_V_fu_291618_p4.read()) + sc_biguint<16>(mult_31_V_fu_291473_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_572_fu_297575_p2() {
    add_ln703_572_fu_297575_p2 = (!add_ln703_570_fu_297563_p2.read().is_01() || !add_ln703_571_fu_297569_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_570_fu_297563_p2.read()) + sc_biguint<16>(add_ln703_571_fu_297569_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_573_fu_297581_p2() {
    add_ln703_573_fu_297581_p2 = (!mult_79_V_fu_292318_p4.read().is_01() || !mult_68_V_fu_292182_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_79_V_fu_292318_p4.read()) + sc_biguint<16>(mult_68_V_fu_292182_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_574_fu_297587_p2() {
    add_ln703_574_fu_297587_p2 = (!mult_127_V_fu_293168_p4.read().is_01() || !mult_103_V_fu_292775_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_127_V_fu_293168_p4.read()) + sc_biguint<16>(mult_103_V_fu_292775_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_575_fu_297593_p2() {
    add_ln703_575_fu_297593_p2 = (!mult_95_V_fu_292651_p4.read().is_01() || !add_ln703_574_fu_297587_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_95_V_fu_292651_p4.read()) + sc_biguint<16>(add_ln703_574_fu_297587_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_576_fu_297599_p2() {
    add_ln703_576_fu_297599_p2 = (!add_ln703_573_fu_297581_p2.read().is_01() || !add_ln703_575_fu_297593_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_573_fu_297581_p2.read()) + sc_biguint<16>(add_ln703_575_fu_297593_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_577_fu_297605_p2() {
    add_ln703_577_fu_297605_p2 = (!add_ln703_572_fu_297575_p2.read().is_01() || !add_ln703_576_fu_297599_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_572_fu_297575_p2.read()) + sc_biguint<16>(add_ln703_576_fu_297599_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_578_fu_297611_p2() {
    add_ln703_578_fu_297611_p2 = (!mult_151_V_fu_293558_p4.read().is_01() || !mult_135_V_fu_293305_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_151_V_fu_293558_p4.read()) + sc_biguint<16>(mult_135_V_fu_293305_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_579_fu_297617_p2() {
    add_ln703_579_fu_297617_p2 = (!mult_191_V_fu_294142_p4.read().is_01() || !mult_159_V_fu_293651_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_191_V_fu_294142_p4.read()) + sc_biguint<16>(mult_159_V_fu_293651_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_580_fu_297623_p2() {
    add_ln703_580_fu_297623_p2 = (!add_ln703_578_fu_297611_p2.read().is_01() || !add_ln703_579_fu_297617_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_578_fu_297611_p2.read()) + sc_biguint<16>(add_ln703_579_fu_297617_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_581_fu_297629_p2() {
    add_ln703_581_fu_297629_p2 = (!mult_263_V_fu_295403_p4.read().is_01() || !mult_231_V_fu_294859_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_263_V_fu_295403_p4.read()) + sc_biguint<16>(mult_231_V_fu_294859_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_582_fu_297635_p2() {
    add_ln703_582_fu_297635_p2 = (!mult_55_V_fu_291910_p1.read().is_01() || !trunc_ln708_227_fu_295675_p4.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_55_V_fu_291910_p1.read()) + sc_biguint<16>(trunc_ln708_227_fu_295675_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_583_fu_297641_p2() {
    add_ln703_583_fu_297641_p2 = (!trunc_ln708_219_fu_295550_p4.read().is_01() || !add_ln703_582_fu_297635_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln708_219_fu_295550_p4.read()) + sc_biguint<16>(add_ln703_582_fu_297635_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_584_fu_297647_p2() {
    add_ln703_584_fu_297647_p2 = (!add_ln703_581_fu_297629_p2.read().is_01() || !add_ln703_583_fu_297641_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_581_fu_297629_p2.read()) + sc_biguint<16>(add_ln703_583_fu_297641_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_585_fu_297653_p2() {
    add_ln703_585_fu_297653_p2 = (!add_ln703_580_fu_297623_p2.read().is_01() || !add_ln703_584_fu_297647_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_580_fu_297623_p2.read()) + sc_biguint<16>(add_ln703_584_fu_297647_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_586_fu_297659_p2() {
    add_ln703_586_fu_297659_p2 = (!add_ln703_577_fu_297605_p2.read().is_01() || !add_ln703_585_fu_297653_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_577_fu_297605_p2.read()) + sc_biguint<16>(add_ln703_585_fu_297653_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_587_fu_297665_p2() {
    add_ln703_587_fu_297665_p2 = (!mult_111_V_fu_292920_p1.read().is_01() || !mult_63_V_fu_292094_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_111_V_fu_292920_p1.read()) + sc_bigint<16>(mult_63_V_fu_292094_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_588_fu_297671_p2() {
    add_ln703_588_fu_297671_p2 = (!mult_167_V_fu_293773_p1.read().is_01() || !mult_119_V_fu_293040_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_167_V_fu_293773_p1.read()) + sc_bigint<16>(mult_119_V_fu_293040_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_589_fu_297677_p2() {
    add_ln703_589_fu_297677_p2 = (!add_ln703_587_fu_297665_p2.read().is_01() || !add_ln703_588_fu_297671_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_587_fu_297665_p2.read()) + sc_biguint<16>(add_ln703_588_fu_297671_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_590_fu_297683_p2() {
    add_ln703_590_fu_297683_p2 = (!mult_215_V_fu_294604_p1.read().is_01() || !mult_207_V_fu_294434_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_215_V_fu_294604_p1.read()) + sc_bigint<16>(mult_207_V_fu_294434_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_591_fu_297689_p2() {
    add_ln703_591_fu_297689_p2 = (!mult_255_V_fu_295276_p1.read().is_01() || !mult_239_V_fu_295012_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_255_V_fu_295276_p1.read()) + sc_bigint<16>(mult_239_V_fu_295012_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_592_fu_297695_p2() {
    add_ln703_592_fu_297695_p2 = (!mult_223_V_fu_294749_p1.read().is_01() || !add_ln703_591_fu_297689_p2.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_223_V_fu_294749_p1.read()) + sc_biguint<16>(add_ln703_591_fu_297689_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_593_fu_297701_p2() {
    add_ln703_593_fu_297701_p2 = (!add_ln703_590_fu_297683_p2.read().is_01() || !add_ln703_592_fu_297695_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_590_fu_297683_p2.read()) + sc_biguint<16>(add_ln703_592_fu_297695_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_594_fu_297707_p2() {
    add_ln703_594_fu_297707_p2 = (!add_ln703_589_fu_297677_p2.read().is_01() || !add_ln703_593_fu_297701_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_589_fu_297677_p2.read()) + sc_biguint<16>(add_ln703_593_fu_297701_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_595_fu_297713_p2() {
    add_ln703_595_fu_297713_p2 = (!sext_ln203_76_fu_291064_p1.read().is_01() || !sext_ln703_110_fu_295829_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_76_fu_291064_p1.read()) + sc_bigint<15>(sext_ln703_110_fu_295829_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_596_fu_297723_p2() {
    add_ln703_596_fu_297723_p2 = (!sext_ln203_126_fu_294306_p1.read().is_01() || !sext_ln203_118_fu_294020_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_126_fu_294306_p1.read()) + sc_bigint<15>(sext_ln203_118_fu_294020_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_597_fu_297733_p2() {
    add_ln703_597_fu_297733_p2 = (!mult_143_V_fu_293460_p1.read().is_01() || !sext_ln703_121_fu_297729_p1.read().is_01())? sc_lv<16>(): (sc_bigint<16>(mult_143_V_fu_293460_p1.read()) + sc_bigint<16>(sext_ln703_121_fu_297729_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_598_fu_297739_p2() {
    add_ln703_598_fu_297739_p2 = (!sext_ln703_124_fu_297719_p1.read().is_01() || !add_ln703_597_fu_297733_p2.read().is_01())? sc_lv<16>(): (sc_bigint<16>(sext_ln703_124_fu_297719_p1.read()) + sc_biguint<16>(add_ln703_597_fu_297733_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_599_fu_297745_p2() {
    add_ln703_599_fu_297745_p2 = (!sext_ln203_89_fu_291786_p1.read().is_01() || !sext_ln203_142_fu_295167_p1.read().is_01())? sc_lv<15>(): (sc_bigint<15>(sext_ln203_89_fu_291786_p1.read()) + sc_bigint<15>(sext_ln203_142_fu_295167_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_600_fu_297751_p2() {
    add_ln703_600_fu_297751_p2 = (!sext_ln203_101_fu_292467_p1.read().is_01() || !ap_const_lv9_147.is_01())? sc_lv<9>(): (sc_bigint<9>(sext_ln203_101_fu_292467_p1.read()) + sc_bigint<9>(ap_const_lv9_147));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_601_fu_297761_p2() {
    add_ln703_601_fu_297761_p2 = (!sext_ln203_119_cast_fu_293912_p1.read().is_01() || !sext_ln703_125_fu_297757_p1.read().is_01())? sc_lv<13>(): (sc_bigint<13>(sext_ln203_119_cast_fu_293912_p1.read()) + sc_bigint<13>(sext_ln703_125_fu_297757_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_602_fu_297771_p2() {
    add_ln703_602_fu_297771_p2 = (!add_ln703_599_fu_297745_p2.read().is_01() || !sext_ln703_126_fu_297767_p1.read().is_01())? sc_lv<15>(): (sc_biguint<15>(add_ln703_599_fu_297745_p2.read()) + sc_bigint<15>(sext_ln703_126_fu_297767_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_603_fu_297781_p2() {
    add_ln703_603_fu_297781_p2 = (!add_ln703_598_fu_297739_p2.read().is_01() || !sext_ln703_127_fu_297777_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_598_fu_297739_p2.read()) + sc_bigint<16>(sext_ln703_127_fu_297777_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_604_fu_297787_p2() {
    add_ln703_604_fu_297787_p2 = (!add_ln703_594_fu_297707_p2.read().is_01() || !add_ln703_603_fu_297781_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(add_ln703_594_fu_297707_p2.read()) + sc_biguint<16>(add_ln703_603_fu_297781_p2.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_add_ln703_fu_295833_p2() {
    add_ln703_fu_295833_p2 = (!mult_64_V_fu_292124_p4.read().is_01() || !mult_32_V_fu_291502_p4.read().is_01())? sc_lv<16>(): (sc_biguint<16>(mult_64_V_fu_292124_p4.read()) + sc_biguint<16>(mult_32_V_fu_291502_p4.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_ap_ready() {
    ap_ready = ap_const_logic_1;
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_ap_return_0() {
    ap_return_0 = add_ln703_389_fu_296069_p2.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_ap_return_1() {
    ap_return_1 = acc_1_V_fu_296321_p2.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_ap_return_2() {
    ap_return_2 = acc_2_V_fu_296565_p2.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_ap_return_3() {
    ap_return_3 = acc_3_V_fu_296813_p2.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_ap_return_4() {
    ap_return_4 = acc_4_V_fu_297061_p2.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_ap_return_5() {
    ap_return_5 = acc_5_V_fu_297309_p2.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_ap_return_6() {
    ap_return_6 = acc_6_V_fu_297557_p2.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_ap_return_7() {
    ap_return_7 = acc_7_V_fu_297793_p2.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_286_fu_1151_p0() {
    mul_ln1118_286_fu_1151_p0 = sext_ln1116_cast95_fu_290923_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_286_fu_1151_p2() {
    mul_ln1118_286_fu_1151_p2 = (!mul_ln1118_286_fu_1151_p0.read().is_01() || !ap_const_lv21_1FFFF3.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_286_fu_1151_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF3);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_287_fu_1035_p0() {
    mul_ln1118_287_fu_1035_p0 =  (sc_lv<16>) (sext_ln1116_cast96_fu_290917_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_287_fu_1035_p2() {
    mul_ln1118_287_fu_1035_p2 = (!mul_ln1118_287_fu_1035_p0.read().is_01() || !ap_const_lv26_3FFFDE7.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_287_fu_1035_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDE7);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_288_fu_1039_p0() {
    mul_ln1118_288_fu_1039_p0 =  (sc_lv<16>) (sext_ln1116_cast97_fu_290911_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_288_fu_1039_p2() {
    mul_ln1118_288_fu_1039_p2 = (!mul_ln1118_288_fu_1039_p0.read().is_01() || !ap_const_lv25_A7.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_288_fu_1039_p0.read()) * sc_biguint<25>(ap_const_lv25_A7);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_289_fu_1110_p0() {
    mul_ln1118_289_fu_1110_p0 =  (sc_lv<16>) (sext_ln1116_cast96_fu_290917_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_289_fu_1110_p2() {
    mul_ln1118_289_fu_1110_p2 = (!mul_ln1118_289_fu_1110_p0.read().is_01() || !ap_const_lv26_26A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_289_fu_1110_p0.read()) * sc_biguint<26>(ap_const_lv26_26A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_290_fu_891_p0() {
    mul_ln1118_290_fu_891_p0 =  (sc_lv<16>) (sext_ln1116_cast97_fu_290911_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_290_fu_891_p2() {
    mul_ln1118_290_fu_891_p2 = (!mul_ln1118_290_fu_891_p0.read().is_01() || !ap_const_lv25_1FFFF66.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_290_fu_891_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF66);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_291_fu_948_p0() {
    mul_ln1118_291_fu_948_p0 =  (sc_lv<16>) (sext_ln1116_cast94_fu_290928_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_291_fu_948_p2() {
    mul_ln1118_291_fu_948_p2 = (!mul_ln1118_291_fu_948_p0.read().is_01() || !ap_const_lv24_6C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_291_fu_948_p0.read()) * sc_biguint<24>(ap_const_lv24_6C);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_292_fu_911_p0() {
    mul_ln1118_292_fu_911_p0 = sext_ln1116_41_cast_fu_291086_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_292_fu_911_p2() {
    mul_ln1118_292_fu_911_p2 = (!mul_ln1118_292_fu_911_p0.read().is_01() || !ap_const_lv24_4F.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_292_fu_911_p0.read()) * sc_biguint<24>(ap_const_lv24_4F);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_293_fu_1056_p0() {
    mul_ln1118_293_fu_1056_p0 =  (sc_lv<16>) (sext_ln1116_41_cast90_fu_291078_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_293_fu_1056_p2() {
    mul_ln1118_293_fu_1056_p2 = (!mul_ln1118_293_fu_1056_p0.read().is_01() || !ap_const_lv26_3FFFEEE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_293_fu_1056_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEEE);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_294_fu_950_p0() {
    mul_ln1118_294_fu_950_p0 =  (sc_lv<16>) (sext_ln1116_41_cast90_fu_291078_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_294_fu_950_p2() {
    mul_ln1118_294_fu_950_p2 = (!mul_ln1118_294_fu_950_p0.read().is_01() || !ap_const_lv26_3FFFE4F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_294_fu_950_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE4F);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_295_fu_1090_p0() {
    mul_ln1118_295_fu_1090_p0 =  (sc_lv<16>) (sext_ln1116_41_cast90_fu_291078_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_295_fu_1090_p2() {
    mul_ln1118_295_fu_1090_p2 = (!mul_ln1118_295_fu_1090_p0.read().is_01() || !ap_const_lv26_3FFFD40.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_295_fu_1090_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD40);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_296_fu_919_p0() {
    mul_ln1118_296_fu_919_p0 = sext_ln1116_41_cast91_fu_291073_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_296_fu_919_p2() {
    mul_ln1118_296_fu_919_p2 = (!mul_ln1118_296_fu_919_p0.read().is_01() || !ap_const_lv21_B.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_296_fu_919_p0.read()) * sc_biguint<21>(ap_const_lv21_B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_297_fu_975_p0() {
    mul_ln1118_297_fu_975_p0 = sext_ln1116_41_cast93_fu_291068_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_297_fu_975_p2() {
    mul_ln1118_297_fu_975_p2 = (!mul_ln1118_297_fu_975_p0.read().is_01() || !ap_const_lv25_A3.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_297_fu_975_p0.read()) * sc_biguint<25>(ap_const_lv25_A3);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_298_fu_921_p0() {
    mul_ln1118_298_fu_921_p0 =  (sc_lv<16>) (sext_ln1116_41_cast90_fu_291078_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_298_fu_921_p2() {
    mul_ln1118_298_fu_921_p2 = (!mul_ln1118_298_fu_921_p0.read().is_01() || !ap_const_lv26_1B4.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_298_fu_921_p0.read()) * sc_biguint<26>(ap_const_lv26_1B4);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_299_fu_1094_p0() {
    mul_ln1118_299_fu_1094_p0 =  (sc_lv<16>) (sext_ln1116_42_cast_fu_291239_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_299_fu_1094_p2() {
    mul_ln1118_299_fu_1094_p2 = (!mul_ln1118_299_fu_1094_p0.read().is_01() || !ap_const_lv24_FFFF8C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_299_fu_1094_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8C);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_300_fu_1102_p0() {
    mul_ln1118_300_fu_1102_p0 = sext_ln1116_42_cast87_fu_291234_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_300_fu_1102_p2() {
    mul_ln1118_300_fu_1102_p2 = (!mul_ln1118_300_fu_1102_p0.read().is_01() || !ap_const_lv25_1FFFF75.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_300_fu_1102_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF75);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_302_fu_973_p0() {
    mul_ln1118_302_fu_973_p0 =  (sc_lv<16>) (sext_ln1116_42_cast89_fu_291223_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_302_fu_973_p2() {
    mul_ln1118_302_fu_973_p2 = (!mul_ln1118_302_fu_973_p0.read().is_01() || !ap_const_lv26_11E.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_302_fu_973_p0.read()) * sc_biguint<26>(ap_const_lv26_11E);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_303_fu_1103_p0() {
    mul_ln1118_303_fu_1103_p0 =  (sc_lv<16>) (sext_ln1116_42_cast89_fu_291223_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_303_fu_1103_p2() {
    mul_ln1118_303_fu_1103_p2 = (!mul_ln1118_303_fu_1103_p0.read().is_01() || !ap_const_lv26_3FFFDD1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_303_fu_1103_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDD1);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_304_fu_997_p0() {
    mul_ln1118_304_fu_997_p0 =  (sc_lv<16>) (sext_ln1116_42_cast_fu_291239_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_304_fu_997_p2() {
    mul_ln1118_304_fu_997_p2 = (!mul_ln1118_304_fu_997_p0.read().is_01() || !ap_const_lv24_FFFF96.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_304_fu_997_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF96);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_305_fu_1054_p0() {
    mul_ln1118_305_fu_1054_p0 =  (sc_lv<16>) (sext_ln1116_42_cast89_fu_291223_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_305_fu_1054_p2() {
    mul_ln1118_305_fu_1054_p2 = (!mul_ln1118_305_fu_1054_p0.read().is_01() || !ap_const_lv26_3FFFE0C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_305_fu_1054_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE0C);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_306_fu_1105_p0() {
    mul_ln1118_306_fu_1105_p0 = sext_ln1116_43_cast_fu_291382_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_306_fu_1105_p2() {
    mul_ln1118_306_fu_1105_p2 = (!mul_ln1118_306_fu_1105_p0.read().is_01() || !ap_const_lv22_3FFFE3.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_306_fu_1105_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE3);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_307_fu_1137_p0() {
    mul_ln1118_307_fu_1137_p0 =  (sc_lv<16>) (sext_ln1116_43_cast83_fu_291376_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_307_fu_1137_p2() {
    mul_ln1118_307_fu_1137_p2 = (!mul_ln1118_307_fu_1137_p0.read().is_01() || !ap_const_lv23_7FFFD3.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_307_fu_1137_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD3);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_308_fu_874_p0() {
    mul_ln1118_308_fu_874_p0 = sext_ln1116_43_cast84_fu_291371_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_308_fu_874_p2() {
    mul_ln1118_308_fu_874_p2 = (!mul_ln1118_308_fu_874_p0.read().is_01() || !ap_const_lv25_C6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_308_fu_874_p0.read()) * sc_biguint<25>(ap_const_lv25_C6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_309_fu_1088_p0() {
    mul_ln1118_309_fu_1088_p0 =  (sc_lv<16>) (sext_ln1116_43_cast85_fu_291363_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_309_fu_1088_p2() {
    mul_ln1118_309_fu_1088_p2 = (!mul_ln1118_309_fu_1088_p0.read().is_01() || !ap_const_lv26_3FFFD4B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_309_fu_1088_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD4B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_310_fu_1089_p0() {
    mul_ln1118_310_fu_1089_p0 =  (sc_lv<16>) (sext_ln1116_43_cast85_fu_291363_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_310_fu_1089_p2() {
    mul_ln1118_310_fu_1089_p2 = (!mul_ln1118_310_fu_1089_p0.read().is_01() || !ap_const_lv26_12F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_310_fu_1089_p0.read()) * sc_biguint<26>(ap_const_lv26_12F);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_311_fu_915_p0() {
    mul_ln1118_311_fu_915_p0 =  (sc_lv<16>) (sext_ln1116_43_cast85_fu_291363_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_311_fu_915_p2() {
    mul_ln1118_311_fu_915_p2 = (!mul_ln1118_311_fu_915_p0.read().is_01() || !ap_const_lv26_25F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_311_fu_915_p0.read()) * sc_biguint<26>(ap_const_lv26_25F);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_312_fu_1091_p0() {
    mul_ln1118_312_fu_1091_p0 =  (sc_lv<16>) (sext_ln1116_43_cast83_fu_291376_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_312_fu_1091_p2() {
    mul_ln1118_312_fu_1091_p2 = (!mul_ln1118_312_fu_1091_p0.read().is_01() || !ap_const_lv23_7FFFD4.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_312_fu_1091_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD4);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_313_fu_1092_p0() {
    mul_ln1118_313_fu_1092_p0 =  (sc_lv<16>) (sext_ln1116_43_cast85_fu_291363_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_313_fu_1092_p2() {
    mul_ln1118_313_fu_1092_p2 = (!mul_ln1118_313_fu_1092_p0.read().is_01() || !ap_const_lv26_159.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_313_fu_1092_p0.read()) * sc_biguint<26>(ap_const_lv26_159);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_314_fu_1120_p0() {
    mul_ln1118_314_fu_1120_p0 =  (sc_lv<16>) (sext_ln1116_44_cast_fu_291494_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_314_fu_1120_p2() {
    mul_ln1118_314_fu_1120_p2 = (!mul_ln1118_314_fu_1120_p0.read().is_01() || !ap_const_lv26_3FFFE55.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_314_fu_1120_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE55);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_315_fu_1114_p0() {
    mul_ln1118_315_fu_1114_p0 =  (sc_lv<16>) (sext_ln1116_44_cast_fu_291494_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_315_fu_1114_p2() {
    mul_ln1118_315_fu_1114_p2 = (!mul_ln1118_315_fu_1114_p0.read().is_01() || !ap_const_lv26_3FFFE9A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_315_fu_1114_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE9A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_316_fu_1096_p0() {
    mul_ln1118_316_fu_1096_p0 =  (sc_lv<16>) (sext_ln1116_44_cast_fu_291494_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_316_fu_1096_p2() {
    mul_ln1118_316_fu_1096_p2 = (!mul_ln1118_316_fu_1096_p0.read().is_01() || !ap_const_lv26_3FFFE89.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_316_fu_1096_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE89);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_317_fu_940_p0() {
    mul_ln1118_317_fu_940_p0 =  (sc_lv<16>) (sext_ln1116_44_cast81_fu_291488_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_317_fu_940_p2() {
    mul_ln1118_317_fu_940_p2 = (!mul_ln1118_317_fu_940_p0.read().is_01() || !ap_const_lv25_85.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_317_fu_940_p0.read()) * sc_biguint<25>(ap_const_lv25_85);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_318_fu_1066_p0() {
    mul_ln1118_318_fu_1066_p0 = sext_ln1116_44_cast82_fu_291483_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_318_fu_1066_p2() {
    mul_ln1118_318_fu_1066_p2 = (!mul_ln1118_318_fu_1066_p0.read().is_01() || !ap_const_lv24_FFFFA6.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_318_fu_1066_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_319_fu_897_p0() {
    mul_ln1118_319_fu_897_p0 =  (sc_lv<16>) (sext_ln1116_44_cast81_fu_291488_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_319_fu_897_p2() {
    mul_ln1118_319_fu_897_p2 = (!mul_ln1118_319_fu_897_p0.read().is_01() || !ap_const_lv25_1FFFF19.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_319_fu_897_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF19);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_320_fu_1111_p0() {
    mul_ln1118_320_fu_1111_p0 =  (sc_lv<16>) (sext_ln1116_44_cast_fu_291494_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_320_fu_1111_p2() {
    mul_ln1118_320_fu_1111_p2 = (!mul_ln1118_320_fu_1111_p0.read().is_01() || !ap_const_lv26_151.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_320_fu_1111_p0.read()) * sc_biguint<26>(ap_const_lv26_151);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_321_fu_1030_p0() {
    mul_ln1118_321_fu_1030_p0 = sext_ln1116_45_cast_fu_291645_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_321_fu_1030_p2() {
    mul_ln1118_321_fu_1030_p2 = (!mul_ln1118_321_fu_1030_p0.read().is_01() || !ap_const_lv25_DB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_321_fu_1030_p0.read()) * sc_biguint<25>(ap_const_lv25_DB);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_322_fu_1031_p0() {
    mul_ln1118_322_fu_1031_p0 =  (sc_lv<16>) (sext_ln1116_45_cast76_fu_291638_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_322_fu_1031_p2() {
    mul_ln1118_322_fu_1031_p2 = (!mul_ln1118_322_fu_1031_p0.read().is_01() || !ap_const_lv26_333.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_322_fu_1031_p0.read()) * sc_biguint<26>(ap_const_lv26_333);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_323_fu_1032_p0() {
    mul_ln1118_323_fu_1032_p0 =  (sc_lv<16>) (sext_ln1116_45_cast76_fu_291638_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_323_fu_1032_p2() {
    mul_ln1118_323_fu_1032_p2 = (!mul_ln1118_323_fu_1032_p0.read().is_01() || !ap_const_lv26_3FFFC94.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_323_fu_1032_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFC94);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_324_fu_923_p0() {
    mul_ln1118_324_fu_923_p0 =  (sc_lv<16>) (sext_ln1116_45_cast76_fu_291638_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_324_fu_923_p2() {
    mul_ln1118_324_fu_923_p2 = (!mul_ln1118_324_fu_923_p0.read().is_01() || !ap_const_lv26_179.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_324_fu_923_p0.read()) * sc_biguint<26>(ap_const_lv26_179);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_325_fu_917_p0() {
    mul_ln1118_325_fu_917_p0 =  (sc_lv<16>) (sext_ln1116_45_cast79_fu_291628_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_325_fu_917_p2() {
    mul_ln1118_325_fu_917_p2 = (!mul_ln1118_325_fu_917_p0.read().is_01() || !ap_const_lv23_3D.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_325_fu_917_p0.read()) * sc_biguint<23>(ap_const_lv23_3D);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_326_fu_1042_p0() {
    mul_ln1118_326_fu_1042_p0 =  (sc_lv<16>) (sext_ln1116_45_cast79_fu_291628_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_326_fu_1042_p2() {
    mul_ln1118_326_fu_1042_p2 = (!mul_ln1118_326_fu_1042_p0.read().is_01() || !ap_const_lv23_3B.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_326_fu_1042_p0.read()) * sc_biguint<23>(ap_const_lv23_3B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_327_fu_1006_p0() {
    mul_ln1118_327_fu_1006_p0 = sext_ln1116_46_cast_fu_291809_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_327_fu_1006_p2() {
    mul_ln1118_327_fu_1006_p2 = (!mul_ln1118_327_fu_1006_p0.read().is_01() || !ap_const_lv22_15.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_327_fu_1006_p0.read()) * sc_biguint<22>(ap_const_lv22_15);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_328_fu_875_p0() {
    mul_ln1118_328_fu_875_p0 =  (sc_lv<16>) (sext_ln1116_46_cast73_fu_291802_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_328_fu_875_p2() {
    mul_ln1118_328_fu_875_p2 = (!mul_ln1118_328_fu_875_p0.read().is_01() || !ap_const_lv25_1FFFF3F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_328_fu_875_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF3F);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_329_fu_932_p0() {
    mul_ln1118_329_fu_932_p0 = sext_ln1116_46_cast74_fu_291797_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_329_fu_932_p2() {
    mul_ln1118_329_fu_932_p2 = (!mul_ln1118_329_fu_932_p0.read().is_01() || !ap_const_lv24_67.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_329_fu_932_p0.read()) * sc_biguint<24>(ap_const_lv24_67);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_330_fu_895_p0() {
    mul_ln1118_330_fu_895_p0 =  (sc_lv<16>) (sext_ln1116_46_cast75_fu_291790_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_330_fu_895_p2() {
    mul_ln1118_330_fu_895_p2 = (!mul_ln1118_330_fu_895_p0.read().is_01() || !ap_const_lv26_338.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_330_fu_895_p0.read()) * sc_biguint<26>(ap_const_lv26_338);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_331_fu_1040_p0() {
    mul_ln1118_331_fu_1040_p0 =  (sc_lv<16>) (sext_ln1116_46_cast73_fu_291802_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_331_fu_1040_p2() {
    mul_ln1118_331_fu_1040_p2 = (!mul_ln1118_331_fu_1040_p0.read().is_01() || !ap_const_lv25_1FFFF6C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_331_fu_1040_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6C);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_332_fu_890_p0() {
    mul_ln1118_332_fu_890_p0 =  (sc_lv<16>) (sext_ln1116_46_cast75_fu_291790_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_332_fu_890_p2() {
    mul_ln1118_332_fu_890_p2 = (!mul_ln1118_332_fu_890_p0.read().is_01() || !ap_const_lv26_3FFFE1C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_332_fu_890_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE1C);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_333_fu_966_p0() {
    mul_ln1118_333_fu_966_p0 =  (sc_lv<16>) (sext_ln1116_46_cast75_fu_291790_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_333_fu_966_p2() {
    mul_ln1118_333_fu_966_p2 = (!mul_ln1118_333_fu_966_p0.read().is_01() || !ap_const_lv26_3FFFD51.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_333_fu_966_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD51);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_334_fu_1028_p0() {
    mul_ln1118_334_fu_1028_p0 =  (sc_lv<16>) (sext_ln1116_46_cast73_fu_291802_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_334_fu_1028_p2() {
    mul_ln1118_334_fu_1028_p2 = (!mul_ln1118_334_fu_1028_p0.read().is_01() || !ap_const_lv25_BF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_334_fu_1028_p0.read()) * sc_biguint<25>(ap_const_lv25_BF);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_335_fu_1146_p0() {
    mul_ln1118_335_fu_1146_p0 = sext_ln1116_47_cast70_fu_291924_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_335_fu_1146_p2() {
    mul_ln1118_335_fu_1146_p2 = (!mul_ln1118_335_fu_1146_p0.read().is_01() || !ap_const_lv23_7FFFD5.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_335_fu_1146_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD5);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_336_fu_1147_p0() {
    mul_ln1118_336_fu_1147_p0 = sext_ln1116_47_cast71_fu_291919_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_336_fu_1147_p2() {
    mul_ln1118_336_fu_1147_p2 = (!mul_ln1118_336_fu_1147_p0.read().is_01() || !ap_const_lv24_FFFFA8.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_336_fu_1147_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA8);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_337_fu_873_p0() {
    mul_ln1118_337_fu_873_p0 = sext_ln1116_47_cast72_fu_291914_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_337_fu_873_p2() {
    mul_ln1118_337_fu_873_p2 = (!mul_ln1118_337_fu_873_p0.read().is_01() || !ap_const_lv26_3FFFE4E.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_337_fu_873_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE4E);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_338_fu_1149_p0() {
    mul_ln1118_338_fu_1149_p0 =  (sc_lv<16>) (sext_ln1116_47_cast_fu_291929_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_338_fu_1149_p2() {
    mul_ln1118_338_fu_1149_p2 = (!mul_ln1118_338_fu_1149_p0.read().is_01() || !ap_const_lv25_B9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_338_fu_1149_p0.read()) * sc_biguint<25>(ap_const_lv25_B9);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_339_fu_986_p0() {
    mul_ln1118_339_fu_986_p0 =  (sc_lv<16>) (sext_ln1116_47_cast_fu_291929_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_339_fu_986_p2() {
    mul_ln1118_339_fu_986_p2 = (!mul_ln1118_339_fu_986_p0.read().is_01() || !ap_const_lv25_D7.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_339_fu_986_p0.read()) * sc_biguint<25>(ap_const_lv25_D7);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_340_fu_930_p0() {
    mul_ln1118_340_fu_930_p0 =  (sc_lv<16>) (sext_ln1116_47_cast_fu_291929_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_340_fu_930_p2() {
    mul_ln1118_340_fu_930_p2 = (!mul_ln1118_340_fu_930_p0.read().is_01() || !ap_const_lv25_E7.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_340_fu_930_p0.read()) * sc_biguint<25>(ap_const_lv25_E7);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_341_fu_1100_p0() {
    mul_ln1118_341_fu_1100_p0 =  (sc_lv<16>) (sext_ln1116_48_cast_fu_292117_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_341_fu_1100_p2() {
    mul_ln1118_341_fu_1100_p2 = (!mul_ln1118_341_fu_1100_p0.read().is_01() || !ap_const_lv26_3FFFEBA.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_341_fu_1100_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEBA);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_342_fu_1107_p0() {
    mul_ln1118_342_fu_1107_p0 = sext_ln1116_48_cast67_fu_292108_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_342_fu_1107_p2() {
    mul_ln1118_342_fu_1107_p2 = (!mul_ln1118_342_fu_1107_p0.read().is_01() || !ap_const_lv25_1FFFF1D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_342_fu_1107_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF1D);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_343_fu_888_p0() {
    mul_ln1118_343_fu_888_p0 = sext_ln1116_48_cast68_fu_292103_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_343_fu_888_p2() {
    mul_ln1118_343_fu_888_p2 = (!mul_ln1118_343_fu_888_p0.read().is_01() || !ap_const_lv22_1A.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_343_fu_888_p0.read()) * sc_biguint<22>(ap_const_lv22_1A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_344_fu_989_p0() {
    mul_ln1118_344_fu_989_p0 =  (sc_lv<16>) (sext_ln1116_48_cast_fu_292117_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_344_fu_989_p2() {
    mul_ln1118_344_fu_989_p2 = (!mul_ln1118_344_fu_989_p0.read().is_01() || !ap_const_lv26_1A7.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_344_fu_989_p0.read()) * sc_biguint<26>(ap_const_lv26_1A7);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_345_fu_883_p0() {
    mul_ln1118_345_fu_883_p0 =  (sc_lv<16>) (sext_ln1116_48_cast_fu_292117_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_345_fu_883_p2() {
    mul_ln1118_345_fu_883_p2 = (!mul_ln1118_345_fu_883_p0.read().is_01() || !ap_const_lv26_3FFFED6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_345_fu_883_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_346_fu_1142_p0() {
    mul_ln1118_346_fu_1142_p0 = sext_ln1116_48_cast69_fu_292098_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_346_fu_1142_p2() {
    mul_ln1118_346_fu_1142_p2 = (!mul_ln1118_346_fu_1142_p0.read().is_01() || !ap_const_lv24_4B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_346_fu_1142_p0.read()) * sc_biguint<24>(ap_const_lv24_4B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_347_fu_1143_p0() {
    mul_ln1118_347_fu_1143_p0 =  (sc_lv<16>) (sext_ln1116_49_cast_fu_292227_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_347_fu_1143_p2() {
    mul_ln1118_347_fu_1143_p2 = (!mul_ln1118_347_fu_1143_p0.read().is_01() || !ap_const_lv26_24B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_347_fu_1143_p0.read()) * sc_biguint<26>(ap_const_lv26_24B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_348_fu_1144_p0() {
    mul_ln1118_348_fu_1144_p0 =  (sc_lv<16>) (sext_ln1116_49_cast64_fu_292221_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_348_fu_1144_p2() {
    mul_ln1118_348_fu_1144_p2 = (!mul_ln1118_348_fu_1144_p0.read().is_01() || !ap_const_lv25_1FFFF75.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_348_fu_1144_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF75);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_349_fu_1145_p0() {
    mul_ln1118_349_fu_1145_p0 =  (sc_lv<16>) (sext_ln1116_49_cast64_fu_292221_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_349_fu_1145_p2() {
    mul_ln1118_349_fu_1145_p2 = (!mul_ln1118_349_fu_1145_p0.read().is_01() || !ap_const_lv25_1FFFF5F.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_349_fu_1145_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF5F);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_350_fu_977_p0() {
    mul_ln1118_350_fu_977_p0 =  (sc_lv<16>) (sext_ln1116_49_cast_fu_292227_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_350_fu_977_p2() {
    mul_ln1118_350_fu_977_p2 = (!mul_ln1118_350_fu_977_p0.read().is_01() || !ap_const_lv26_2E6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_350_fu_977_p0.read()) * sc_biguint<26>(ap_const_lv26_2E6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_351_fu_920_p0() {
    mul_ln1118_351_fu_920_p0 = sext_ln1116_49_cast65_fu_292216_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_351_fu_920_p2() {
    mul_ln1118_351_fu_920_p2 = (!mul_ln1118_351_fu_920_p0.read().is_01() || !ap_const_lv23_7FFFCD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_351_fu_920_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCD);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_352_fu_1029_p0() {
    mul_ln1118_352_fu_1029_p0 =  (sc_lv<16>) (sext_ln1116_49_cast_fu_292227_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_352_fu_1029_p2() {
    mul_ln1118_352_fu_1029_p2 = (!mul_ln1118_352_fu_1029_p0.read().is_01() || !ap_const_lv26_371.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_352_fu_1029_p0.read()) * sc_biguint<26>(ap_const_lv26_371);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_353_fu_1055_p0() {
    mul_ln1118_353_fu_1055_p0 =  (sc_lv<16>) (sext_ln1116_49_cast_fu_292227_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_353_fu_1055_p2() {
    mul_ln1118_353_fu_1055_p2 = (!mul_ln1118_353_fu_1055_p0.read().is_01() || !ap_const_lv26_1A3.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_353_fu_1055_p0.read()) * sc_biguint<26>(ap_const_lv26_1A3);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_354_fu_1024_p0() {
    mul_ln1118_354_fu_1024_p0 =  (sc_lv<16>) (sext_ln1116_49_cast_fu_292227_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_354_fu_1024_p2() {
    mul_ln1118_354_fu_1024_p2 = (!mul_ln1118_354_fu_1024_p0.read().is_01() || !ap_const_lv26_3FFFD8F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_354_fu_1024_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD8F);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_355_fu_893_p0() {
    mul_ln1118_355_fu_893_p0 =  (sc_lv<16>) (sext_ln1116_50_cast62_fu_292333_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_355_fu_893_p2() {
    mul_ln1118_355_fu_893_p2 = (!mul_ln1118_355_fu_893_p0.read().is_01() || !ap_const_lv25_1FFFF43.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_355_fu_893_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF43);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_356_fu_881_p0() {
    mul_ln1118_356_fu_881_p0 =  (sc_lv<16>) (sext_ln1116_50_cast62_fu_292333_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_356_fu_881_p2() {
    mul_ln1118_356_fu_881_p2 = (!mul_ln1118_356_fu_881_p0.read().is_01() || !ap_const_lv25_A7.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_356_fu_881_p0.read()) * sc_biguint<25>(ap_const_lv25_A7);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_357_fu_1095_p0() {
    mul_ln1118_357_fu_1095_p0 = sext_ln1116_50_cast63_fu_292328_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_357_fu_1095_p2() {
    mul_ln1118_357_fu_1095_p2 = (!mul_ln1118_357_fu_1095_p0.read().is_01() || !ap_const_lv23_29.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_357_fu_1095_p0.read()) * sc_biguint<23>(ap_const_lv23_29);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_358_fu_967_p0() {
    mul_ln1118_358_fu_967_p0 =  (sc_lv<16>) (sext_ln1116_50_cast61_fu_292339_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_358_fu_967_p2() {
    mul_ln1118_358_fu_967_p2 = (!mul_ln1118_358_fu_967_p0.read().is_01() || !ap_const_lv26_3FFFD2F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_358_fu_967_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD2F);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_359_fu_968_p0() {
    mul_ln1118_359_fu_968_p0 =  (sc_lv<16>) (sext_ln1116_50_cast61_fu_292339_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_359_fu_968_p2() {
    mul_ln1118_359_fu_968_p2 = (!mul_ln1118_359_fu_968_p0.read().is_01() || !ap_const_lv26_3FFFDA7.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_359_fu_968_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDA7);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_360_fu_1148_p0() {
    mul_ln1118_360_fu_1148_p0 =  (sc_lv<16>) (sext_ln1116_51_cast59_fu_292471_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_360_fu_1148_p2() {
    mul_ln1118_360_fu_1148_p2 = (!mul_ln1118_360_fu_1148_p0.read().is_01() || !ap_const_lv26_3FFFECB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_360_fu_1148_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFECB);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_361_fu_970_p0() {
    mul_ln1118_361_fu_970_p0 =  (sc_lv<16>) (sext_ln1116_51_cast59_fu_292471_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_361_fu_970_p2() {
    mul_ln1118_361_fu_970_p2 = (!mul_ln1118_361_fu_970_p0.read().is_01() || !ap_const_lv26_12E.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_361_fu_970_p0.read()) * sc_biguint<26>(ap_const_lv26_12E);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_362_fu_1157_p0() {
    mul_ln1118_362_fu_1157_p0 = sext_ln1116_51_cast_fu_292478_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_362_fu_1157_p2() {
    mul_ln1118_362_fu_1157_p2 = (!mul_ln1118_362_fu_1157_p0.read().is_01() || !ap_const_lv22_17.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_362_fu_1157_p0.read()) * sc_biguint<22>(ap_const_lv22_17);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_363_fu_972_p0() {
    mul_ln1118_363_fu_972_p0 =  (sc_lv<16>) (sext_ln1116_51_cast59_fu_292471_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_363_fu_972_p2() {
    mul_ln1118_363_fu_972_p2 = (!mul_ln1118_363_fu_972_p0.read().is_01() || !ap_const_lv26_1B5.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_363_fu_972_p0.read()) * sc_biguint<26>(ap_const_lv26_1B5);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_364_fu_1059_p0() {
    mul_ln1118_364_fu_1059_p0 =  (sc_lv<16>) (sext_ln1116_52_cast_fu_292675_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_364_fu_1059_p2() {
    mul_ln1118_364_fu_1059_p2 = (!mul_ln1118_364_fu_1059_p0.read().is_01() || !ap_const_lv26_24E.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_364_fu_1059_p0.read()) * sc_biguint<26>(ap_const_lv26_24E);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_365_fu_1135_p0() {
    mul_ln1118_365_fu_1135_p0 =  (sc_lv<16>) (sext_ln1116_52_cast55_fu_292669_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_365_fu_1135_p2() {
    mul_ln1118_365_fu_1135_p2 = (!mul_ln1118_365_fu_1135_p0.read().is_01() || !ap_const_lv25_B0.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_365_fu_1135_p0.read()) * sc_biguint<25>(ap_const_lv25_B0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_366_fu_935_p0() {
    mul_ln1118_366_fu_935_p0 =  (sc_lv<16>) (sext_ln1116_52_cast55_fu_292669_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_366_fu_935_p2() {
    mul_ln1118_366_fu_935_p2 = (!mul_ln1118_366_fu_935_p0.read().is_01() || !ap_const_lv25_EF.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_366_fu_935_p0.read()) * sc_biguint<25>(ap_const_lv25_EF);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_367_fu_1086_p0() {
    mul_ln1118_367_fu_1086_p0 =  (sc_lv<16>) (sext_ln1116_52_cast56_fu_292661_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_367_fu_1086_p2() {
    mul_ln1118_367_fu_1086_p2 = (!mul_ln1118_367_fu_1086_p0.read().is_01() || !ap_const_lv24_52.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_367_fu_1086_p0.read()) * sc_biguint<24>(ap_const_lv24_52);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_368_fu_1093_p0() {
    mul_ln1118_368_fu_1093_p0 =  (sc_lv<16>) (sext_ln1116_52_cast56_fu_292661_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_368_fu_1093_p2() {
    mul_ln1118_368_fu_1093_p2 = (!mul_ln1118_368_fu_1093_p0.read().is_01() || !ap_const_lv24_FFFF9D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_368_fu_1093_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9D);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_369_fu_1125_p0() {
    mul_ln1118_369_fu_1125_p0 =  (sc_lv<16>) (sext_ln1116_52_cast56_fu_292661_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_369_fu_1125_p2() {
    mul_ln1118_369_fu_1125_p2 = (!mul_ln1118_369_fu_1125_p0.read().is_01() || !ap_const_lv24_FFFFAF.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_369_fu_1125_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFAF);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_370_fu_906_p0() {
    mul_ln1118_370_fu_906_p0 =  (sc_lv<16>) (sext_ln1116_52_cast56_fu_292661_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_370_fu_906_p2() {
    mul_ln1118_370_fu_906_p2 = (!mul_ln1118_370_fu_906_p0.read().is_01() || !ap_const_lv24_FFFF86.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_370_fu_906_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF86);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_371_fu_1087_p0() {
    mul_ln1118_371_fu_1087_p0 =  (sc_lv<16>) (sext_ln1116_52_cast_fu_292675_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_371_fu_1087_p2() {
    mul_ln1118_371_fu_1087_p2 = (!mul_ln1118_371_fu_1087_p0.read().is_01() || !ap_const_lv26_3FFFED4.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_371_fu_1087_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED4);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_372_fu_1152_p0() {
    mul_ln1118_372_fu_1152_p0 =  (sc_lv<16>) (sext_ln1116_53_cast_fu_292791_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_372_fu_1152_p2() {
    mul_ln1118_372_fu_1152_p2 = (!mul_ln1118_372_fu_1152_p0.read().is_01() || !ap_const_lv26_2C4.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_372_fu_1152_p0.read()) * sc_biguint<26>(ap_const_lv26_2C4);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_373_fu_912_p0() {
    mul_ln1118_373_fu_912_p0 =  (sc_lv<16>) (sext_ln1116_53_cast_fu_292791_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_373_fu_912_p2() {
    mul_ln1118_373_fu_912_p2 = (!mul_ln1118_373_fu_912_p0.read().is_01() || !ap_const_lv26_3FFFEAD.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_373_fu_912_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEAD);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_374_fu_913_p0() {
    mul_ln1118_374_fu_913_p0 =  (sc_lv<16>) (sext_ln1116_53_cast_fu_292791_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_374_fu_913_p2() {
    mul_ln1118_374_fu_913_p2 = (!mul_ln1118_374_fu_913_p0.read().is_01() || !ap_const_lv26_3FFFDE6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_374_fu_913_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDE6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_375_fu_929_p0() {
    mul_ln1118_375_fu_929_p0 =  (sc_lv<16>) (sext_ln1116_53_cast_fu_292791_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_375_fu_929_p2() {
    mul_ln1118_375_fu_929_p2 = (!mul_ln1118_375_fu_929_p0.read().is_01() || !ap_const_lv26_3FFFDEB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_375_fu_929_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDEB);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_376_fu_1064_p0() {
    mul_ln1118_376_fu_1064_p0 =  (sc_lv<16>) (sext_ln1116_53_cast54_fu_292785_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_376_fu_1064_p2() {
    mul_ln1118_376_fu_1064_p2 = (!mul_ln1118_376_fu_1064_p0.read().is_01() || !ap_const_lv25_F6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_376_fu_1064_p0.read()) * sc_biguint<25>(ap_const_lv25_F6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_377_fu_933_p0() {
    mul_ln1118_377_fu_933_p0 =  (sc_lv<16>) (sext_ln1116_53_cast_fu_292791_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_377_fu_933_p2() {
    mul_ln1118_377_fu_933_p2 = (!mul_ln1118_377_fu_933_p0.read().is_01() || !ap_const_lv26_142.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_377_fu_933_p0.read()) * sc_biguint<26>(ap_const_lv26_142);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_378_fu_1015_p0() {
    mul_ln1118_378_fu_1015_p0 =  (sc_lv<16>) (sext_ln1116_53_cast54_fu_292785_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_378_fu_1015_p2() {
    mul_ln1118_378_fu_1015_p2 = (!mul_ln1118_378_fu_1015_p0.read().is_01() || !ap_const_lv25_F1.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_378_fu_1015_p0.read()) * sc_biguint<25>(ap_const_lv25_F1);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_379_fu_1047_p0() {
    mul_ln1118_379_fu_1047_p0 =  (sc_lv<16>) (sext_ln1116_54_cast_fu_292937_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_379_fu_1047_p2() {
    mul_ln1118_379_fu_1047_p2 = (!mul_ln1118_379_fu_1047_p0.read().is_01() || !ap_const_lv23_7FFFDA.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_379_fu_1047_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDA);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_380_fu_1098_p0() {
    mul_ln1118_380_fu_1098_p0 =  (sc_lv<16>) (sext_ln1116_54_cast52_fu_292930_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_380_fu_1098_p2() {
    mul_ln1118_380_fu_1098_p2 = (!mul_ln1118_380_fu_1098_p0.read().is_01() || !ap_const_lv26_123.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_380_fu_1098_p0.read()) * sc_biguint<26>(ap_const_lv26_123);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_381_fu_1155_p0() {
    mul_ln1118_381_fu_1155_p0 =  (sc_lv<16>) (sext_ln1116_54_cast52_fu_292930_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_381_fu_1155_p2() {
    mul_ln1118_381_fu_1155_p2 = (!mul_ln1118_381_fu_1155_p0.read().is_01() || !ap_const_lv26_236.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_381_fu_1155_p0.read()) * sc_biguint<26>(ap_const_lv26_236);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_382_fu_1085_p0() {
    mul_ln1118_382_fu_1085_p0 =  (sc_lv<16>) (sext_ln1116_54_cast_fu_292937_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_382_fu_1085_p2() {
    mul_ln1118_382_fu_1085_p2 = (!mul_ln1118_382_fu_1085_p0.read().is_01() || !ap_const_lv23_7FFFC3.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_382_fu_1085_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFC3);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_383_fu_907_p0() {
    mul_ln1118_383_fu_907_p0 =  (sc_lv<16>) (sext_ln1116_54_cast53_fu_292924_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_383_fu_907_p2() {
    mul_ln1118_383_fu_907_p2 = (!mul_ln1118_383_fu_907_p0.read().is_01() || !ap_const_lv25_1FFFF2B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_383_fu_907_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF2B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_384_fu_908_p0() {
    mul_ln1118_384_fu_908_p0 =  (sc_lv<16>) (sext_ln1116_54_cast_fu_292937_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_384_fu_908_p2() {
    mul_ln1118_384_fu_908_p2 = (!mul_ln1118_384_fu_908_p0.read().is_01() || !ap_const_lv23_7FFFCC.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_384_fu_908_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCC);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_385_fu_971_p0() {
    mul_ln1118_385_fu_971_p0 =  (sc_lv<16>) (sext_ln1116_54_cast52_fu_292930_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_385_fu_971_p2() {
    mul_ln1118_385_fu_971_p2 = (!mul_ln1118_385_fu_971_p0.read().is_01() || !ap_const_lv26_173.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_385_fu_971_p0.read()) * sc_biguint<26>(ap_const_lv26_173);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_386_fu_1027_p0() {
    mul_ln1118_386_fu_1027_p0 =  (sc_lv<16>) (sext_ln1116_54_cast53_fu_292924_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_386_fu_1027_p2() {
    mul_ln1118_386_fu_1027_p2 = (!mul_ln1118_386_fu_1027_p0.read().is_01() || !ap_const_lv25_ED.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_386_fu_1027_p0.read()) * sc_biguint<25>(ap_const_lv25_ED);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_387_fu_1097_p0() {
    mul_ln1118_387_fu_1097_p0 =  (sc_lv<16>) (sext_ln1116_55_cast_fu_293056_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_387_fu_1097_p2() {
    mul_ln1118_387_fu_1097_p2 = (!mul_ln1118_387_fu_1097_p0.read().is_01() || !ap_const_lv24_6B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_387_fu_1097_p0.read()) * sc_biguint<24>(ap_const_lv24_6B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_388_fu_995_p0() {
    mul_ln1118_388_fu_995_p0 = sext_ln1116_55_cast49_fu_293051_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_388_fu_995_p2() {
    mul_ln1118_388_fu_995_p2 = (!mul_ln1118_388_fu_995_p0.read().is_01() || !ap_const_lv23_7FFFCD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_388_fu_995_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCD);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_389_fu_900_p0() {
    mul_ln1118_389_fu_900_p0 =  (sc_lv<16>) (sext_ln1116_55_cast_fu_293056_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_389_fu_900_p2() {
    mul_ln1118_389_fu_900_p2 = (!mul_ln1118_389_fu_900_p0.read().is_01() || !ap_const_lv24_FFFFA4.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_389_fu_900_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA4);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_390_fu_1045_p0() {
    mul_ln1118_390_fu_1045_p0 =  (sc_lv<16>) (sext_ln1116_55_cast51_fu_293044_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_390_fu_1045_p2() {
    mul_ln1118_390_fu_1045_p2 = (!mul_ln1118_390_fu_1045_p0.read().is_01() || !ap_const_lv26_13C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_390_fu_1045_p0.read()) * sc_biguint<26>(ap_const_lv26_13C);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_391_fu_889_p0() {
    mul_ln1118_391_fu_889_p0 =  (sc_lv<16>) (sext_ln1116_55_cast51_fu_293044_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_391_fu_889_p2() {
    mul_ln1118_391_fu_889_p2 = (!mul_ln1118_391_fu_889_p0.read().is_01() || !ap_const_lv26_3FFFEF2.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_391_fu_889_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEF2);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_392_fu_877_p0() {
    mul_ln1118_392_fu_877_p0 =  (sc_lv<16>) (sext_ln1116_55_cast51_fu_293044_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_392_fu_877_p2() {
    mul_ln1118_392_fu_877_p2 = (!mul_ln1118_392_fu_877_p0.read().is_01() || !ap_const_lv26_3FFFDBE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_392_fu_877_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDBE);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_393_fu_978_p0() {
    mul_ln1118_393_fu_978_p0 =  (sc_lv<16>) (sext_ln1116_56_cast_fu_293190_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_393_fu_978_p2() {
    mul_ln1118_393_fu_978_p2 = (!mul_ln1118_393_fu_978_p0.read().is_01() || !ap_const_lv25_8B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_393_fu_978_p0.read()) * sc_biguint<25>(ap_const_lv25_8B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_394_fu_941_p0() {
    mul_ln1118_394_fu_941_p0 =  (sc_lv<16>) (sext_ln1116_56_cast47_fu_293183_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_394_fu_941_p2() {
    mul_ln1118_394_fu_941_p2 = (!mul_ln1118_394_fu_941_p0.read().is_01() || !ap_const_lv26_178.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_394_fu_941_p0.read()) * sc_biguint<26>(ap_const_lv26_178);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_395_fu_1021_p0() {
    mul_ln1118_395_fu_1021_p0 =  (sc_lv<16>) (sext_ln1116_56_cast_fu_293190_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_395_fu_1021_p2() {
    mul_ln1118_395_fu_1021_p2 = (!mul_ln1118_395_fu_1021_p0.read().is_01() || !ap_const_lv25_D7.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_395_fu_1021_p0.read()) * sc_biguint<25>(ap_const_lv25_D7);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_396_fu_1139_p0() {
    mul_ln1118_396_fu_1139_p0 =  (sc_lv<16>) (sext_ln1116_56_cast_fu_293190_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_396_fu_1139_p2() {
    mul_ln1118_396_fu_1139_p2 = (!mul_ln1118_396_fu_1139_p0.read().is_01() || !ap_const_lv25_1FFFF06.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_396_fu_1139_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF06);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_397_fu_1154_p0() {
    mul_ln1118_397_fu_1154_p0 = sext_ln1116_56_cast48_fu_293178_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_397_fu_1154_p2() {
    mul_ln1118_397_fu_1154_p2 = (!mul_ln1118_397_fu_1154_p0.read().is_01() || !ap_const_lv23_7FFFD6.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_397_fu_1154_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_398_fu_1141_p0() {
    mul_ln1118_398_fu_1141_p0 =  (sc_lv<16>) (sext_ln1116_56_cast47_fu_293183_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_398_fu_1141_p2() {
    mul_ln1118_398_fu_1141_p2 = (!mul_ln1118_398_fu_1141_p0.read().is_01() || !ap_const_lv26_3FFFDCC.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_398_fu_1141_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDCC);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_399_fu_1025_p0() {
    mul_ln1118_399_fu_1025_p0 =  (sc_lv<16>) (sext_ln1116_56_cast47_fu_293183_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_399_fu_1025_p2() {
    mul_ln1118_399_fu_1025_p2 = (!mul_ln1118_399_fu_1025_p0.read().is_01() || !ap_const_lv26_3FFFEAF.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_399_fu_1025_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEAF);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_400_fu_1118_p0() {
    mul_ln1118_400_fu_1118_p0 = sext_ln1116_57_cast_fu_293333_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_400_fu_1118_p2() {
    mul_ln1118_400_fu_1118_p2 = (!mul_ln1118_400_fu_1118_p0.read().is_01() || !ap_const_lv23_7FFFCD.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_400_fu_1118_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFCD);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_401_fu_1112_p0() {
    mul_ln1118_401_fu_1112_p0 =  (sc_lv<16>) (sext_ln1116_57_cast44_fu_293325_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_401_fu_1112_p2() {
    mul_ln1118_401_fu_1112_p2 = (!mul_ln1118_401_fu_1112_p0.read().is_01() || !ap_const_lv26_3FFFEA4.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_401_fu_1112_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEA4);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_402_fu_1075_p0() {
    mul_ln1118_402_fu_1075_p0 = sext_ln1116_57_cast45_fu_293320_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_402_fu_1075_p2() {
    mul_ln1118_402_fu_1075_p2 = (!mul_ln1118_402_fu_1075_p0.read().is_01() || !ap_const_lv25_1FFFF07.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_402_fu_1075_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF07);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_403_fu_1038_p0() {
    mul_ln1118_403_fu_1038_p0 =  (sc_lv<16>) (sext_ln1116_57_cast44_fu_293325_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_403_fu_1038_p2() {
    mul_ln1118_403_fu_1038_p2 = (!mul_ln1118_403_fu_1038_p0.read().is_01() || !ap_const_lv26_3FFFBC2.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_403_fu_1038_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFBC2);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_404_fu_976_p0() {
    mul_ln1118_404_fu_976_p0 =  (sc_lv<16>) (sext_ln1116_57_cast44_fu_293325_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_404_fu_976_p2() {
    mul_ln1118_404_fu_976_p2 = (!mul_ln1118_404_fu_976_p0.read().is_01() || !ap_const_lv26_3FFFD0F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_404_fu_976_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD0F);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_405_fu_1033_p0() {
    mul_ln1118_405_fu_1033_p0 =  (sc_lv<16>) (sext_ln1116_57_cast44_fu_293325_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_405_fu_1033_p2() {
    mul_ln1118_405_fu_1033_p2 = (!mul_ln1118_405_fu_1033_p0.read().is_01() || !ap_const_lv26_16C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_405_fu_1033_p0.read()) * sc_biguint<26>(ap_const_lv26_16C);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_406_fu_1109_p0() {
    mul_ln1118_406_fu_1109_p0 = sext_ln1116_57_cast46_fu_293315_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_406_fu_1109_p2() {
    mul_ln1118_406_fu_1109_p2 = (!mul_ln1118_406_fu_1109_p0.read().is_01() || !ap_const_lv24_FFFF9E.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_406_fu_1109_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9E);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_407_fu_1080_p0() {
    mul_ln1118_407_fu_1080_p0 =  (sc_lv<16>) (sext_ln1116_58_cast_fu_293470_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_407_fu_1080_p2() {
    mul_ln1118_407_fu_1080_p2 = (!mul_ln1118_407_fu_1080_p0.read().is_01() || !ap_const_lv26_3FFFEDE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_407_fu_1080_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEDE);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_408_fu_1019_p0() {
    mul_ln1118_408_fu_1019_p0 =  (sc_lv<16>) (sext_ln1116_58_cast_fu_293470_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_408_fu_1019_p2() {
    mul_ln1118_408_fu_1019_p2 = (!mul_ln1118_408_fu_1019_p0.read().is_01() || !ap_const_lv26_4FA.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_408_fu_1019_p0.read()) * sc_biguint<26>(ap_const_lv26_4FA);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_409_fu_910_p0() {
    mul_ln1118_409_fu_910_p0 =  (sc_lv<16>) (sext_ln1116_58_cast_fu_293470_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_409_fu_910_p2() {
    mul_ln1118_409_fu_910_p2 = (!mul_ln1118_409_fu_910_p0.read().is_01() || !ap_const_lv26_18B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_409_fu_910_p0.read()) * sc_biguint<26>(ap_const_lv26_18B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_410_fu_1138_p0() {
    mul_ln1118_410_fu_1138_p0 =  (sc_lv<16>) (sext_ln1116_58_cast43_fu_293464_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_410_fu_1138_p2() {
    mul_ln1118_410_fu_1138_p2 = (!mul_ln1118_410_fu_1138_p0.read().is_01() || !ap_const_lv25_9A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_410_fu_1138_p0.read()) * sc_biguint<25>(ap_const_lv25_9A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_411_fu_1043_p0() {
    mul_ln1118_411_fu_1043_p0 =  (sc_lv<16>) (sext_ln1116_58_cast43_fu_293464_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_411_fu_1043_p2() {
    mul_ln1118_411_fu_1043_p2 = (!mul_ln1118_411_fu_1043_p0.read().is_01() || !ap_const_lv25_C6.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_411_fu_1043_p0.read()) * sc_biguint<25>(ap_const_lv25_C6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_412_fu_1140_p0() {
    mul_ln1118_412_fu_1140_p0 =  (sc_lv<16>) (sext_ln1116_58_cast_fu_293470_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_412_fu_1140_p2() {
    mul_ln1118_412_fu_1140_p2 = (!mul_ln1118_412_fu_1140_p0.read().is_01() || !ap_const_lv26_3FFFE3D.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_412_fu_1140_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE3D);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_413_fu_1117_p0() {
    mul_ln1118_413_fu_1117_p0 =  (sc_lv<16>) (sext_ln1116_58_cast_fu_293470_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_413_fu_1117_p2() {
    mul_ln1118_413_fu_1117_p2 = (!mul_ln1118_413_fu_1117_p0.read().is_01() || !ap_const_lv26_3FFFC98.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_413_fu_1117_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFC98);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_414_fu_943_p0() {
    mul_ln1118_414_fu_943_p0 =  (sc_lv<16>) (sext_ln1116_58_cast_fu_293470_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_414_fu_943_p2() {
    mul_ln1118_414_fu_943_p2 = (!mul_ln1118_414_fu_943_p0.read().is_01() || !ap_const_lv26_27C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_414_fu_943_p0.read()) * sc_biguint<26>(ap_const_lv26_27C);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_415_fu_955_p0() {
    mul_ln1118_415_fu_955_p0 =  (sc_lv<16>) (sext_ln1116_59_cast_fu_293574_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_415_fu_955_p2() {
    mul_ln1118_415_fu_955_p2 = (!mul_ln1118_415_fu_955_p0.read().is_01() || !ap_const_lv26_14A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_415_fu_955_p0.read()) * sc_biguint<26>(ap_const_lv26_14A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_416_fu_1069_p0() {
    mul_ln1118_416_fu_1069_p0 =  (sc_lv<16>) (sext_ln1116_59_cast42_fu_293568_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_416_fu_1069_p2() {
    mul_ln1118_416_fu_1069_p2 = (!mul_ln1118_416_fu_1069_p0.read().is_01() || !ap_const_lv25_1FFFF31.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_416_fu_1069_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF31);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_417_fu_1101_p0() {
    mul_ln1118_417_fu_1101_p0 =  (sc_lv<16>) (sext_ln1116_59_cast_fu_293574_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_417_fu_1101_p2() {
    mul_ln1118_417_fu_1101_p2 = (!mul_ln1118_417_fu_1101_p0.read().is_01() || !ap_const_lv26_191.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_417_fu_1101_p0.read()) * sc_biguint<26>(ap_const_lv26_191);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_418_fu_1026_p0() {
    mul_ln1118_418_fu_1026_p0 =  (sc_lv<16>) (sext_ln1116_59_cast42_fu_293568_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_418_fu_1026_p2() {
    mul_ln1118_418_fu_1026_p2 = (!mul_ln1118_418_fu_1026_p0.read().is_01() || !ap_const_lv25_1FFFF68.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_418_fu_1026_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF68);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_419_fu_1077_p0() {
    mul_ln1118_419_fu_1077_p0 =  (sc_lv<16>) (sext_ln1116_59_cast_fu_293574_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_419_fu_1077_p2() {
    mul_ln1118_419_fu_1077_p2 = (!mul_ln1118_419_fu_1077_p0.read().is_01() || !ap_const_lv26_3FFFE76.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_419_fu_1077_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE76);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_420_fu_1023_p0() {
    mul_ln1118_420_fu_1023_p0 =  (sc_lv<16>) (sext_ln1116_59_cast_fu_293574_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_420_fu_1023_p2() {
    mul_ln1118_420_fu_1023_p2 = (!mul_ln1118_420_fu_1023_p0.read().is_01() || !ap_const_lv26_222.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_420_fu_1023_p0.read()) * sc_biguint<26>(ap_const_lv26_222);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_421_fu_962_p0() {
    mul_ln1118_421_fu_962_p0 =  (sc_lv<16>) (sext_ln1116_59_cast_fu_293574_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_421_fu_962_p2() {
    mul_ln1118_421_fu_962_p2 = (!mul_ln1118_421_fu_962_p0.read().is_01() || !ap_const_lv26_3FFFDC6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_421_fu_962_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDC6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_422_fu_963_p0() {
    mul_ln1118_422_fu_963_p0 =  (sc_lv<16>) (sext_ln1116_60_cast_fu_293674_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_422_fu_963_p2() {
    mul_ln1118_422_fu_963_p2 = (!mul_ln1118_422_fu_963_p0.read().is_01() || !ap_const_lv25_1FFFF28.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_422_fu_963_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF28);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_423_fu_964_p0() {
    mul_ln1118_423_fu_964_p0 =  (sc_lv<16>) (sext_ln1116_60_cast40_fu_293666_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_423_fu_964_p2() {
    mul_ln1118_423_fu_964_p2 = (!mul_ln1118_423_fu_964_p0.read().is_01() || !ap_const_lv26_197.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_423_fu_964_p0.read()) * sc_biguint<26>(ap_const_lv26_197);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_424_fu_965_p0() {
    mul_ln1118_424_fu_965_p0 =  (sc_lv<16>) (sext_ln1116_60_cast40_fu_293666_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_424_fu_965_p2() {
    mul_ln1118_424_fu_965_p2 = (!mul_ln1118_424_fu_965_p0.read().is_01() || !ap_const_lv26_3FFFE5A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_424_fu_965_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE5A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_425_fu_1034_p0() {
    mul_ln1118_425_fu_1034_p0 = sext_ln1116_60_cast41_fu_293661_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_425_fu_1034_p2() {
    mul_ln1118_425_fu_1034_p2 = (!mul_ln1118_425_fu_1034_p0.read().is_01() || !ap_const_lv23_7FFFDA.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_425_fu_1034_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFDA);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_426_fu_884_p0() {
    mul_ln1118_426_fu_884_p0 =  (sc_lv<16>) (sext_ln1116_60_cast_fu_293674_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_426_fu_884_p2() {
    mul_ln1118_426_fu_884_p2 = (!mul_ln1118_426_fu_884_p0.read().is_01() || !ap_const_lv25_1FFFF41.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_426_fu_884_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF41);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_427_fu_1004_p0() {
    mul_ln1118_427_fu_1004_p0 =  (sc_lv<16>) (sext_ln1116_60_cast40_fu_293666_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_427_fu_1004_p2() {
    mul_ln1118_427_fu_1004_p2 = (!mul_ln1118_427_fu_1004_p0.read().is_01() || !ap_const_lv26_3FFFED4.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_427_fu_1004_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED4);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_428_fu_879_p0() {
    mul_ln1118_428_fu_879_p0 =  (sc_lv<16>) (sext_ln1116_60_cast40_fu_293666_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_428_fu_879_p2() {
    mul_ln1118_428_fu_879_p2 = (!mul_ln1118_428_fu_879_p0.read().is_01() || !ap_const_lv26_10E.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_428_fu_879_p0.read()) * sc_biguint<26>(ap_const_lv26_10E);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_429_fu_880_p0() {
    mul_ln1118_429_fu_880_p0 =  (sc_lv<16>) (sext_ln1116_60_cast_fu_293674_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_429_fu_880_p2() {
    mul_ln1118_429_fu_880_p2 = (!mul_ln1118_429_fu_880_p0.read().is_01() || !ap_const_lv25_BE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_429_fu_880_p0.read()) * sc_biguint<25>(ap_const_lv25_BE);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_430_fu_918_p0() {
    mul_ln1118_430_fu_918_p0 =  (sc_lv<16>) (sext_ln1116_61_cast_fu_293782_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_430_fu_918_p2() {
    mul_ln1118_430_fu_918_p2 = (!mul_ln1118_430_fu_918_p0.read().is_01() || !ap_const_lv26_10C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_430_fu_918_p0.read()) * sc_biguint<26>(ap_const_lv26_10C);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_431_fu_994_p0() {
    mul_ln1118_431_fu_994_p0 = sext_ln1116_61_cast38_fu_293777_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_431_fu_994_p2() {
    mul_ln1118_431_fu_994_p2 = (!mul_ln1118_431_fu_994_p0.read().is_01() || !ap_const_lv22_3FFFE9.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_431_fu_994_p0.read()) * sc_bigint<22>(ap_const_lv22_3FFFE9);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_432_fu_1020_p0() {
    mul_ln1118_432_fu_1020_p0 =  (sc_lv<16>) (sext_ln1116_61_cast_fu_293782_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_432_fu_1020_p2() {
    mul_ln1118_432_fu_1020_p2 = (!mul_ln1118_432_fu_1020_p0.read().is_01() || !ap_const_lv26_1D8.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_432_fu_1020_p0.read()) * sc_biguint<26>(ap_const_lv26_1D8);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_433_fu_1076_p0() {
    mul_ln1118_433_fu_1076_p0 =  (sc_lv<16>) (sext_ln1116_61_cast_fu_293782_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_433_fu_1076_p2() {
    mul_ln1118_433_fu_1076_p2 = (!mul_ln1118_433_fu_1076_p0.read().is_01() || !ap_const_lv26_3FFFD39.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_433_fu_1076_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFD39);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_434_fu_922_p0() {
    mul_ln1118_434_fu_922_p0 =  (sc_lv<16>) (sext_ln1116_61_cast_fu_293782_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_434_fu_922_p2() {
    mul_ln1118_434_fu_922_p2 = (!mul_ln1118_434_fu_922_p0.read().is_01() || !ap_const_lv26_3FFFE5E.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_434_fu_922_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE5E);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_435_fu_1078_p0() {
    mul_ln1118_435_fu_1078_p0 =  (sc_lv<16>) (sext_ln1116_61_cast_fu_293782_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_435_fu_1078_p2() {
    mul_ln1118_435_fu_1078_p2 = (!mul_ln1118_435_fu_1078_p0.read().is_01() || !ap_const_lv26_3FFFEB6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_435_fu_1078_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEB6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_436_fu_1079_p0() {
    mul_ln1118_436_fu_1079_p0 =  (sc_lv<16>) (sext_ln1116_61_cast_fu_293782_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_436_fu_1079_p2() {
    mul_ln1118_436_fu_1079_p2 = (!mul_ln1118_436_fu_1079_p0.read().is_01() || !ap_const_lv26_367.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_436_fu_1079_p0.read()) * sc_biguint<26>(ap_const_lv26_367);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_437_fu_1053_p0() {
    mul_ln1118_437_fu_1053_p0 =  (sc_lv<16>) (sext_ln1116_62_cast_fu_293926_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_437_fu_1053_p2() {
    mul_ln1118_437_fu_1053_p2 = (!mul_ln1118_437_fu_1053_p0.read().is_01() || !ap_const_lv26_198.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_437_fu_1053_p0.read()) * sc_biguint<26>(ap_const_lv26_198);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_438_fu_914_p0() {
    mul_ln1118_438_fu_914_p0 =  (sc_lv<16>) (sext_ln1116_62_cast_fu_293926_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_438_fu_914_p2() {
    mul_ln1118_438_fu_914_p2 = (!mul_ln1118_438_fu_914_p0.read().is_01() || !ap_const_lv26_328.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_438_fu_914_p0.read()) * sc_biguint<26>(ap_const_lv26_328);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_439_fu_949_p0() {
    mul_ln1118_439_fu_949_p0 =  (sc_lv<16>) (sext_ln1116_62_cast_fu_293926_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_439_fu_949_p2() {
    mul_ln1118_439_fu_949_p2 = (!mul_ln1118_439_fu_949_p0.read().is_01() || !ap_const_lv26_3FFFB45.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_439_fu_949_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFB45);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_440_fu_878_p0() {
    mul_ln1118_440_fu_878_p0 = sext_ln1116_62_cast36_fu_293921_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_440_fu_878_p2() {
    mul_ln1118_440_fu_878_p2 = (!mul_ln1118_440_fu_878_p0.read().is_01() || !ap_const_lv25_D2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_440_fu_878_p0.read()) * sc_biguint<25>(ap_const_lv25_D2);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_441_fu_985_p0() {
    mul_ln1118_441_fu_985_p0 =  (sc_lv<16>) (sext_ln1116_62_cast_fu_293926_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_441_fu_985_p2() {
    mul_ln1118_441_fu_985_p2 = (!mul_ln1118_441_fu_985_p0.read().is_01() || !ap_const_lv26_1C5.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_441_fu_985_p0.read()) * sc_biguint<26>(ap_const_lv26_1C5);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_442_fu_904_p0() {
    mul_ln1118_442_fu_904_p0 =  (sc_lv<16>) (sext_ln1116_62_cast_fu_293926_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_442_fu_904_p2() {
    mul_ln1118_442_fu_904_p2 = (!mul_ln1118_442_fu_904_p0.read().is_01() || !ap_const_lv26_3FFFCB5.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_442_fu_904_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFCB5);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_443_fu_980_p0() {
    mul_ln1118_443_fu_980_p0 =  (sc_lv<16>) (sext_ln1116_62_cast_fu_293926_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_443_fu_980_p2() {
    mul_ln1118_443_fu_980_p2 = (!mul_ln1118_443_fu_980_p0.read().is_01() || !ap_const_lv26_3FFFEDD.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_443_fu_980_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEDD);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_444_fu_928_p0() {
    mul_ln1118_444_fu_928_p0 = sext_ln1116_62_cast37_fu_293916_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_444_fu_928_p2() {
    mul_ln1118_444_fu_928_p2 = (!mul_ln1118_444_fu_928_p0.read().is_01() || !ap_const_lv24_6D.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_444_fu_928_p0.read()) * sc_biguint<24>(ap_const_lv24_6D);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_445_fu_901_p0() {
    mul_ln1118_445_fu_901_p0 =  (sc_lv<16>) (sext_ln1116_63_cast_fu_294042_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_445_fu_901_p2() {
    mul_ln1118_445_fu_901_p2 = (!mul_ln1118_445_fu_901_p0.read().is_01() || !ap_const_lv23_3D.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_445_fu_901_p0.read()) * sc_biguint<23>(ap_const_lv23_3D);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_446_fu_902_p0() {
    mul_ln1118_446_fu_902_p0 =  (sc_lv<16>) (sext_ln1116_63_cast33_fu_294035_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_446_fu_902_p2() {
    mul_ln1118_446_fu_902_p2 = (!mul_ln1118_446_fu_902_p0.read().is_01() || !ap_const_lv25_1FFFF4A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_446_fu_902_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF4A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_447_fu_903_p0() {
    mul_ln1118_447_fu_903_p0 =  (sc_lv<16>) (sext_ln1116_63_cast33_fu_294035_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_447_fu_903_p2() {
    mul_ln1118_447_fu_903_p2 = (!mul_ln1118_447_fu_903_p0.read().is_01() || !ap_const_lv25_1FFFF27.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_447_fu_903_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF27);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_448_fu_1083_p0() {
    mul_ln1118_448_fu_1083_p0 =  (sc_lv<16>) (sext_ln1116_63_cast33_fu_294035_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_448_fu_1083_p2() {
    mul_ln1118_448_fu_1083_p2 = (!mul_ln1118_448_fu_1083_p0.read().is_01() || !ap_const_lv25_1FFFF67.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_448_fu_1083_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF67);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_449_fu_1022_p0() {
    mul_ln1118_449_fu_1022_p0 =  (sc_lv<16>) (sext_ln1116_63_cast34_fu_294029_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_449_fu_1022_p2() {
    mul_ln1118_449_fu_1022_p2 = (!mul_ln1118_449_fu_1022_p0.read().is_01() || !ap_const_lv26_3FFFDC6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_449_fu_1022_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDC6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_450_fu_1057_p0() {
    mul_ln1118_450_fu_1057_p0 = sext_ln1116_63_cast35_fu_294024_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_450_fu_1057_p2() {
    mul_ln1118_450_fu_1057_p2 = (!mul_ln1118_450_fu_1057_p0.read().is_01() || !ap_const_lv24_FFFFA8.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_450_fu_1057_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA8);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_451_fu_1108_p0() {
    mul_ln1118_451_fu_1108_p0 =  (sc_lv<16>) (sext_ln1116_63_cast_fu_294042_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_451_fu_1108_p2() {
    mul_ln1118_451_fu_1108_p2 = (!mul_ln1118_451_fu_1108_p0.read().is_01() || !ap_const_lv23_3A.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_451_fu_1108_p0.read()) * sc_biguint<23>(ap_const_lv23_3A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_452_fu_1121_p0() {
    mul_ln1118_452_fu_1121_p0 =  (sc_lv<16>) (sext_ln1116_63_cast34_fu_294029_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_452_fu_1121_p2() {
    mul_ln1118_452_fu_1121_p2 = (!mul_ln1118_452_fu_1121_p0.read().is_01() || !ap_const_lv26_18A.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_452_fu_1121_p0.read()) * sc_biguint<26>(ap_const_lv26_18A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_453_fu_1153_p0() {
    mul_ln1118_453_fu_1153_p0 =  (sc_lv<16>) (sext_ln1116_64_cast_fu_294176_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_453_fu_1153_p2() {
    mul_ln1118_453_fu_1153_p2 = (!mul_ln1118_453_fu_1153_p0.read().is_01() || !ap_const_lv24_6A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_453_fu_1153_p0.read()) * sc_biguint<24>(ap_const_lv24_6A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_454_fu_1116_p0() {
    mul_ln1118_454_fu_1116_p0 = sext_ln1116_64_cast28_fu_294171_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_454_fu_1116_p2() {
    mul_ln1118_454_fu_1116_p2 = (!mul_ln1118_454_fu_1116_p0.read().is_01() || !ap_const_lv21_B.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_454_fu_1116_p0.read()) * sc_biguint<21>(ap_const_lv21_B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_455_fu_885_p0() {
    mul_ln1118_455_fu_885_p0 =  (sc_lv<16>) (sext_ln1116_64_cast30_fu_294161_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_455_fu_885_p2() {
    mul_ln1118_455_fu_885_p2 = (!mul_ln1118_455_fu_885_p0.read().is_01() || !ap_const_lv26_20B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_455_fu_885_p0.read()) * sc_biguint<26>(ap_const_lv26_20B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_456_fu_942_p0() {
    mul_ln1118_456_fu_942_p0 = sext_ln1116_64_cast32_fu_294152_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_456_fu_942_p2() {
    mul_ln1118_456_fu_942_p2 = (!mul_ln1118_456_fu_942_p0.read().is_01() || !ap_const_lv25_1FFFF74.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_456_fu_942_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF74);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_457_fu_1132_p0() {
    mul_ln1118_457_fu_1132_p0 =  (sc_lv<16>) (sext_ln1116_64_cast30_fu_294161_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_457_fu_1132_p2() {
    mul_ln1118_457_fu_1132_p2 = (!mul_ln1118_457_fu_1132_p0.read().is_01() || !ap_const_lv26_3FFFEBA.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_457_fu_1132_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEBA);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_458_fu_961_p0() {
    mul_ln1118_458_fu_961_p0 =  (sc_lv<16>) (sext_ln1116_64_cast_fu_294176_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_458_fu_961_p2() {
    mul_ln1118_458_fu_961_p2 = (!mul_ln1118_458_fu_961_p0.read().is_01() || !ap_const_lv24_FFFF94.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_458_fu_961_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF94);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_459_fu_1017_p0() {
    mul_ln1118_459_fu_1017_p0 =  (sc_lv<16>) (sext_ln1116_65_cast_fu_294327_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_459_fu_1017_p2() {
    mul_ln1118_459_fu_1017_p2 = (!mul_ln1118_459_fu_1017_p0.read().is_01() || !ap_const_lv25_EB.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_459_fu_1017_p0.read()) * sc_biguint<25>(ap_const_lv25_EB);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_460_fu_1018_p0() {
    mul_ln1118_460_fu_1018_p0 =  (sc_lv<16>) (sext_ln1116_65_cast25_fu_294321_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_460_fu_1018_p2() {
    mul_ln1118_460_fu_1018_p2 = (!mul_ln1118_460_fu_1018_p0.read().is_01() || !ap_const_lv24_74.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_460_fu_1018_p0.read()) * sc_biguint<24>(ap_const_lv24_74);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_461_fu_1081_p0() {
    mul_ln1118_461_fu_1081_p0 = sext_ln1116_65_cast26_fu_294316_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_461_fu_1081_p2() {
    mul_ln1118_461_fu_1081_p2 = (!mul_ln1118_461_fu_1081_p0.read().is_01() || !ap_const_lv21_1FFFF3.is_01())? sc_lv<21>(): sc_bigint<16>(mul_ln1118_461_fu_1081_p0.read()) * sc_bigint<21>(ap_const_lv21_1FFFF3);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_462_fu_1106_p0() {
    mul_ln1118_462_fu_1106_p0 =  (sc_lv<16>) (sext_ln1116_65_cast_fu_294327_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_462_fu_1106_p2() {
    mul_ln1118_462_fu_1106_p2 = (!mul_ln1118_462_fu_1106_p0.read().is_01() || !ap_const_lv25_B4.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_462_fu_1106_p0.read()) * sc_biguint<25>(ap_const_lv25_B4);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_463_fu_937_p0() {
    mul_ln1118_463_fu_937_p0 =  (sc_lv<16>) (sext_ln1116_65_cast27_fu_294310_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_463_fu_937_p2() {
    mul_ln1118_463_fu_937_p2 = (!mul_ln1118_463_fu_937_p0.read().is_01() || !ap_const_lv26_24C.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_463_fu_937_p0.read()) * sc_biguint<26>(ap_const_lv26_24C);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_464_fu_969_p0() {
    mul_ln1118_464_fu_969_p0 =  (sc_lv<16>) (sext_ln1116_65_cast25_fu_294321_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_464_fu_969_p2() {
    mul_ln1118_464_fu_969_p2 = (!mul_ln1118_464_fu_969_p0.read().is_01() || !ap_const_lv24_FFFF9B.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_464_fu_969_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF9B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_465_fu_951_p0() {
    mul_ln1118_465_fu_951_p0 =  (sc_lv<16>) (sext_ln1116_65_cast27_fu_294310_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_465_fu_951_p2() {
    mul_ln1118_465_fu_951_p2 = (!mul_ln1118_465_fu_951_p0.read().is_01() || !ap_const_lv26_3FFFE82.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_465_fu_951_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE82);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_466_fu_1008_p0() {
    mul_ln1118_466_fu_1008_p0 =  (sc_lv<16>) (sext_ln1116_65_cast_fu_294327_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_466_fu_1008_p2() {
    mul_ln1118_466_fu_1008_p2 = (!mul_ln1118_466_fu_1008_p0.read().is_01() || !ap_const_lv25_1FFFF1C.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_466_fu_1008_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF1C);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_467_fu_927_p0() {
    mul_ln1118_467_fu_927_p0 =  (sc_lv<16>) (sext_ln1116_66_cast_fu_294450_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_467_fu_927_p2() {
    mul_ln1118_467_fu_927_p2 = (!mul_ln1118_467_fu_927_p0.read().is_01() || !ap_const_lv23_25.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_467_fu_927_p0.read()) * sc_biguint<23>(ap_const_lv23_25);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_468_fu_934_p0() {
    mul_ln1118_468_fu_934_p0 =  (sc_lv<16>) (sext_ln1116_66_cast23_fu_294443_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_468_fu_934_p2() {
    mul_ln1118_468_fu_934_p2 = (!mul_ln1118_468_fu_934_p0.read().is_01() || !ap_const_lv26_1A5.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_468_fu_934_p0.read()) * sc_biguint<26>(ap_const_lv26_1A5);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_469_fu_1129_p0() {
    mul_ln1118_469_fu_1129_p0 =  (sc_lv<16>) (sext_ln1116_66_cast23_fu_294443_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_469_fu_1129_p2() {
    mul_ln1118_469_fu_1129_p2 = (!mul_ln1118_469_fu_1129_p0.read().is_01() || !ap_const_lv26_3FFFEEB.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_469_fu_1129_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEEB);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_470_fu_1130_p0() {
    mul_ln1118_470_fu_1130_p0 =  (sc_lv<16>) (sext_ln1116_66_cast23_fu_294443_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_470_fu_1130_p2() {
    mul_ln1118_470_fu_1130_p2 = (!mul_ln1118_470_fu_1130_p0.read().is_01() || !ap_const_lv26_3FFFCC4.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_470_fu_1130_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFCC4);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_471_fu_1131_p0() {
    mul_ln1118_471_fu_1131_p0 =  (sc_lv<16>) (sext_ln1116_66_cast_fu_294450_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_471_fu_1131_p2() {
    mul_ln1118_471_fu_1131_p2 = (!mul_ln1118_471_fu_1131_p0.read().is_01() || !ap_const_lv23_35.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_471_fu_1131_p0.read()) * sc_biguint<23>(ap_const_lv23_35);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_472_fu_960_p0() {
    mul_ln1118_472_fu_960_p0 = sext_ln1116_66_cast24_fu_294438_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_472_fu_960_p2() {
    mul_ln1118_472_fu_960_p2 = (!mul_ln1118_472_fu_960_p0.read().is_01() || !ap_const_lv25_1FFFF3E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_472_fu_960_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF3E);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_473_fu_1133_p0() {
    mul_ln1118_473_fu_1133_p0 =  (sc_lv<16>) (sext_ln1116_67_cast_fu_294619_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_473_fu_1133_p2() {
    mul_ln1118_473_fu_1133_p2 = (!mul_ln1118_473_fu_1133_p0.read().is_01() || !ap_const_lv24_5A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_473_fu_1133_p0.read()) * sc_biguint<24>(ap_const_lv24_5A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_474_fu_1046_p0() {
    mul_ln1118_474_fu_1046_p0 =  (sc_lv<16>) (sext_ln1116_67_cast_fu_294619_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_474_fu_1046_p2() {
    mul_ln1118_474_fu_1046_p2 = (!mul_ln1118_474_fu_1046_p0.read().is_01() || !ap_const_lv24_FFFFB6.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_474_fu_1046_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_475_fu_1036_p0() {
    mul_ln1118_475_fu_1036_p0 =  (sc_lv<16>) (sext_ln1116_67_cast_fu_294619_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_475_fu_1036_p2() {
    mul_ln1118_475_fu_1036_p2 = (!mul_ln1118_475_fu_1036_p0.read().is_01() || !ap_const_lv24_54.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_475_fu_1036_p0.read()) * sc_biguint<24>(ap_const_lv24_54);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_476_fu_974_p0() {
    mul_ln1118_476_fu_974_p0 = sext_ln1116_67_cast19_fu_294614_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_476_fu_974_p2() {
    mul_ln1118_476_fu_974_p2 = (!mul_ln1118_476_fu_974_p0.read().is_01() || !ap_const_lv26_112.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_476_fu_974_p0.read()) * sc_biguint<26>(ap_const_lv26_112);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_477_fu_1119_p0() {
    mul_ln1118_477_fu_1119_p0 =  (sc_lv<16>) (sext_ln1116_67_cast20_fu_294608_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_477_fu_1119_p2() {
    mul_ln1118_477_fu_1119_p2 = (!mul_ln1118_477_fu_1119_p0.read().is_01() || !ap_const_lv25_1FFFF7B.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_477_fu_1119_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF7B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_478_fu_925_p0() {
    mul_ln1118_478_fu_925_p0 =  (sc_lv<16>) (sext_ln1116_67_cast_fu_294619_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_478_fu_925_p2() {
    mul_ln1118_478_fu_925_p2 = (!mul_ln1118_478_fu_925_p0.read().is_01() || !ap_const_lv24_FFFF86.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_478_fu_925_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF86);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_479_fu_1001_p0() {
    mul_ln1118_479_fu_1001_p0 =  (sc_lv<16>) (sext_ln1116_67_cast20_fu_294608_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_479_fu_1001_p2() {
    mul_ln1118_479_fu_1001_p2 = (!mul_ln1118_479_fu_1001_p0.read().is_01() || !ap_const_lv25_1FFFF18.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_479_fu_1001_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF18);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_480_fu_983_p0() {
    mul_ln1118_480_fu_983_p0 =  (sc_lv<16>) (sext_ln1116_68_cast_fu_294765_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_480_fu_983_p2() {
    mul_ln1118_480_fu_983_p2 = (!mul_ln1118_480_fu_983_p0.read().is_01() || !ap_const_lv26_176.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_480_fu_983_p0.read()) * sc_biguint<26>(ap_const_lv26_176);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_481_fu_954_p0() {
    mul_ln1118_481_fu_954_p0 =  (sc_lv<16>) (sext_ln1116_68_cast16_fu_294758_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_481_fu_954_p2() {
    mul_ln1118_481_fu_954_p2 = (!mul_ln1118_481_fu_954_p0.read().is_01() || !ap_const_lv23_7FFFD6.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_481_fu_954_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_482_fu_1072_p0() {
    mul_ln1118_482_fu_1072_p0 = sext_ln1116_68_cast17_fu_294753_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_482_fu_1072_p2() {
    mul_ln1118_482_fu_1072_p2 = (!mul_ln1118_482_fu_1072_p0.read().is_01() || !ap_const_lv25_8D.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_482_fu_1072_p0.read()) * sc_biguint<25>(ap_const_lv25_8D);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_483_fu_1128_p0() {
    mul_ln1118_483_fu_1128_p0 =  (sc_lv<16>) (sext_ln1116_68_cast_fu_294765_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_483_fu_1128_p2() {
    mul_ln1118_483_fu_1128_p2 = (!mul_ln1118_483_fu_1128_p0.read().is_01() || !ap_const_lv26_19B.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_483_fu_1128_p0.read()) * sc_biguint<26>(ap_const_lv26_19B);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_484_fu_1074_p0() {
    mul_ln1118_484_fu_1074_p0 =  (sc_lv<16>) (sext_ln1116_68_cast_fu_294765_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_484_fu_1074_p2() {
    mul_ln1118_484_fu_1074_p2 = (!mul_ln1118_484_fu_1074_p0.read().is_01() || !ap_const_lv26_3FFFED1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_484_fu_1074_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED1);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_485_fu_979_p0() {
    mul_ln1118_485_fu_979_p0 =  (sc_lv<16>) (sext_ln1116_68_cast16_fu_294758_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_485_fu_979_p2() {
    mul_ln1118_485_fu_979_p2 = (!mul_ln1118_485_fu_979_p0.read().is_01() || !ap_const_lv23_7FFFD3.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_485_fu_979_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD3);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_486_fu_959_p0() {
    mul_ln1118_486_fu_959_p0 =  (sc_lv<16>) (sext_ln1116_68_cast16_fu_294758_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_486_fu_959_p2() {
    mul_ln1118_486_fu_959_p2 = (!mul_ln1118_486_fu_959_p0.read().is_01() || !ap_const_lv23_7FFFD9.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_486_fu_959_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD9);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_487_fu_1060_p0() {
    mul_ln1118_487_fu_1060_p0 =  (sc_lv<16>) (sext_ln1116_68_cast_fu_294765_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_487_fu_1060_p2() {
    mul_ln1118_487_fu_1060_p2 = (!mul_ln1118_487_fu_1060_p0.read().is_01() || !ap_const_lv26_3FFFED7.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_487_fu_1060_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED7);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_488_fu_1136_p0() {
    mul_ln1118_488_fu_1136_p0 =  (sc_lv<16>) (sext_ln1116_69_cast_fu_294885_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_488_fu_1136_p2() {
    mul_ln1118_488_fu_1136_p2 = (!mul_ln1118_488_fu_1136_p0.read().is_01() || !ap_const_lv25_1FFFF26.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_488_fu_1136_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF26);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_489_fu_992_p0() {
    mul_ln1118_489_fu_992_p0 =  (sc_lv<16>) (sext_ln1116_69_cast14_fu_294878_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_489_fu_992_p2() {
    mul_ln1118_489_fu_992_p2 = (!mul_ln1118_489_fu_992_p0.read().is_01() || !ap_const_lv26_3FFFEFA.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_489_fu_992_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEFA);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_490_fu_886_p0() {
    mul_ln1118_490_fu_886_p0 =  (sc_lv<16>) (sext_ln1116_69_cast14_fu_294878_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_490_fu_886_p2() {
    mul_ln1118_490_fu_886_p2 = (!mul_ln1118_490_fu_886_p0.read().is_01() || !ap_const_lv26_141.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_490_fu_886_p0.read()) * sc_biguint<26>(ap_const_lv26_141);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_491_fu_987_p0() {
    mul_ln1118_491_fu_987_p0 = sext_ln1116_69_cast15_fu_294869_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_491_fu_987_p2() {
    mul_ln1118_491_fu_987_p2 = (!mul_ln1118_491_fu_987_p0.read().is_01() || !ap_const_lv23_26.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_491_fu_987_p0.read()) * sc_biguint<23>(ap_const_lv23_26);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_492_fu_1063_p0() {
    mul_ln1118_492_fu_1063_p0 =  (sc_lv<16>) (sext_ln1116_69_cast14_fu_294878_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_492_fu_1063_p2() {
    mul_ln1118_492_fu_1063_p2 = (!mul_ln1118_492_fu_1063_p0.read().is_01() || !ap_const_lv26_2FC.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_492_fu_1063_p0.read()) * sc_biguint<26>(ap_const_lv26_2FC);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_493_fu_1068_p0() {
    mul_ln1118_493_fu_1068_p0 =  (sc_lv<16>) (sext_ln1116_69_cast_fu_294885_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_493_fu_1068_p2() {
    mul_ln1118_493_fu_1068_p2 = (!mul_ln1118_493_fu_1068_p0.read().is_01() || !ap_const_lv25_1FFFF6E.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_493_fu_1068_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF6E);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_494_fu_952_p0() {
    mul_ln1118_494_fu_952_p0 =  (sc_lv<16>) (sext_ln1116_69_cast_fu_294885_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_494_fu_952_p2() {
    mul_ln1118_494_fu_952_p2 = (!mul_ln1118_494_fu_952_p0.read().is_01() || !ap_const_lv25_A2.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_494_fu_952_p0.read()) * sc_biguint<25>(ap_const_lv25_A2);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_495_fu_1070_p0() {
    mul_ln1118_495_fu_1070_p0 =  (sc_lv<16>) (sext_ln1116_70_cast_fu_295028_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_495_fu_1070_p2() {
    mul_ln1118_495_fu_1070_p2 = (!mul_ln1118_495_fu_1070_p0.read().is_01() || !ap_const_lv26_1F1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_495_fu_1070_p0.read()) * sc_biguint<26>(ap_const_lv26_1F1);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_496_fu_1071_p0() {
    mul_ln1118_496_fu_1071_p0 =  (sc_lv<16>) (sext_ln1116_70_cast12_fu_295022_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_496_fu_1071_p2() {
    mul_ln1118_496_fu_1071_p2 = (!mul_ln1118_496_fu_1071_p0.read().is_01() || !ap_const_lv25_8A.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_496_fu_1071_p0.read()) * sc_biguint<25>(ap_const_lv25_8A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_497_fu_1134_p0() {
    mul_ln1118_497_fu_1134_p0 =  (sc_lv<16>) (sext_ln1116_70_cast_fu_295028_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_497_fu_1134_p2() {
    mul_ln1118_497_fu_1134_p2 = (!mul_ln1118_497_fu_1134_p0.read().is_01() || !ap_const_lv26_3FFFE2F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_497_fu_1134_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE2F);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_498_fu_1073_p0() {
    mul_ln1118_498_fu_1073_p0 =  (sc_lv<16>) (sext_ln1116_70_cast_fu_295028_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_498_fu_1073_p2() {
    mul_ln1118_498_fu_1073_p2 = (!mul_ln1118_498_fu_1073_p0.read().is_01() || !ap_const_lv26_1A6.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_498_fu_1073_p0.read()) * sc_biguint<26>(ap_const_lv26_1A6);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_499_fu_958_p0() {
    mul_ln1118_499_fu_958_p0 =  (sc_lv<16>) (sext_ln1116_70_cast13_fu_295016_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_499_fu_958_p2() {
    mul_ln1118_499_fu_958_p2 = (!mul_ln1118_499_fu_958_p0.read().is_01() || !ap_const_lv24_6A.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_499_fu_958_p0.read()) * sc_biguint<24>(ap_const_lv24_6A);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_500_fu_990_p0() {
    mul_ln1118_500_fu_990_p0 =  (sc_lv<16>) (sext_ln1116_70_cast12_fu_295022_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_500_fu_990_p2() {
    mul_ln1118_500_fu_990_p2 = (!mul_ln1118_500_fu_990_p0.read().is_01() || !ap_const_lv25_1FFFF18.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_500_fu_990_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF18);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_501_fu_953_p0() {
    mul_ln1118_501_fu_953_p0 =  (sc_lv<16>) (sext_ln1116_70_cast13_fu_295016_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_501_fu_953_p2() {
    mul_ln1118_501_fu_953_p2 = (!mul_ln1118_501_fu_953_p0.read().is_01() || !ap_const_lv24_FFFF8C.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_501_fu_953_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF8C);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_502_fu_916_p0() {
    mul_ln1118_502_fu_916_p0 =  (sc_lv<16>) (sext_ln1116_71_cast_fu_295188_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_502_fu_916_p2() {
    mul_ln1118_502_fu_916_p2 = (!mul_ln1118_502_fu_916_p0.read().is_01() || !ap_const_lv25_D5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_502_fu_916_p0.read()) * sc_biguint<25>(ap_const_lv25_D5);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_503_fu_1061_p0() {
    mul_ln1118_503_fu_1061_p0 = sext_ln1116_71_cast9_fu_295183_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_503_fu_1061_p2() {
    mul_ln1118_503_fu_1061_p2 = (!mul_ln1118_503_fu_1061_p0.read().is_01() || !ap_const_lv22_13.is_01())? sc_lv<22>(): sc_bigint<16>(mul_ln1118_503_fu_1061_p0.read()) * sc_biguint<22>(ap_const_lv22_13);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_504_fu_1156_p0() {
    mul_ln1118_504_fu_1156_p0 =  (sc_lv<16>) (sext_ln1116_71_cast10_fu_295176_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_504_fu_1156_p2() {
    mul_ln1118_504_fu_1156_p2 = (!mul_ln1118_504_fu_1156_p0.read().is_01() || !ap_const_lv26_28F.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_504_fu_1156_p0.read()) * sc_biguint<26>(ap_const_lv26_28F);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_505_fu_981_p0() {
    mul_ln1118_505_fu_981_p0 = sext_ln1116_71_cast11_fu_295171_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_505_fu_981_p2() {
    mul_ln1118_505_fu_981_p2 = (!mul_ln1118_505_fu_981_p0.read().is_01() || !ap_const_lv24_FFFFA3.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_505_fu_981_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA3);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_506_fu_1011_p0() {
    mul_ln1118_506_fu_1011_p0 =  (sc_lv<16>) (sext_ln1116_71_cast10_fu_295176_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_506_fu_1011_p2() {
    mul_ln1118_506_fu_1011_p2 = (!mul_ln1118_506_fu_1011_p0.read().is_01() || !ap_const_lv26_137.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_506_fu_1011_p0.read()) * sc_biguint<26>(ap_const_lv26_137);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_507_fu_957_p0() {
    mul_ln1118_507_fu_957_p0 =  (sc_lv<16>) (sext_ln1116_71_cast10_fu_295176_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_507_fu_957_p2() {
    mul_ln1118_507_fu_957_p2 = (!mul_ln1118_507_fu_957_p0.read().is_01() || !ap_const_lv26_346.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_507_fu_957_p0.read()) * sc_biguint<26>(ap_const_lv26_346);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_508_fu_896_p0() {
    mul_ln1118_508_fu_896_p0 =  (sc_lv<16>) (sext_ln1116_71_cast_fu_295188_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_508_fu_896_p2() {
    mul_ln1118_508_fu_896_p2 = (!mul_ln1118_508_fu_896_p0.read().is_01() || !ap_const_lv25_A9.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_508_fu_896_p0.read()) * sc_biguint<25>(ap_const_lv25_A9);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_509_fu_1014_p0() {
    mul_ln1118_509_fu_1014_p0 =  (sc_lv<16>) (sext_ln1116_72_cast_fu_295285_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_509_fu_1014_p2() {
    mul_ln1118_509_fu_1014_p2 = (!mul_ln1118_509_fu_1014_p0.read().is_01() || !ap_const_lv26_1DE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_509_fu_1014_p0.read()) * sc_biguint<26>(ap_const_lv26_1DE);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_510_fu_898_p0() {
    mul_ln1118_510_fu_898_p0 =  (sc_lv<16>) (sext_ln1116_72_cast_fu_295285_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_510_fu_898_p2() {
    mul_ln1118_510_fu_898_p2 = (!mul_ln1118_510_fu_898_p0.read().is_01() || !ap_const_lv26_3FFFEB1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_510_fu_898_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEB1);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_511_fu_1003_p0() {
    mul_ln1118_511_fu_1003_p0 = sext_ln1116_72_cast7_fu_295280_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_511_fu_1003_p2() {
    mul_ln1118_511_fu_1003_p2 = (!mul_ln1118_511_fu_1003_p0.read().is_01() || !ap_const_lv25_1FFFF41.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_511_fu_1003_p0.read()) * sc_bigint<25>(ap_const_lv25_1FFFF41);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_512_fu_1158_p0() {
    mul_ln1118_512_fu_1158_p0 =  (sc_lv<16>) (sext_ln1116_72_cast_fu_295285_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_512_fu_1158_p2() {
    mul_ln1118_512_fu_1158_p2 = (!mul_ln1118_512_fu_1158_p0.read().is_01() || !ap_const_lv26_185.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_512_fu_1158_p0.read()) * sc_biguint<26>(ap_const_lv26_185);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_513_fu_1052_p0() {
    mul_ln1118_513_fu_1052_p0 =  (sc_lv<16>) (sext_ln1116_72_cast_fu_295285_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_513_fu_1052_p2() {
    mul_ln1118_513_fu_1052_p2 = (!mul_ln1118_513_fu_1052_p0.read().is_01() || !ap_const_lv26_173.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_513_fu_1052_p0.read()) * sc_biguint<26>(ap_const_lv26_173);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_514_fu_946_p0() {
    mul_ln1118_514_fu_946_p0 =  (sc_lv<16>) (sext_ln1116_72_cast_fu_295285_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_514_fu_946_p2() {
    mul_ln1118_514_fu_946_p2 = (!mul_ln1118_514_fu_946_p0.read().is_01() || !ap_const_lv26_3FFFEF3.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_514_fu_946_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEF3);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_515_fu_909_p0() {
    mul_ln1118_515_fu_909_p0 =  (sc_lv<16>) (sext_ln1116_72_cast_fu_295285_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_515_fu_909_p2() {
    mul_ln1118_515_fu_909_p2 = (!mul_ln1118_515_fu_909_p0.read().is_01() || !ap_const_lv26_1E5.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_515_fu_909_p0.read()) * sc_biguint<26>(ap_const_lv26_1E5);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_516_fu_872_p0() {
    mul_ln1118_516_fu_872_p0 =  (sc_lv<16>) (sext_ln1116_73_cast_fu_295420_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_516_fu_872_p2() {
    mul_ln1118_516_fu_872_p2 = (!mul_ln1118_516_fu_872_p0.read().is_01() || !ap_const_lv26_3FFFEB2.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_516_fu_872_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFEB2);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_517_fu_1099_p0() {
    mul_ln1118_517_fu_1099_p0 =  (sc_lv<16>) (sext_ln1116_73_cast5_fu_295413_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_517_fu_1099_p2() {
    mul_ln1118_517_fu_1099_p2 = (!mul_ln1118_517_fu_1099_p0.read().is_01() || !ap_const_lv24_FFFFA2.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_517_fu_1099_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFA2);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_518_fu_926_p0() {
    mul_ln1118_518_fu_926_p0 =  (sc_lv<16>) (sext_ln1116_73_cast_fu_295420_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_518_fu_926_p2() {
    mul_ln1118_518_fu_926_p2 = (!mul_ln1118_518_fu_926_p0.read().is_01() || !ap_const_lv26_329.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_518_fu_926_p0.read()) * sc_biguint<26>(ap_const_lv26_329);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_519_fu_1009_p0() {
    mul_ln1118_519_fu_1009_p0 =  (sc_lv<16>) (sext_ln1116_73_cast_fu_295420_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_519_fu_1009_p2() {
    mul_ln1118_519_fu_1009_p2 = (!mul_ln1118_519_fu_1009_p0.read().is_01() || !ap_const_lv26_3FFFED5.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_519_fu_1009_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFED5);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_520_fu_1010_p0() {
    mul_ln1118_520_fu_1010_p0 =  (sc_lv<16>) (sext_ln1116_73_cast5_fu_295413_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_520_fu_1010_p2() {
    mul_ln1118_520_fu_1010_p2 = (!mul_ln1118_520_fu_1010_p0.read().is_01() || !ap_const_lv24_69.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_520_fu_1010_p0.read()) * sc_biguint<24>(ap_const_lv24_69);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_521_fu_956_p0() {
    mul_ln1118_521_fu_956_p0 =  (sc_lv<16>) (sext_ln1116_73_cast5_fu_295413_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_521_fu_956_p2() {
    mul_ln1118_521_fu_956_p2 = (!mul_ln1118_521_fu_956_p0.read().is_01() || !ap_const_lv24_52.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_521_fu_956_p0.read()) * sc_biguint<24>(ap_const_lv24_52);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_522_fu_1012_p0() {
    mul_ln1118_522_fu_1012_p0 =  (sc_lv<16>) (sext_ln1116_73_cast_fu_295420_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_522_fu_1012_p2() {
    mul_ln1118_522_fu_1012_p2 = (!mul_ln1118_522_fu_1012_p0.read().is_01() || !ap_const_lv26_1D1.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_522_fu_1012_p0.read()) * sc_biguint<26>(ap_const_lv26_1D1);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_523_fu_1013_p0() {
    mul_ln1118_523_fu_1013_p0 =  (sc_lv<16>) (sext_ln1116_74_cast_fu_295569_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_523_fu_1013_p2() {
    mul_ln1118_523_fu_1013_p2 = (!mul_ln1118_523_fu_1013_p0.read().is_01() || !ap_const_lv26_511.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_523_fu_1013_p0.read()) * sc_biguint<26>(ap_const_lv26_511);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_524_fu_1050_p0() {
    mul_ln1118_524_fu_1050_p0 =  (sc_lv<16>) (sext_ln1116_74_cast_fu_295569_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_524_fu_1050_p2() {
    mul_ln1118_524_fu_1050_p2 = (!mul_ln1118_524_fu_1050_p0.read().is_01() || !ap_const_lv26_3FFFE98.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_524_fu_1050_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE98);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_525_fu_1082_p0() {
    mul_ln1118_525_fu_1082_p0 =  (sc_lv<16>) (sext_ln1116_74_cast_fu_295569_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_525_fu_1082_p2() {
    mul_ln1118_525_fu_1082_p2 = (!mul_ln1118_525_fu_1082_p0.read().is_01() || !ap_const_lv26_3FFFDC2.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_525_fu_1082_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDC2);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_526_fu_882_p0() {
    mul_ln1118_526_fu_882_p0 = sext_ln1116_74_cast3_fu_295564_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_526_fu_882_p2() {
    mul_ln1118_526_fu_882_p2 = (!mul_ln1118_526_fu_882_p0.read().is_01() || !ap_const_lv23_7FFFD3.is_01())? sc_lv<23>(): sc_bigint<16>(mul_ln1118_526_fu_882_p0.read()) * sc_bigint<23>(ap_const_lv23_7FFFD3);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_527_fu_939_p0() {
    mul_ln1118_527_fu_939_p0 =  (sc_lv<16>) (sext_ln1116_74_cast_fu_295569_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_527_fu_939_p2() {
    mul_ln1118_527_fu_939_p2 = (!mul_ln1118_527_fu_939_p0.read().is_01() || !ap_const_lv26_3FFFE94.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_527_fu_939_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE94);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_528_fu_1084_p0() {
    mul_ln1118_528_fu_1084_p0 =  (sc_lv<16>) (sext_ln1116_74_cast_fu_295569_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_528_fu_1084_p2() {
    mul_ln1118_528_fu_1084_p2 = (!mul_ln1118_528_fu_1084_p0.read().is_01() || !ap_const_lv26_3FFFE37.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_528_fu_1084_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE37);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_529_fu_1041_p0() {
    mul_ln1118_529_fu_1041_p0 =  (sc_lv<16>) (sext_ln1116_74_cast_fu_295569_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_529_fu_1041_p2() {
    mul_ln1118_529_fu_1041_p2 = (!mul_ln1118_529_fu_1041_p0.read().is_01() || !ap_const_lv26_3FFFDB7.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_529_fu_1041_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFDB7);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_530_fu_1122_p0() {
    mul_ln1118_530_fu_1122_p0 = sext_ln1116_75_cast_fu_295698_p0.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_530_fu_1122_p2() {
    mul_ln1118_530_fu_1122_p2 = (!mul_ln1118_530_fu_1122_p0.read().is_01() || !ap_const_lv24_FFFFB5.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_530_fu_1122_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFFB5);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_531_fu_1123_p0() {
    mul_ln1118_531_fu_1123_p0 =  (sc_lv<16>) (sext_ln1116_75_cast1_fu_295692_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_531_fu_1123_p2() {
    mul_ln1118_531_fu_1123_p2 = (!mul_ln1118_531_fu_1123_p0.read().is_01() || !ap_const_lv25_E5.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_531_fu_1123_p0.read()) * sc_biguint<25>(ap_const_lv25_E5);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_532_fu_1124_p0() {
    mul_ln1118_532_fu_1124_p0 =  (sc_lv<16>) (sext_ln1116_75_cast1_fu_295692_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_532_fu_1124_p2() {
    mul_ln1118_532_fu_1124_p2 = (!mul_ln1118_532_fu_1124_p0.read().is_01() || !ap_const_lv25_CE.is_01())? sc_lv<25>(): sc_bigint<16>(mul_ln1118_532_fu_1124_p0.read()) * sc_biguint<25>(ap_const_lv25_CE);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_533_fu_905_p0() {
    mul_ln1118_533_fu_905_p0 =  (sc_lv<16>) (sext_ln1116_75_cast2_fu_295685_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_533_fu_905_p2() {
    mul_ln1118_533_fu_905_p2 = (!mul_ln1118_533_fu_905_p0.read().is_01() || !ap_const_lv26_1CE.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_533_fu_905_p0.read()) * sc_biguint<26>(ap_const_lv26_1CE);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_534_fu_1126_p0() {
    mul_ln1118_534_fu_1126_p0 =  (sc_lv<16>) (sext_ln1116_75_cast2_fu_295685_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_534_fu_1126_p2() {
    mul_ln1118_534_fu_1126_p2 = (!mul_ln1118_534_fu_1126_p0.read().is_01() || !ap_const_lv26_182.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_534_fu_1126_p0.read()) * sc_biguint<26>(ap_const_lv26_182);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_535_fu_1127_p0() {
    mul_ln1118_535_fu_1127_p0 =  (sc_lv<16>) (sext_ln1116_75_cast2_fu_295685_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_535_fu_1127_p2() {
    mul_ln1118_535_fu_1127_p2 = (!mul_ln1118_535_fu_1127_p0.read().is_01() || !ap_const_lv26_3FFFE65.is_01())? sc_lv<26>(): sc_bigint<16>(mul_ln1118_535_fu_1127_p0.read()) * sc_bigint<26>(ap_const_lv26_3FFFE65);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_fu_1150_p0() {
    mul_ln1118_fu_1150_p0 =  (sc_lv<16>) (sext_ln1116_cast94_fu_290928_p1.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mul_ln1118_fu_1150_p2() {
    mul_ln1118_fu_1150_p2 = (!mul_ln1118_fu_1150_p0.read().is_01() || !ap_const_lv24_FFFF96.is_01())? sc_lv<24>(): sc_bigint<16>(mul_ln1118_fu_1150_p0.read()) * sc_bigint<24>(ap_const_lv24_FFFF96);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_100_V_fu_292743_p1() {
    mult_100_V_fu_292743_p1 = esl_sext<16,14>(trunc_ln708_250_fu_292733_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_103_V_fu_292775_p4() {
    mult_103_V_fu_292775_p4 = mul_ln1118_371_fu_1087_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_104_V_fu_292800_p4() {
    mult_104_V_fu_292800_p4 = mul_ln1118_372_fu_1152_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_105_V_fu_292810_p4() {
    mult_105_V_fu_292810_p4 = mul_ln1118_373_fu_912_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_106_V_fu_292820_p4() {
    mult_106_V_fu_292820_p4 = mul_ln1118_374_fu_913_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_107_V_fu_292866_p4() {
    mult_107_V_fu_292866_p4 = sub_ln1118_59_fu_292860_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_108_V_fu_292876_p4() {
    mult_108_V_fu_292876_p4 = mul_ln1118_375_fu_929_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_109_V_fu_292896_p1() {
    mult_109_V_fu_292896_p1 = esl_sext<16,15>(trunc_ln708_253_fu_292886_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_10_V_fu_291115_p4() {
    mult_10_V_fu_291115_p4 = mul_ln1118_294_fu_950_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_110_V_fu_292900_p4() {
    mult_110_V_fu_292900_p4 = mul_ln1118_377_fu_933_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_111_V_fu_292920_p1() {
    mult_111_V_fu_292920_p1 = esl_sext<16,15>(trunc_ln708_254_fu_292910_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_113_V_fu_292958_p4() {
    mult_113_V_fu_292958_p4 = mul_ln1118_380_fu_1098_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_114_V_fu_292968_p4() {
    mult_114_V_fu_292968_p4 = mul_ln1118_381_fu_1155_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_116_V_fu_293002_p1() {
    mult_116_V_fu_293002_p1 = esl_sext<16,15>(trunc_ln708_257_fu_292992_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_118_V_fu_293020_p4() {
    mult_118_V_fu_293020_p4 = mul_ln1118_385_fu_971_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_119_V_fu_293040_p1() {
    mult_119_V_fu_293040_p1 = esl_sext<16,15>(trunc_ln708_259_fu_293030_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_11_V_fu_291125_p4() {
    mult_11_V_fu_291125_p4 = mul_ln1118_295_fu_1090_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_120_V_fu_293072_p1() {
    mult_120_V_fu_293072_p1 = esl_sext<16,14>(trunc_ln708_260_fu_293062_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_125_V_fu_293148_p4() {
    mult_125_V_fu_293148_p4 = mul_ln1118_390_fu_1045_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_126_V_fu_293158_p4() {
    mult_126_V_fu_293158_p4 = mul_ln1118_391_fu_889_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_127_V_fu_293168_p4() {
    mult_127_V_fu_293168_p4 = mul_ln1118_392_fu_877_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_128_V_fu_293207_p1() {
    mult_128_V_fu_293207_p1 = esl_sext<16,15>(trunc_ln708_263_fu_293197_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_129_V_fu_293211_p4() {
    mult_129_V_fu_293211_p4 = mul_ln1118_394_fu_941_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_130_V_fu_293231_p1() {
    mult_130_V_fu_293231_p1 = esl_sext<16,15>(trunc_ln708_264_fu_293221_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_131_V_fu_293245_p1() {
    mult_131_V_fu_293245_p1 = esl_sext<16,15>(trunc_ln708_265_fu_293235_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_133_V_fu_293263_p4() {
    mult_133_V_fu_293263_p4 = mul_ln1118_398_fu_1141_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_134_V_fu_293301_p1() {
    mult_134_V_fu_293301_p1 = esl_sext<16,15>(trunc_ln708_267_fu_293291_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_135_V_fu_293305_p4() {
    mult_135_V_fu_293305_p4 = mul_ln1118_399_fu_1025_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_137_V_fu_293352_p4() {
    mult_137_V_fu_293352_p4 = mul_ln1118_401_fu_1112_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_138_V_fu_293372_p1() {
    mult_138_V_fu_293372_p1 = esl_sext<16,15>(trunc_ln708_269_fu_293362_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_139_V_fu_293376_p4() {
    mult_139_V_fu_293376_p4 = mul_ln1118_403_fu_1038_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_140_V_fu_293386_p4() {
    mult_140_V_fu_293386_p4 = mul_ln1118_404_fu_976_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_141_V_fu_293436_p1() {
    mult_141_V_fu_293436_p1 = esl_sext<16,15>(trunc_ln708_270_fu_293426_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_142_V_fu_293440_p4() {
    mult_142_V_fu_293440_p4 = mul_ln1118_405_fu_1033_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_143_V_fu_293460_p1() {
    mult_143_V_fu_293460_p1 = esl_sext<16,14>(trunc_ln708_271_fu_293450_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_144_V_fu_293480_p4() {
    mult_144_V_fu_293480_p4 = mul_ln1118_407_fu_1080_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_145_V_fu_293490_p4() {
    mult_145_V_fu_293490_p4 = mul_ln1118_408_fu_1019_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_146_V_fu_293500_p4() {
    mult_146_V_fu_293500_p4 = mul_ln1118_409_fu_910_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_147_V_fu_293520_p1() {
    mult_147_V_fu_293520_p1 = esl_sext<16,15>(trunc_ln708_272_fu_293510_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_148_V_fu_293534_p1() {
    mult_148_V_fu_293534_p1 = esl_sext<16,15>(trunc_ln708_273_fu_293524_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_149_V_fu_293538_p4() {
    mult_149_V_fu_293538_p4 = mul_ln1118_412_fu_1140_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_14_V_fu_291209_p1() {
    mult_14_V_fu_291209_p1 = esl_sext<16,15>(trunc_ln708_189_fu_291199_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_150_V_fu_293548_p4() {
    mult_150_V_fu_293548_p4 = mul_ln1118_413_fu_1117_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_151_V_fu_293558_p4() {
    mult_151_V_fu_293558_p4 = mul_ln1118_414_fu_943_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_152_V_fu_293583_p4() {
    mult_152_V_fu_293583_p4 = mul_ln1118_415_fu_955_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_153_V_fu_293603_p1() {
    mult_153_V_fu_293603_p1 = esl_sext<16,15>(trunc_ln708_274_fu_293593_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_154_V_fu_293607_p4() {
    mult_154_V_fu_293607_p4 = mul_ln1118_417_fu_1101_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_155_V_fu_293627_p1() {
    mult_155_V_fu_293627_p1 = esl_sext<16,15>(trunc_ln708_275_fu_293617_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_156_V_fu_293631_p4() {
    mult_156_V_fu_293631_p4 = mul_ln1118_419_fu_1077_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_158_V_fu_293641_p4() {
    mult_158_V_fu_293641_p4 = mul_ln1118_420_fu_1023_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_159_V_fu_293651_p4() {
    mult_159_V_fu_293651_p4 = mul_ln1118_421_fu_962_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_15_V_fu_291213_p4() {
    mult_15_V_fu_291213_p4 = mul_ln1118_298_fu_921_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_160_V_fu_293691_p1() {
    mult_160_V_fu_293691_p1 = esl_sext<16,15>(trunc_ln708_276_fu_293681_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_161_V_fu_293695_p4() {
    mult_161_V_fu_293695_p4 = mul_ln1118_423_fu_964_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_162_V_fu_293705_p4() {
    mult_162_V_fu_293705_p4 = mul_ln1118_424_fu_965_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_164_V_fu_293739_p1() {
    mult_164_V_fu_293739_p1 = esl_sext<16,15>(trunc_ln708_278_fu_293729_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_165_V_fu_293743_p4() {
    mult_165_V_fu_293743_p4 = mul_ln1118_427_fu_1004_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_166_V_fu_293753_p4() {
    mult_166_V_fu_293753_p4 = mul_ln1118_428_fu_879_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_167_V_fu_293773_p1() {
    mult_167_V_fu_293773_p1 = esl_sext<16,15>(trunc_ln708_279_fu_293763_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_168_V_fu_293792_p4() {
    mult_168_V_fu_293792_p4 = mul_ln1118_430_fu_918_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_170_V_fu_293816_p4() {
    mult_170_V_fu_293816_p4 = mul_ln1118_432_fu_1020_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_171_V_fu_293826_p4() {
    mult_171_V_fu_293826_p4 = mul_ln1118_433_fu_1076_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_172_V_fu_293836_p4() {
    mult_172_V_fu_293836_p4 = mul_ln1118_434_fu_922_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_173_V_fu_293846_p4() {
    mult_173_V_fu_293846_p4 = mul_ln1118_435_fu_1078_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_174_V_fu_293856_p4() {
    mult_174_V_fu_293856_p4 = mul_ln1118_436_fu_1079_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_176_V_fu_293936_p4() {
    mult_176_V_fu_293936_p4 = mul_ln1118_437_fu_1053_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_177_V_fu_293946_p4() {
    mult_177_V_fu_293946_p4 = mul_ln1118_438_fu_914_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_178_V_fu_293956_p4() {
    mult_178_V_fu_293956_p4 = mul_ln1118_439_fu_949_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_179_V_fu_293976_p1() {
    mult_179_V_fu_293976_p1 = esl_sext<16,15>(trunc_ln708_281_fu_293966_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_17_V_fu_291269_p1() {
    mult_17_V_fu_291269_p1 = esl_sext<16,15>(trunc_ln708_191_fu_291259_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_180_V_fu_293980_p4() {
    mult_180_V_fu_293980_p4 = mul_ln1118_441_fu_985_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_181_V_fu_293990_p4() {
    mult_181_V_fu_293990_p4 = mul_ln1118_442_fu_904_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_182_V_fu_294000_p4() {
    mult_182_V_fu_294000_p4 = mul_ln1118_443_fu_980_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_185_V_fu_294072_p1() {
    mult_185_V_fu_294072_p1 = esl_sext<16,15>(trunc_ln708_284_fu_294062_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_186_V_fu_294086_p1() {
    mult_186_V_fu_294086_p1 = esl_sext<16,15>(trunc_ln708_285_fu_294076_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_187_V_fu_294100_p1() {
    mult_187_V_fu_294100_p1 = esl_sext<16,15>(trunc_ln708_286_fu_294090_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_188_V_fu_294104_p4() {
    mult_188_V_fu_294104_p4 = mul_ln1118_449_fu_1022_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_191_V_fu_294142_p4() {
    mult_191_V_fu_294142_p4 = mul_ln1118_452_fu_1121_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_195_V_fu_294230_p4() {
    mult_195_V_fu_294230_p4 = mul_ln1118_455_fu_885_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_197_V_fu_294282_p1() {
    mult_197_V_fu_294282_p1 = esl_sext<16,15>(trunc_ln708_293_fu_294272_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_198_V_fu_294286_p4() {
    mult_198_V_fu_294286_p4 = mul_ln1118_457_fu_1132_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_19_V_fu_291305_p4() {
    mult_19_V_fu_291305_p4 = mul_ln1118_302_fu_973_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_1_V_fu_290988_p1() {
    mult_1_V_fu_290988_p1 = esl_sext<16,14>(trunc_ln708_s_fu_290978_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_200_V_fu_294344_p1() {
    mult_200_V_fu_294344_p1 = esl_sext<16,15>(trunc_ln708_295_fu_294334_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_203_V_fu_294386_p1() {
    mult_203_V_fu_294386_p1 = esl_sext<16,15>(trunc_ln708_298_fu_294376_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_204_V_fu_294390_p4() {
    mult_204_V_fu_294390_p4 = mul_ln1118_463_fu_937_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_206_V_fu_294414_p4() {
    mult_206_V_fu_294414_p4 = mul_ln1118_465_fu_951_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_207_V_fu_294434_p1() {
    mult_207_V_fu_294434_p1 = esl_sext<16,15>(trunc_ln708_300_fu_294424_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_20_V_fu_291315_p4() {
    mult_20_V_fu_291315_p4 = mul_ln1118_303_fu_1103_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_211_V_fu_294550_p4() {
    mult_211_V_fu_294550_p4 = mul_ln1118_468_fu_934_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_212_V_fu_294560_p4() {
    mult_212_V_fu_294560_p4 = mul_ln1118_469_fu_1129_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_213_V_fu_294570_p4() {
    mult_213_V_fu_294570_p4 = mul_ln1118_470_fu_1130_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_215_V_fu_294604_p1() {
    mult_215_V_fu_294604_p1 = esl_sext<16,15>(trunc_ln708_304_fu_294594_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_217_V_fu_294651_p1() {
    mult_217_V_fu_294651_p1 = esl_sext<16,14>(trunc_ln708_306_fu_294641_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_220_V_fu_294701_p4() {
    mult_220_V_fu_294701_p4 = mul_ln1118_476_fu_974_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_221_V_fu_294721_p1() {
    mult_221_V_fu_294721_p1 = esl_sext<16,15>(trunc_ln708_309_fu_294711_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_223_V_fu_294749_p1() {
    mult_223_V_fu_294749_p1 = esl_sext<16,15>(trunc_ln708_311_fu_294739_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_224_V_fu_294773_p4() {
    mult_224_V_fu_294773_p4 = mul_ln1118_480_fu_983_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_226_V_fu_294807_p1() {
    mult_226_V_fu_294807_p1 = esl_sext<16,15>(trunc_ln708_313_fu_294797_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_227_V_fu_294811_p4() {
    mult_227_V_fu_294811_p4 = mul_ln1118_483_fu_1128_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_228_V_fu_294821_p4() {
    mult_228_V_fu_294821_p4 = mul_ln1118_484_fu_1074_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_231_V_fu_294859_p4() {
    mult_231_V_fu_294859_p4 = mul_ln1118_487_fu_1060_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_232_V_fu_294902_p1() {
    mult_232_V_fu_294902_p1 = esl_sext<16,15>(trunc_ln708_316_fu_294892_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_233_V_fu_294906_p4() {
    mult_233_V_fu_294906_p4 = mul_ln1118_489_fu_992_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_234_V_fu_294916_p4() {
    mult_234_V_fu_294916_p4 = mul_ln1118_490_fu_886_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_236_V_fu_294940_p4() {
    mult_236_V_fu_294940_p4 = mul_ln1118_492_fu_1063_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_238_V_fu_294998_p1() {
    mult_238_V_fu_294998_p1 = esl_sext<16,15>(trunc_ln708_318_fu_294988_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_239_V_fu_295012_p1() {
    mult_239_V_fu_295012_p1 = esl_sext<16,15>(trunc_ln708_319_fu_295002_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_23_V_fu_291353_p4() {
    mult_23_V_fu_291353_p4 = mul_ln1118_305_fu_1054_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_240_V_fu_295035_p4() {
    mult_240_V_fu_295035_p4 = mul_ln1118_495_fu_1070_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_241_V_fu_295055_p1() {
    mult_241_V_fu_295055_p1 = esl_sext<16,15>(trunc_ln708_320_fu_295045_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_242_V_fu_295059_p4() {
    mult_242_V_fu_295059_p4 = mul_ln1118_497_fu_1134_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_243_V_fu_295069_p4() {
    mult_243_V_fu_295069_p4 = mul_ln1118_498_fu_1073_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_245_V_fu_295103_p1() {
    mult_245_V_fu_295103_p1 = esl_sext<16,15>(trunc_ln708_322_fu_295093_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_246_V_fu_295153_p1() {
    mult_246_V_fu_295153_p1 = esl_sext<16,15>(trunc_ln708_323_fu_295143_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_248_V_fu_295204_p1() {
    mult_248_V_fu_295204_p1 = esl_sext<16,15>(trunc_ln708_325_fu_295194_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_250_V_fu_295222_p4() {
    mult_250_V_fu_295222_p4 = mul_ln1118_504_fu_1156_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_253_V_fu_295246_p4() {
    mult_253_V_fu_295246_p4 = mul_ln1118_506_fu_1011_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_254_V_fu_295256_p4() {
    mult_254_V_fu_295256_p4 = mul_ln1118_507_fu_957_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_255_V_fu_295276_p1() {
    mult_255_V_fu_295276_p1 = esl_sext<16,15>(trunc_ln708_328_fu_295266_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_256_V_fu_295295_p4() {
    mult_256_V_fu_295295_p4 = mul_ln1118_509_fu_1014_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_257_V_fu_295305_p4() {
    mult_257_V_fu_295305_p4 = mul_ln1118_510_fu_898_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_258_V_fu_295325_p1() {
    mult_258_V_fu_295325_p1 = esl_sext<16,15>(trunc_ln708_329_fu_295315_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_259_V_fu_295329_p4() {
    mult_259_V_fu_295329_p4 = mul_ln1118_512_fu_1158_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_261_V_fu_295383_p4() {
    mult_261_V_fu_295383_p4 = mul_ln1118_513_fu_1052_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_262_V_fu_295393_p4() {
    mult_262_V_fu_295393_p4 = mul_ln1118_514_fu_946_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_263_V_fu_295403_p4() {
    mult_263_V_fu_295403_p4 = mul_ln1118_515_fu_909_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_264_V_fu_295428_p4() {
    mult_264_V_fu_295428_p4 = mul_ln1118_516_fu_872_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_266_V_fu_295452_p4() {
    mult_266_V_fu_295452_p4 = mul_ln1118_518_fu_926_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_267_V_fu_295462_p4() {
    mult_267_V_fu_295462_p4 = mul_ln1118_519_fu_1009_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_26_V_fu_291425_p1() {
    mult_26_V_fu_291425_p1 = esl_sext<16,15>(trunc_ln708_197_fu_291415_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_27_V_fu_291429_p4() {
    mult_27_V_fu_291429_p4 = mul_ln1118_309_fu_1088_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_28_V_fu_291439_p4() {
    mult_28_V_fu_291439_p4 = mul_ln1118_310_fu_1089_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_29_V_fu_291449_p4() {
    mult_29_V_fu_291449_p4 = mul_ln1118_311_fu_915_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_31_V_fu_291473_p4() {
    mult_31_V_fu_291473_p4 = mul_ln1118_313_fu_1092_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_32_V_fu_291502_p4() {
    mult_32_V_fu_291502_p4 = mul_ln1118_314_fu_1120_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_33_V_fu_291512_p4() {
    mult_33_V_fu_291512_p4 = mul_ln1118_315_fu_1114_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_34_V_fu_291522_p4() {
    mult_34_V_fu_291522_p4 = mul_ln1118_316_fu_1096_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_36_V_fu_291586_p1() {
    mult_36_V_fu_291586_p1 = esl_sext<16,15>(trunc_ln708_200_fu_291576_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_38_V_fu_291614_p1() {
    mult_38_V_fu_291614_p1 = esl_sext<16,15>(trunc_ln708_202_fu_291604_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_39_V_fu_291618_p4() {
    mult_39_V_fu_291618_p4 = mul_ln1118_320_fu_1111_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_3_V_fu_291006_p4() {
    mult_3_V_fu_291006_p4 = mul_ln1118_287_fu_1035_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_40_V_fu_291660_p1() {
    mult_40_V_fu_291660_p1 = esl_sext<16,15>(trunc_ln708_203_fu_291650_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_41_V_fu_291664_p4() {
    mult_41_V_fu_291664_p4 = mul_ln1118_322_fu_1031_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_42_V_fu_291674_p4() {
    mult_42_V_fu_291674_p4 = mul_ln1118_323_fu_1032_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_45_V_fu_291752_p4() {
    mult_45_V_fu_291752_p4 = mul_ln1118_324_fu_923_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_49_V_fu_291838_p1() {
    mult_49_V_fu_291838_p1 = esl_sext<16,15>(trunc_ln708_209_fu_291828_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_4_V_fu_291026_p1() {
    mult_4_V_fu_291026_p1 = esl_sext<16,15>(trunc_ln708_185_fu_291016_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_51_V_fu_291856_p4() {
    mult_51_V_fu_291856_p4 = mul_ln1118_330_fu_895_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_52_V_fu_291876_p1() {
    mult_52_V_fu_291876_p1 = esl_sext<16,15>(trunc_ln708_211_fu_291866_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_53_V_fu_291880_p4() {
    mult_53_V_fu_291880_p4 = mul_ln1118_332_fu_890_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_54_V_fu_291890_p4() {
    mult_54_V_fu_291890_p4 = mul_ln1118_333_fu_966_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_55_V_fu_291910_p1() {
    mult_55_V_fu_291910_p1 = esl_sext<16,15>(trunc_ln708_212_fu_291900_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_56_V_fu_291982_p1() {
    mult_56_V_fu_291982_p1 = esl_sext<16,14>(trunc_ln708_213_fu_291972_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_59_V_fu_292014_p4() {
    mult_59_V_fu_292014_p4 = mul_ln1118_337_fu_873_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_5_V_fu_291030_p4() {
    mult_5_V_fu_291030_p4 = mul_ln1118_289_fu_1110_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_60_V_fu_292034_p1() {
    mult_60_V_fu_292034_p1 = esl_sext<16,15>(trunc_ln708_216_fu_292024_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_61_V_fu_292066_p1() {
    mult_61_V_fu_292066_p1 = esl_sext<16,14>(trunc_ln708_217_fu_292056_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_62_V_fu_292080_p1() {
    mult_62_V_fu_292080_p1 = esl_sext<16,15>(trunc_ln708_218_fu_292070_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_63_V_fu_292094_p1() {
    mult_63_V_fu_292094_p1 = esl_sext<16,15>(trunc_ln708_223_fu_292084_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_64_V_fu_292124_p4() {
    mult_64_V_fu_292124_p4 = mul_ln1118_341_fu_1100_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_66_V_fu_292164_p1() {
    mult_66_V_fu_292164_p1 = esl_sext<16,15>(trunc_ln708_228_fu_292154_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_68_V_fu_292182_p4() {
    mult_68_V_fu_292182_p4 = mul_ln1118_344_fu_989_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_69_V_fu_292192_p4() {
    mult_69_V_fu_292192_p4 = mul_ln1118_345_fu_883_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_6_V_fu_291050_p1() {
    mult_6_V_fu_291050_p1 = esl_sext<16,15>(trunc_ln708_186_fu_291040_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_72_V_fu_292236_p4() {
    mult_72_V_fu_292236_p4 = mul_ln1118_347_fu_1143_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_73_V_fu_292256_p1() {
    mult_73_V_fu_292256_p1 = esl_sext<16,15>(trunc_ln708_231_fu_292246_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_74_V_fu_292270_p1() {
    mult_74_V_fu_292270_p1 = esl_sext<16,15>(trunc_ln708_235_fu_292260_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_75_V_fu_292274_p4() {
    mult_75_V_fu_292274_p4 = mul_ln1118_350_fu_977_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_77_V_fu_292298_p4() {
    mult_77_V_fu_292298_p4 = mul_ln1118_352_fu_1029_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_78_V_fu_292308_p4() {
    mult_78_V_fu_292308_p4 = mul_ln1118_353_fu_1055_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_79_V_fu_292318_p4() {
    mult_79_V_fu_292318_p4 = mul_ln1118_354_fu_1024_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_82_V_fu_292405_p1() {
    mult_82_V_fu_292405_p1 = esl_sext<16,15>(trunc_ln708_239_fu_292395_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_83_V_fu_292419_p1() {
    mult_83_V_fu_292419_p1 = esl_sext<16,15>(trunc_ln708_240_fu_292409_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_85_V_fu_292437_p4() {
    mult_85_V_fu_292437_p4 = mul_ln1118_358_fu_967_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_86_V_fu_292447_p4() {
    mult_86_V_fu_292447_p4 = mul_ln1118_359_fu_968_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_8_V_fu_291101_p1() {
    mult_8_V_fu_291101_p1 = esl_sext<16,14>(trunc_ln708_187_fu_291091_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_90_V_fu_292533_p4() {
    mult_90_V_fu_292533_p4 = mul_ln1118_360_fu_1148_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_91_V_fu_292573_p4() {
    mult_91_V_fu_292573_p4 = sub_ln1118_56_fu_292567_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_92_V_fu_292583_p4() {
    mult_92_V_fu_292583_p4 = mul_ln1118_361_fu_970_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_95_V_fu_292651_p4() {
    mult_95_V_fu_292651_p4 = mul_ln1118_363_fu_972_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_96_V_fu_292681_p4() {
    mult_96_V_fu_292681_p4 = mul_ln1118_364_fu_1059_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_97_V_fu_292701_p1() {
    mult_97_V_fu_292701_p1 = esl_sext<16,15>(trunc_ln708_247_fu_292691_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_98_V_fu_292715_p1() {
    mult_98_V_fu_292715_p1 = esl_sext<16,15>(trunc_ln708_248_fu_292705_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_mult_9_V_fu_291105_p4() {
    mult_9_V_fu_291105_p4 = mul_ln1118_293_fu_1056_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_41_cast90_fu_291078_p0() {
    sext_ln1116_41_cast90_fu_291078_p0 = data_1_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_41_cast90_fu_291078_p1() {
    sext_ln1116_41_cast90_fu_291078_p1 = esl_sext<26,16>(sext_ln1116_41_cast90_fu_291078_p0.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_41_cast91_fu_291073_p0() {
    sext_ln1116_41_cast91_fu_291073_p0 = data_1_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_41_cast93_fu_291068_p0() {
    sext_ln1116_41_cast93_fu_291068_p0 = data_1_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_41_cast_fu_291086_p0() {
    sext_ln1116_41_cast_fu_291086_p0 = data_1_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_42_cast87_fu_291234_p0() {
    sext_ln1116_42_cast87_fu_291234_p0 = data_2_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_42_cast88_fu_291230_p0() {
    sext_ln1116_42_cast88_fu_291230_p0 = data_2_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_42_cast88_fu_291230_p1() {
    sext_ln1116_42_cast88_fu_291230_p1 = esl_sext<19,16>(sext_ln1116_42_cast88_fu_291230_p0.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_42_cast89_fu_291223_p0() {
    sext_ln1116_42_cast89_fu_291223_p0 = data_2_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_42_cast89_fu_291223_p1() {
    sext_ln1116_42_cast89_fu_291223_p1 = esl_sext<26,16>(sext_ln1116_42_cast89_fu_291223_p0.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_42_cast_fu_291239_p0() {
    sext_ln1116_42_cast_fu_291239_p0 = data_2_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_42_cast_fu_291239_p1() {
    sext_ln1116_42_cast_fu_291239_p1 = esl_sext<24,16>(sext_ln1116_42_cast_fu_291239_p0.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_43_cast83_fu_291376_p0() {
    sext_ln1116_43_cast83_fu_291376_p0 = data_3_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_43_cast83_fu_291376_p1() {
    sext_ln1116_43_cast83_fu_291376_p1 = esl_sext<23,16>(sext_ln1116_43_cast83_fu_291376_p0.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln1116_43_cast84_fu_291371_p0() {
    sext_ln1116_43_cast84_fu_291371_p0 = data_3_V_read.read();
}

}

