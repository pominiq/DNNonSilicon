//Numpy array shape [10]
//Min -0.486083984375
//Max 0.750000000000
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
model_default_t b9[10];
#else
model_default_t b9[10] = {-0.1193237305, 0.7500000000, 0.1201782227, -0.1113281250, -0.2059326172, 0.2580566406, 0.0872192383, 0.0078659058, -0.4860839844, -0.0440368652};
#endif

#endif
