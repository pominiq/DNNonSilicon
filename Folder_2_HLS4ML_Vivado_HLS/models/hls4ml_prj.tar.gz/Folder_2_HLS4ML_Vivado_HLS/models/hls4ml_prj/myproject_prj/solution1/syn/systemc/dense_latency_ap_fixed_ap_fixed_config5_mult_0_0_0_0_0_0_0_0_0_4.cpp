#include "dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_181_fu_7110_p4() {
    trunc_ln708_181_fu_7110_p4 = sub_ln1118_45_fu_7104_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_192_fu_5429_p4() {
    trunc_ln708_192_fu_5429_p4 = sub_ln1118_50_fu_5423_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_197_fu_5632_p4() {
    trunc_ln708_197_fu_5632_p4 = sub_ln1118_53_fu_5626_p2.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_199_fu_5676_p4() {
    trunc_ln708_199_fu_5676_p4 = sub_ln1118_54_fu_5670_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_206_fu_5878_p4() {
    trunc_ln708_206_fu_5878_p4 = sub_ln1118_55_fu_5872_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_207_fu_5913_p4() {
    trunc_ln708_207_fu_5913_p4 = sub_ln1118_56_fu_5907_p2.read().range(19, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_208_fu_6114_p4() {
    trunc_ln708_208_fu_6114_p4 = sub_ln1118_62_fu_6108_p2.read().range(19, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_229_fu_6608_p4() {
    trunc_ln708_229_fu_6608_p4 = add_ln1118_9_fu_6602_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_237_fu_6254_p4() {
    trunc_ln708_237_fu_6254_p4 = sub_ln1118_59_fu_6248_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_238_fu_6286_p4() {
    trunc_ln708_238_fu_6286_p4 = sub_ln1118_60_fu_6280_p2.read().range(18, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_95_fu_3556_p1() {
    trunc_ln708_95_fu_3556_p1 =  (sc_lv<22>) (grp_fu_871_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_s_fu_5075_p4() {
    trunc_ln708_s_fu_5075_p4 = sub_ln1118_fu_5069_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_zext_ln703_fu_6341_p1() {
    zext_ln703_fu_6341_p1 = esl_zext<13,11>(add_ln703_565_fu_6335_p2.read());
}

}

