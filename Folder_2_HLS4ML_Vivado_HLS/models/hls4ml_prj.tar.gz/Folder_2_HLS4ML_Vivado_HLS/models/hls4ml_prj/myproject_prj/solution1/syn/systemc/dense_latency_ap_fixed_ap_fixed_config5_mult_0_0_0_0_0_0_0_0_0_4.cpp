#include "dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_74_fu_12188_p1() {
    sext_ln703_74_fu_12188_p1 = esl_sext<16,13>(add_ln703_351_reg_13807.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_75_fu_12243_p1() {
    sext_ln703_75_fu_12243_p1 = esl_sext<16,15>(add_ln703_373_reg_13088.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_76_fu_12252_p1() {
    sext_ln703_76_fu_12252_p1 = esl_sext<16,15>(add_ln703_375_reg_13257.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_77_fu_9805_p1() {
    sext_ln703_77_fu_9805_p1 = esl_sext<16,15>(add_ln703_376_fu_9799_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_78_fu_11698_p1() {
    sext_ln703_78_fu_11698_p1 = esl_sext<15,14>(add_ln703_380_reg_13726.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_79_fu_11707_p1() {
    sext_ln703_79_fu_11707_p1 = esl_sext<15,14>(add_ln703_381_fu_11701_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_80_fu_12266_p1() {
    sext_ln703_80_fu_12266_p1 = esl_sext<16,15>(add_ln703_382_reg_13909.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_81_fu_12269_p1() {
    sext_ln703_81_fu_12269_p1 = esl_sext<14,13>(add_ln703_383_reg_13731.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_82_fu_12272_p1() {
    sext_ln703_82_fu_12272_p1 = esl_sext<13,12>(add_ln703_384_reg_13817.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_83_fu_12281_p1() {
    sext_ln703_83_fu_12281_p1 = esl_sext<14,13>(add_ln703_385_fu_12275_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_84_fu_12291_p1() {
    sext_ln703_84_fu_12291_p1 = esl_sext<16,14>(add_ln703_386_fu_12285_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_85_fu_12339_p1() {
    sext_ln703_85_fu_12339_p1 = esl_sext<16,15>(add_ln703_411_reg_13919.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_86_fu_12640_p1() {
    sext_ln703_86_fu_12640_p1 = esl_sext<16,15>(add_ln703_415_fu_12634_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_87_fu_10278_p1() {
    sext_ln703_87_fu_10278_p1 = esl_sext<14,13>(add_ln703_416_fu_10272_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_88_fu_12644_p1() {
    sext_ln703_88_fu_12644_p1 = esl_sext<16,14>(add_ln703_417_reg_13624.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_89_fu_11239_p1() {
    sext_ln703_89_fu_11239_p1 = esl_sext<13,12>(add_ln703_419_fu_11233_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_90_fu_9832_p1() {
    sext_ln703_90_fu_9832_p1 = esl_sext<11,8>(add_ln703_420_fu_9826_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_91_fu_11243_p1() {
    sext_ln703_91_fu_11243_p1 = esl_sext<13,11>(add_ln703_421_reg_13523.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_92_fu_12653_p1() {
    sext_ln703_92_fu_12653_p1 = esl_sext<16,13>(add_ln703_422_reg_13827.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_93_fu_12683_p1() {
    sext_ln703_93_fu_12683_p1 = esl_sext<16,15>(add_ln703_446_reg_13342.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_94_fu_10294_p1() {
    sext_ln703_94_fu_10294_p1 = esl_sext<16,15>(add_ln703_447_fu_10288_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_95_fu_11278_p1() {
    sext_ln703_95_fu_11278_p1 = esl_sext<16,14>(add_ln703_451_reg_13093.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_96_fu_11287_p1() {
    sext_ln703_96_fu_11287_p1 = esl_sext<15,14>(add_ln703_452_fu_11281_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_97_fu_11297_p1() {
    sext_ln703_97_fu_11297_p1 = esl_sext<16,15>(add_ln703_453_fu_11291_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_98_fu_11307_p1() {
    sext_ln703_98_fu_11307_p1 = esl_sext<14,13>(add_ln703_455_reg_13347.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_99_fu_11316_p1() {
    sext_ln703_99_fu_11316_p1 = esl_sext<12,10>(add_ln703_456_fu_11310_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln703_fu_10654_p1() {
    sext_ln703_fu_10654_p1 = esl_sext<16,15>(add_ln703_336_reg_13327.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln708_2_fu_11976_p1() {
    sext_ln708_2_fu_11976_p1 = esl_sext<16,15>(grp_fu_7419_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln708_3_fu_12052_p1() {
    sext_ln708_3_fu_12052_p1 = esl_sext<16,15>(grp_fu_7349_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln708_4_fu_12622_p1() {
    sext_ln708_4_fu_12622_p1 = esl_sext<16,15>(grp_fu_7369_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln708_5_fu_12099_p1() {
    sext_ln708_5_fu_12099_p1 = esl_sext<16,14>(trunc_ln708_349_fu_12089_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln708_6_fu_12626_p1() {
    sext_ln708_6_fu_12626_p1 = esl_sext<16,15>(grp_fu_7249_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln708_7_fu_12630_p1() {
    sext_ln708_7_fu_12630_p1 = esl_sext<16,15>(grp_fu_7349_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sext_ln708_fu_11968_p1() {
    sext_ln708_fu_11968_p1 = esl_sext<16,15>(grp_fu_7359_p4.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_100_fu_9048_p1() {
    shl_ln1118_100_fu_9048_p1 = ap_port_reg_data_15_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_100_fu_9048_p3() {
    shl_ln1118_100_fu_9048_p3 = esl_concat<16,6>(shl_ln1118_100_fu_9048_p1.read(), ap_const_lv6_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_101_fu_9066_p1() {
    shl_ln1118_101_fu_9066_p1 = ap_port_reg_data_15_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_101_fu_9066_p3() {
    shl_ln1118_101_fu_9066_p3 = esl_concat<16,4>(shl_ln1118_101_fu_9066_p1.read(), ap_const_lv4_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_102_fu_9319_p3() {
    shl_ln1118_102_fu_9319_p3 = esl_concat<16,9>(data_16_V_read_2_reg_12812.read(), ap_const_lv9_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_103_fu_9330_p3() {
    shl_ln1118_103_fu_9330_p3 = esl_concat<16,4>(data_16_V_read_2_reg_12812.read(), ap_const_lv4_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_104_fu_9915_p3() {
    shl_ln1118_104_fu_9915_p3 = esl_concat<16,4>(data_17_V_read_2_reg_13394.read(), ap_const_lv4_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_105_fu_9926_p3() {
    shl_ln1118_105_fu_9926_p3 = esl_concat<16,1>(data_17_V_read_2_reg_13394.read(), ap_const_lv1_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_106_fu_9953_p3() {
    shl_ln1118_106_fu_9953_p3 = esl_concat<16,7>(data_17_V_read_2_reg_13394.read(), ap_const_lv7_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_107_fu_9964_p3() {
    shl_ln1118_107_fu_9964_p3 = esl_concat<16,2>(data_17_V_read_2_reg_13394.read(), ap_const_lv2_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_108_fu_9509_p3() {
    shl_ln1118_108_fu_9509_p3 = esl_concat<16,6>(data_18_V_read_2_reg_13387.read(), ap_const_lv6_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_109_fu_9520_p3() {
    shl_ln1118_109_fu_9520_p3 = esl_concat<16,2>(data_18_V_read_2_reg_13387.read(), ap_const_lv2_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_110_fu_9578_p1() {
    shl_ln1118_110_fu_9578_p1 = ap_port_reg_data_19_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_110_fu_9578_p3() {
    shl_ln1118_110_fu_9578_p3 = esl_concat<16,7>(shl_ln1118_110_fu_9578_p1.read(), ap_const_lv7_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_111_fu_9590_p1() {
    shl_ln1118_111_fu_9590_p1 = ap_port_reg_data_19_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_111_fu_9590_p3() {
    shl_ln1118_111_fu_9590_p3 = esl_concat<16,5>(shl_ln1118_111_fu_9590_p1.read(), ap_const_lv5_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_112_fu_9667_p1() {
    shl_ln1118_112_fu_9667_p1 = ap_port_reg_data_20_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_112_fu_9667_p3() {
    shl_ln1118_112_fu_9667_p3 = esl_concat<16,3>(shl_ln1118_112_fu_9667_p1.read(), ap_const_lv3_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_113_fu_9732_p1() {
    shl_ln1118_113_fu_9732_p1 = ap_port_reg_data_21_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_113_fu_9732_p3() {
    shl_ln1118_113_fu_9732_p3 = esl_concat<16,7>(shl_ln1118_113_fu_9732_p1.read(), ap_const_lv7_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_114_fu_9744_p1() {
    shl_ln1118_114_fu_9744_p1 = ap_port_reg_data_21_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_114_fu_9744_p3() {
    shl_ln1118_114_fu_9744_p3 = esl_concat<16,1>(shl_ln1118_114_fu_9744_p1.read(), ap_const_lv1_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_115_fu_10033_p1() {
    shl_ln1118_115_fu_10033_p1 = ap_port_reg_data_22_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_115_fu_10033_p3() {
    shl_ln1118_115_fu_10033_p3 = esl_concat<16,6>(shl_ln1118_115_fu_10033_p1.read(), ap_const_lv6_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_116_fu_10045_p1() {
    shl_ln1118_116_fu_10045_p1 = ap_port_reg_data_22_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_116_fu_10045_p3() {
    shl_ln1118_116_fu_10045_p3 = esl_concat<16,3>(shl_ln1118_116_fu_10045_p1.read(), ap_const_lv3_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_117_fu_10106_p1() {
    shl_ln1118_117_fu_10106_p1 = ap_port_reg_data_23_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_117_fu_10106_p3() {
    shl_ln1118_117_fu_10106_p3 = esl_concat<16,4>(shl_ln1118_117_fu_10106_p1.read(), ap_const_lv4_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_118_fu_10817_p3() {
    shl_ln1118_118_fu_10817_p3 = esl_concat<16,5>(data_25_V_read_2_reg_13675.read(), ap_const_lv5_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_119_fu_10828_p3() {
    shl_ln1118_119_fu_10828_p3 = esl_concat<16,1>(data_25_V_read_2_reg_13675.read(), ap_const_lv1_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_120_fu_10855_p3() {
    shl_ln1118_120_fu_10855_p3 = esl_concat<16,4>(data_25_V_read_2_reg_13675.read(), ap_const_lv4_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_121_fu_10866_p3() {
    shl_ln1118_121_fu_10866_p3 = esl_concat<16,2>(data_25_V_read_2_reg_13675.read(), ap_const_lv2_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_122_fu_10897_p3() {
    shl_ln1118_122_fu_10897_p3 = esl_concat<16,9>(data_25_V_read_2_reg_13675.read(), ap_const_lv9_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_123_fu_10493_p1() {
    shl_ln1118_123_fu_10493_p1 = ap_port_reg_data_25_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_123_fu_10493_p3() {
    shl_ln1118_123_fu_10493_p3 = esl_concat<16,6>(shl_ln1118_123_fu_10493_p1.read(), ap_const_lv6_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_124_fu_10566_p1() {
    shl_ln1118_124_fu_10566_p1 = ap_port_reg_data_26_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_124_fu_10566_p3() {
    shl_ln1118_124_fu_10566_p3 = esl_concat<16,5>(shl_ln1118_124_fu_10566_p1.read(), ap_const_lv5_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_125_fu_10578_p1() {
    shl_ln1118_125_fu_10578_p1 = ap_port_reg_data_26_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_125_fu_10578_p3() {
    shl_ln1118_125_fu_10578_p3 = esl_concat<16,3>(shl_ln1118_125_fu_10578_p1.read(), ap_const_lv3_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_126_fu_10979_p1() {
    shl_ln1118_126_fu_10979_p1 = ap_port_reg_data_28_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_126_fu_10979_p3() {
    shl_ln1118_126_fu_10979_p3 = esl_concat<16,3>(shl_ln1118_126_fu_10979_p1.read(), ap_const_lv3_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_127_fu_11054_p1() {
    shl_ln1118_127_fu_11054_p1 = ap_port_reg_data_29_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_127_fu_11054_p3() {
    shl_ln1118_127_fu_11054_p3 = esl_concat<16,4>(shl_ln1118_127_fu_11054_p1.read(), ap_const_lv4_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_128_fu_11072_p1() {
    shl_ln1118_128_fu_11072_p1 = ap_port_reg_data_29_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_128_fu_11072_p3() {
    shl_ln1118_128_fu_11072_p3 = esl_concat<16,1>(shl_ln1118_128_fu_11072_p1.read(), ap_const_lv1_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_129_fu_11104_p1() {
    shl_ln1118_129_fu_11104_p1 = ap_port_reg_data_29_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_129_fu_11104_p3() {
    shl_ln1118_129_fu_11104_p3 = esl_concat<16,8>(shl_ln1118_129_fu_11104_p1.read(), ap_const_lv8_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_130_fu_11116_p1() {
    shl_ln1118_130_fu_11116_p1 = ap_port_reg_data_29_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_130_fu_11116_p3() {
    shl_ln1118_130_fu_11116_p3 = esl_concat<16,2>(shl_ln1118_130_fu_11116_p1.read(), ap_const_lv2_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_131_fu_11537_p1() {
    shl_ln1118_131_fu_11537_p1 = ap_port_reg_data_31_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_131_fu_11537_p3() {
    shl_ln1118_131_fu_11537_p3 = esl_concat<16,7>(shl_ln1118_131_fu_11537_p1.read(), ap_const_lv7_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_132_fu_11549_p1() {
    shl_ln1118_132_fu_11549_p1 = ap_port_reg_data_31_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_132_fu_11549_p3() {
    shl_ln1118_132_fu_11549_p3 = esl_concat<16,5>(shl_ln1118_132_fu_11549_p1.read(), ap_const_lv5_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_133_fu_11581_p1() {
    shl_ln1118_133_fu_11581_p1 = ap_port_reg_data_31_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_133_fu_11581_p3() {
    shl_ln1118_133_fu_11581_p3 = esl_concat<16,8>(shl_ln1118_133_fu_11581_p1.read(), ap_const_lv8_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_134_fu_11593_p1() {
    shl_ln1118_134_fu_11593_p1 = ap_port_reg_data_31_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_134_fu_11593_p3() {
    shl_ln1118_134_fu_11593_p3 = esl_concat<16,1>(shl_ln1118_134_fu_11593_p1.read(), ap_const_lv1_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_135_fu_11872_p3() {
    shl_ln1118_135_fu_11872_p3 = esl_concat<16,9>(data_32_V_read_1_reg_13882.read(), ap_const_lv9_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_136_fu_11899_p3() {
    shl_ln1118_136_fu_11899_p3 = esl_concat<16,8>(data_32_V_read_1_reg_13882.read(), ap_const_lv8_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_137_fu_11910_p3() {
    shl_ln1118_137_fu_11910_p3 = esl_concat<16,2>(data_32_V_read_1_reg_13882.read(), ap_const_lv2_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_138_fu_11980_p1() {
    shl_ln1118_138_fu_11980_p1 = ap_port_reg_data_33_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_138_fu_11980_p3() {
    shl_ln1118_138_fu_11980_p3 = esl_concat<16,9>(shl_ln1118_138_fu_11980_p1.read(), ap_const_lv9_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_139_fu_11992_p1() {
    shl_ln1118_139_fu_11992_p1 = ap_port_reg_data_33_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_139_fu_11992_p3() {
    shl_ln1118_139_fu_11992_p3 = esl_concat<16,4>(shl_ln1118_139_fu_11992_p1.read(), ap_const_lv4_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_140_fu_12061_p3() {
    shl_ln1118_140_fu_12061_p3 = esl_concat<16,7>(data_35_V_read_1_reg_13553.read(), ap_const_lv7_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_141_fu_12072_p3() {
    shl_ln1118_141_fu_12072_p3 = esl_concat<16,5>(data_35_V_read_1_reg_13553.read(), ap_const_lv5_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_142_fu_10195_p1() {
    shl_ln1118_142_fu_10195_p1 = ap_port_reg_data_35_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_142_fu_10195_p3() {
    shl_ln1118_142_fu_10195_p3 = esl_concat<16,3>(shl_ln1118_142_fu_10195_p1.read(), ap_const_lv3_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_143_fu_10207_p1() {
    shl_ln1118_143_fu_10207_p1 = ap_port_reg_data_35_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_143_fu_10207_p3() {
    shl_ln1118_143_fu_10207_p3 = esl_concat<16,1>(shl_ln1118_143_fu_10207_p1.read(), ap_const_lv1_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_75_fu_7805_p3() {
    shl_ln1118_75_fu_7805_p3 = esl_concat<16,4>(data_0_V_read_3_reg_12869.read(), ap_const_lv4_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_76_fu_8588_p3() {
    shl_ln1118_76_fu_8588_p3 = esl_concat<16,4>(data_1_V_read_3_reg_12859.read(), ap_const_lv4_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_77_fu_8619_p3() {
    shl_ln1118_77_fu_8619_p3 = esl_concat<16,1>(data_1_V_read_3_reg_12859.read(), ap_const_lv1_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_78_fu_7875_p3() {
    shl_ln1118_78_fu_7875_p3 = esl_concat<16,6>(data_2_V_read_3_reg_12851.read(), ap_const_lv6_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_79_fu_7964_p3() {
    shl_ln1118_79_fu_7964_p3 = esl_concat<16,5>(data_4_V_read_3_reg_12836.read(), ap_const_lv5_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_80_fu_8662_p3() {
    shl_ln1118_80_fu_8662_p3 = esl_concat<16,4>(data_6_V_read_3_reg_12819.read(), ap_const_lv4_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_81_fu_8689_p3() {
    shl_ln1118_81_fu_8689_p3 = esl_concat<16,7>(data_6_V_read_3_reg_12819.read(), ap_const_lv7_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_82_fu_8700_p3() {
    shl_ln1118_82_fu_8700_p3 = esl_concat<16,5>(data_6_V_read_3_reg_12819.read(), ap_const_lv5_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_83_fu_9237_p3() {
    shl_ln1118_83_fu_9237_p3 = esl_concat<16,8>(data_7_V_read_3_reg_13015.read(), ap_const_lv8_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_84_fu_9254_p3() {
    shl_ln1118_84_fu_9254_p3 = esl_concat<16,4>(data_7_V_read_3_reg_13015.read(), ap_const_lv4_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_85_fu_9285_p3() {
    shl_ln1118_85_fu_9285_p3 = esl_concat<16,3>(data_7_V_read_3_reg_13015.read(), ap_const_lv3_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_86_fu_8168_p1() {
    shl_ln1118_86_fu_8168_p1 = ap_port_reg_data_9_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_86_fu_8168_p3() {
    shl_ln1118_86_fu_8168_p3 = esl_concat<16,6>(shl_ln1118_86_fu_8168_p1.read(), ap_const_lv6_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_87_fu_8180_p1() {
    shl_ln1118_87_fu_8180_p1 = ap_port_reg_data_9_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_87_fu_8180_p3() {
    shl_ln1118_87_fu_8180_p3 = esl_concat<16,3>(shl_ln1118_87_fu_8180_p1.read(), ap_const_lv3_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_88_fu_8302_p3() {
    shl_ln1118_88_fu_8302_p3 = esl_concat<16,5>(data_10_V_read11_reg_13103.read(), ap_const_lv5_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_89_fu_8375_p1() {
    shl_ln1118_89_fu_8375_p1 = ap_port_reg_data_11_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_89_fu_8375_p3() {
    shl_ln1118_89_fu_8375_p3 = esl_concat<16,3>(shl_ln1118_89_fu_8375_p1.read(), ap_const_lv3_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_90_fu_8393_p1() {
    shl_ln1118_90_fu_8393_p1 = ap_port_reg_data_11_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_90_fu_8393_p3() {
    shl_ln1118_90_fu_8393_p3 = esl_concat<16,1>(shl_ln1118_90_fu_8393_p1.read(), ap_const_lv1_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_91_fu_8439_p1() {
    shl_ln1118_91_fu_8439_p1 = ap_port_reg_data_11_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_91_fu_8439_p3() {
    shl_ln1118_91_fu_8439_p3 = esl_concat<16,8>(shl_ln1118_91_fu_8439_p1.read(), ap_const_lv8_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_92_fu_8740_p3() {
    shl_ln1118_92_fu_8740_p3 = esl_concat<16,8>(data_12_V_read_2_reg_13183.read(), ap_const_lv8_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_93_fu_8751_p3() {
    shl_ln1118_93_fu_8751_p3 = esl_concat<16,6>(data_12_V_read_2_reg_13183.read(), ap_const_lv6_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_94_fu_8782_p3() {
    shl_ln1118_94_fu_8782_p3 = esl_concat<16,7>(data_12_V_read_2_reg_13183.read(), ap_const_lv7_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_95_fu_8793_p3() {
    shl_ln1118_95_fu_8793_p3 = esl_concat<16,1>(data_12_V_read_2_reg_13183.read(), ap_const_lv1_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_96_fu_8827_p3() {
    shl_ln1118_96_fu_8827_p3 = esl_concat<16,4>(data_12_V_read_2_reg_13183.read(), ap_const_lv4_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_97_fu_8945_p1() {
    shl_ln1118_97_fu_8945_p1 = ap_port_reg_data_14_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_97_fu_8945_p3() {
    shl_ln1118_97_fu_8945_p3 = esl_concat<16,6>(shl_ln1118_97_fu_8945_p1.read(), ap_const_lv6_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_98_fu_8957_p1() {
    shl_ln1118_98_fu_8957_p1 = ap_port_reg_data_14_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_98_fu_8957_p3() {
    shl_ln1118_98_fu_8957_p3 = esl_concat<16,1>(shl_ln1118_98_fu_8957_p1.read(), ap_const_lv1_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_99_fu_8993_p1() {
    shl_ln1118_99_fu_8993_p1 = ap_port_reg_data_14_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_99_fu_8993_p3() {
    shl_ln1118_99_fu_8993_p3 = esl_concat<16,3>(shl_ln1118_99_fu_8993_p1.read(), ap_const_lv3_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln1118_s_fu_8577_p3() {
    shl_ln1118_s_fu_8577_p3 = esl_concat<16,8>(data_1_V_read_3_reg_12859.read(), ap_const_lv8_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_shl_ln_fu_7788_p3() {
    shl_ln_fu_7788_p3 = esl_concat<16,6>(data_0_V_read_3_reg_12869.read(), ap_const_lv6_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_50_fu_7816_p2() {
    sub_ln1118_50_fu_7816_p2 = (!sub_ln1118_fu_7799_p2.read().is_01() || !sext_ln1118_184_fu_7812_p1.read().is_01())? sc_lv<23>(): (sc_biguint<23>(sub_ln1118_fu_7799_p2.read()) - sc_bigint<23>(sext_ln1118_184_fu_7812_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_51_fu_8599_p2() {
    sub_ln1118_51_fu_8599_p2 = (!sext_ln1118_186_fu_8595_p1.read().is_01() || !sext_ln1118_185_fu_8584_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln1118_186_fu_8595_p1.read()) - sc_bigint<25>(sext_ln1118_185_fu_8584_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_52_fu_8630_p2() {
    sub_ln1118_52_fu_8630_p2 = (!sext_ln1118_188_fu_8626_p1.read().is_01() || !sext_ln1118_187_fu_8615_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_188_fu_8626_p1.read()) - sc_bigint<21>(sext_ln1118_187_fu_8615_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_53_fu_7886_p2() {
    sub_ln1118_53_fu_7886_p2 = (!sext_ln1118_189_fu_7882_p1.read().is_01() || !sext_ln1116_42_cast107_fu_7864_p1.read().is_01())? sc_lv<23>(): (sc_bigint<23>(sext_ln1118_189_fu_7882_p1.read()) - sc_bigint<23>(sext_ln1116_42_cast107_fu_7864_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_54_fu_7975_p2() {
    sub_ln1118_54_fu_7975_p2 = (!sext_ln1118_190_fu_7971_p1.read().is_01() || !sext_ln1116_44_cast102_fu_7948_p1.read().is_01())? sc_lv<22>(): (sc_bigint<22>(sext_ln1118_190_fu_7971_p1.read()) - sc_bigint<22>(sext_ln1116_44_cast102_fu_7948_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_55_fu_8673_p2() {
    sub_ln1118_55_fu_8673_p2 = (!ap_const_lv21_0.is_01() || !sext_ln1118_191_fu_8669_p1.read().is_01())? sc_lv<21>(): (sc_biguint<21>(ap_const_lv21_0) - sc_bigint<21>(sext_ln1118_191_fu_8669_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_56_fu_8711_p2() {
    sub_ln1118_56_fu_8711_p2 = (!sext_ln1118_193_fu_8707_p1.read().is_01() || !sext_ln1118_192_fu_8696_p1.read().is_01())? sc_lv<24>(): (sc_bigint<24>(sext_ln1118_193_fu_8707_p1.read()) - sc_bigint<24>(sext_ln1118_192_fu_8696_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_57_fu_9248_p2() {
    sub_ln1118_57_fu_9248_p2 = (!ap_const_lv25_0.is_01() || !sext_ln1118_194_fu_9244_p1.read().is_01())? sc_lv<25>(): (sc_biguint<25>(ap_const_lv25_0) - sc_bigint<25>(sext_ln1118_194_fu_9244_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_58_fu_9265_p2() {
    sub_ln1118_58_fu_9265_p2 = (!sub_ln1118_57_fu_9248_p2.read().is_01() || !sext_ln1118_195_fu_9261_p1.read().is_01())? sc_lv<25>(): (sc_biguint<25>(sub_ln1118_57_fu_9248_p2.read()) - sc_bigint<25>(sext_ln1118_195_fu_9261_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_59_fu_9296_p2() {
    sub_ln1118_59_fu_9296_p2 = (!sext_ln1118_196_fu_9292_p1.read().is_01() || !sext_ln1116_47_cast91_fu_9234_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_196_fu_9292_p1.read()) - sc_bigint<20>(sext_ln1116_47_cast91_fu_9234_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_60_fu_8192_p2() {
    sub_ln1118_60_fu_8192_p2 = (!sext_ln1118_198_fu_8188_p1.read().is_01() || !sext_ln1118_197_fu_8176_p1.read().is_01())? sc_lv<23>(): (sc_bigint<23>(sext_ln1118_198_fu_8188_p1.read()) - sc_bigint<23>(sext_ln1118_197_fu_8176_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_61_fu_8313_p2() {
    sub_ln1118_61_fu_8313_p2 = (!ap_const_lv22_0.is_01() || !sext_ln1118_199_fu_8309_p1.read().is_01())? sc_lv<22>(): (sc_biguint<22>(ap_const_lv22_0) - sc_bigint<22>(sext_ln1118_199_fu_8309_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_62_fu_8319_p2() {
    sub_ln1118_62_fu_8319_p2 = (!sub_ln1118_61_fu_8313_p2.read().is_01() || !sext_ln1116_50_cast81_cast476_fu_8295_p1.read().is_01())? sc_lv<22>(): (sc_biguint<22>(sub_ln1118_61_fu_8313_p2.read()) - sc_bigint<22>(sext_ln1116_50_cast81_cast476_fu_8295_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_63_fu_8387_p2() {
    sub_ln1118_63_fu_8387_p2 = (!ap_const_lv20_0.is_01() || !sext_ln1118_200_fu_8383_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(ap_const_lv20_0) - sc_bigint<20>(sext_ln1118_200_fu_8383_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_64_fu_8405_p2() {
    sub_ln1118_64_fu_8405_p2 = (!sub_ln1118_63_fu_8387_p2.read().is_01() || !sext_ln1118_201_fu_8401_p1.read().is_01())? sc_lv<20>(): (sc_biguint<20>(sub_ln1118_63_fu_8387_p2.read()) - sc_bigint<20>(sext_ln1118_201_fu_8401_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_65_fu_8455_p2() {
    sub_ln1118_65_fu_8455_p2 = (!sext_ln1118_202_fu_8447_p1.read().is_01() || !sext_ln1118_203_fu_8451_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln1118_202_fu_8447_p1.read()) - sc_bigint<25>(sext_ln1118_203_fu_8451_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_66_fu_8804_p2() {
    sub_ln1118_66_fu_8804_p2 = (!sext_ln1118_206_fu_8789_p1.read().is_01() || !sext_ln1118_207_fu_8800_p1.read().is_01())? sc_lv<24>(): (sc_bigint<24>(sext_ln1118_206_fu_8789_p1.read()) - sc_bigint<24>(sext_ln1118_207_fu_8800_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_67_fu_8866_p2() {
    sub_ln1118_67_fu_8866_p2 = (!sext_ln1118_210_fu_8862_p1.read().is_01() || !sext_ln1118_206_fu_8789_p1.read().is_01())? sc_lv<24>(): (sc_bigint<24>(sext_ln1118_210_fu_8862_p1.read()) - sc_bigint<24>(sext_ln1118_206_fu_8789_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_68_fu_9060_p2() {
    sub_ln1118_68_fu_9060_p2 = (!ap_const_lv23_0.is_01() || !sext_ln1118_214_fu_9056_p1.read().is_01())? sc_lv<23>(): (sc_biguint<23>(ap_const_lv23_0) - sc_bigint<23>(sext_ln1118_214_fu_9056_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_69_fu_9078_p2() {
    sub_ln1118_69_fu_9078_p2 = (!sub_ln1118_68_fu_9060_p2.read().is_01() || !sext_ln1118_215_fu_9074_p1.read().is_01())? sc_lv<23>(): (sc_biguint<23>(sub_ln1118_68_fu_9060_p2.read()) - sc_bigint<23>(sext_ln1118_215_fu_9074_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_70_fu_9341_p2() {
    sub_ln1118_70_fu_9341_p2 = (!sext_ln1118_216_fu_9326_p1.read().is_01() || !sext_ln1118_217_fu_9337_p1.read().is_01())? sc_lv<26>(): (sc_bigint<26>(sext_ln1118_216_fu_9326_p1.read()) - sc_bigint<26>(sext_ln1118_217_fu_9337_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_71_fu_9937_p2() {
    sub_ln1118_71_fu_9937_p2 = (!sext_ln1118_218_fu_9922_p1.read().is_01() || !sext_ln1118_219_fu_9933_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_218_fu_9922_p1.read()) - sc_bigint<21>(sext_ln1118_219_fu_9933_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_72_fu_9531_p2() {
    sub_ln1118_72_fu_9531_p2 = (!sext_ln1118_222_fu_9516_p1.read().is_01() || !sext_ln1118_223_fu_9527_p1.read().is_01())? sc_lv<23>(): (sc_bigint<23>(sext_ln1118_222_fu_9516_p1.read()) - sc_bigint<23>(sext_ln1118_223_fu_9527_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_73_fu_9602_p2() {
    sub_ln1118_73_fu_9602_p2 = (!sext_ln1118_224_fu_9586_p1.read().is_01() || !sext_ln1118_225_fu_9598_p1.read().is_01())? sc_lv<24>(): (sc_bigint<24>(sext_ln1118_224_fu_9586_p1.read()) - sc_bigint<24>(sext_ln1118_225_fu_9598_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_74_fu_10118_p2() {
    sub_ln1118_74_fu_10118_p2 = (!sext_ln1118_231_fu_10114_p1.read().is_01() || !sext_ln1116_63_cast_fu_10102_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_231_fu_10114_p1.read()) - sc_bigint<21>(sext_ln1116_63_cast_fu_10102_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_75_fu_10839_p2() {
    sub_ln1118_75_fu_10839_p2 = (!sext_ln1118_233_fu_10835_p1.read().is_01() || !sext_ln1118_232_fu_10824_p1.read().is_01())? sc_lv<22>(): (sc_bigint<22>(sext_ln1118_233_fu_10835_p1.read()) - sc_bigint<22>(sext_ln1118_232_fu_10824_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_76_fu_10877_p2() {
    sub_ln1118_76_fu_10877_p2 = (!sext_ln1118_235_fu_10873_p1.read().is_01() || !sext_ln1118_234_fu_10862_p1.read().is_01())? sc_lv<21>(): (sc_bigint<21>(sext_ln1118_235_fu_10873_p1.read()) - sc_bigint<21>(sext_ln1118_234_fu_10862_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_77_fu_10908_p2() {
    sub_ln1118_77_fu_10908_p2 = (!ap_const_lv26_0.is_01() || !sext_ln1118_236_fu_10904_p1.read().is_01())? sc_lv<26>(): (sc_biguint<26>(ap_const_lv26_0) - sc_bigint<26>(sext_ln1118_236_fu_10904_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_78_fu_10918_p2() {
    sub_ln1118_78_fu_10918_p2 = (!sub_ln1118_77_fu_10908_p2.read().is_01() || !sext_ln1118_237_fu_10914_p1.read().is_01())? sc_lv<26>(): (sc_biguint<26>(sub_ln1118_77_fu_10908_p2.read()) - sc_bigint<26>(sext_ln1118_237_fu_10914_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_79_fu_11066_p2() {
    sub_ln1118_79_fu_11066_p2 = (!ap_const_lv21_0.is_01() || !sext_ln1118_243_fu_11062_p1.read().is_01())? sc_lv<21>(): (sc_biguint<21>(ap_const_lv21_0) - sc_bigint<21>(sext_ln1118_243_fu_11062_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_80_fu_11084_p2() {
    sub_ln1118_80_fu_11084_p2 = (!sub_ln1118_79_fu_11066_p2.read().is_01() || !sext_ln1118_244_fu_11080_p1.read().is_01())? sc_lv<21>(): (sc_biguint<21>(sub_ln1118_79_fu_11066_p2.read()) - sc_bigint<21>(sext_ln1118_244_fu_11080_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_81_fu_11561_p2() {
    sub_ln1118_81_fu_11561_p2 = (!sext_ln1118_247_fu_11545_p1.read().is_01() || !sext_ln1118_248_fu_11557_p1.read().is_01())? sc_lv<24>(): (sc_bigint<24>(sext_ln1118_247_fu_11545_p1.read()) - sc_bigint<24>(sext_ln1118_248_fu_11557_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_82_fu_11883_p2() {
    sub_ln1118_82_fu_11883_p2 = (!ap_const_lv26_0.is_01() || !sext_ln1118_251_fu_11879_p1.read().is_01())? sc_lv<26>(): (sc_biguint<26>(ap_const_lv26_0) - sc_bigint<26>(sext_ln1118_251_fu_11879_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_83_fu_12004_p2() {
    sub_ln1118_83_fu_12004_p2 = (!sext_ln1118_255_fu_11988_p1.read().is_01() || !sext_ln1118_256_fu_12000_p1.read().is_01())? sc_lv<26>(): (sc_bigint<26>(sext_ln1118_255_fu_11988_p1.read()) - sc_bigint<26>(sext_ln1118_256_fu_12000_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_84_fu_10219_p2() {
    sub_ln1118_84_fu_10219_p2 = (!sext_ln1118_263_fu_10215_p1.read().is_01() || !sext_ln1118_262_fu_10203_p1.read().is_01())? sc_lv<20>(): (sc_bigint<20>(sext_ln1118_263_fu_10215_p1.read()) - sc_bigint<20>(sext_ln1118_262_fu_10203_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_85_fu_10150_p2() {
    sub_ln1118_85_fu_10150_p2 = (!sext_ln1116_63_cast42_fu_10092_p1.read().is_01() || !sext_ln1118_265_fu_10146_p1.read().is_01())? sc_lv<22>(): (sc_bigint<22>(sext_ln1116_63_cast42_fu_10092_p1.read()) - sc_bigint<22>(sext_ln1118_265_fu_10146_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_sub_ln1118_fu_7799_p2() {
    sub_ln1118_fu_7799_p2 = (!ap_const_lv23_0.is_01() || !sext_ln1118_fu_7795_p1.read().is_01())? sc_lv<23>(): (sc_biguint<23>(ap_const_lv23_0) - sc_bigint<23>(sext_ln1118_fu_7795_p1.read()));
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_tmp_46_fu_8636_p4() {
    tmp_46_fu_8636_p4 = sub_ln1118_52_fu_8630_p2.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_tmp_50_fu_9011_p4() {
    tmp_50_fu_9011_p4 = add_ln1118_12_fu_9005_p2.read().range(19, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_tmp_53_fu_10596_p4() {
    tmp_53_fu_10596_p4 = add_ln1118_18_fu_10590_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_tmp_54_fu_11090_p4() {
    tmp_54_fu_11090_p4 = sub_ln1118_80_fu_11084_p2.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_tmp_55_fu_10225_p4() {
    tmp_55_fu_10225_p4 = sub_ln1118_84_fu_10219_p2.read().range(19, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_tmp_fu_10138_p1() {
    tmp_fu_10138_p1 = ap_port_reg_data_23_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_tmp_fu_10138_p3() {
    tmp_fu_10138_p3 = esl_concat<16,5>(tmp_fu_10138_p1.read(), ap_const_lv5_0);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_128_fu_12010_p4() {
    trunc_ln708_128_fu_12010_p4 = sub_ln1118_83_fu_12004_p2.read().range(25, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_187_fu_7850_p1() {
    trunc_ln708_187_fu_7850_p1 =  (sc_lv<23>) (grp_fu_837_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_197_fu_7916_p1() {
    trunc_ln708_197_fu_7916_p1 =  (sc_lv<23>) (grp_fu_840_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_206_fu_8014_p1() {
    trunc_ln708_206_fu_8014_p1 =  (sc_lv<24>) (grp_fu_837_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_208_fu_8024_p1() {
    trunc_ln708_208_fu_8024_p1 =  (sc_lv<22>) (grp_fu_833_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_213_fu_8717_p4() {
    trunc_ln708_213_fu_8717_p4 = sub_ln1118_56_fu_8711_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_217_fu_9271_p4() {
    trunc_ln708_217_fu_9271_p4 = sub_ln1118_58_fu_9265_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_235_fu_8361_p1() {
    trunc_ln708_235_fu_8361_p1 =  (sc_lv<24>) (grp_fu_833_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_239_fu_8425_p1() {
    trunc_ln708_239_fu_8425_p1 =  (sc_lv<23>) (grp_fu_826_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_239_fu_8425_p4() {
    trunc_ln708_239_fu_8425_p4 = trunc_ln708_239_fu_8425_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_240_fu_8461_p4() {
    trunc_ln708_240_fu_8461_p4 = sub_ln1118_65_fu_8455_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_243_fu_8768_p4() {
    trunc_ln708_243_fu_8768_p4 = add_ln1118_fu_8762_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_244_fu_8810_p4() {
    trunc_ln708_244_fu_8810_p4 = sub_ln1118_66_fu_8804_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_246_fu_8848_p4() {
    trunc_ln708_246_fu_8848_p4 = add_ln1118_10_fu_8842_p2.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_247_fu_8872_p4() {
    trunc_ln708_247_fu_8872_p4 = sub_ln1118_67_fu_8866_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_252_fu_8505_p1() {
    trunc_ln708_252_fu_8505_p1 = ap_port_reg_data_13_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_254_fu_8905_p1() {
    trunc_ln708_254_fu_8905_p1 =  (sc_lv<23>) (grp_fu_834_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_257_fu_8975_p4() {
    trunc_ln708_257_fu_8975_p4 = add_ln1118_11_fu_8969_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_264_fu_9094_p1() {
    trunc_ln708_264_fu_9094_p1 =  (sc_lv<24>) (grp_fu_829_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_266_fu_9108_p1() {
    trunc_ln708_266_fu_9108_p1 =  (sc_lv<24>) (grp_fu_842_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_267_fu_9118_p1() {
    trunc_ln708_267_fu_9118_p1 =  (sc_lv<22>) (grp_fu_836_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_267_fu_9118_p4() {
    trunc_ln708_267_fu_9118_p4 = trunc_ln708_267_fu_9118_p1.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_271_fu_9981_p4() {
    trunc_ln708_271_fu_9981_p4 = add_ln1118_13_fu_9975_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_275_fu_9385_p1() {
    trunc_ln708_275_fu_9385_p1 =  (sc_lv<24>) (grp_fu_828_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_275_fu_9385_p4() {
    trunc_ln708_275_fu_9385_p4 = trunc_ln708_275_fu_9385_p1.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_283_fu_9653_p1() {
    trunc_ln708_283_fu_9653_p1 =  (sc_lv<22>) (grp_fu_830_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_287_fu_9718_p1() {
    trunc_ln708_287_fu_9718_p1 = ap_port_reg_data_21_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_287_fu_9718_p4() {
    trunc_ln708_287_fu_9718_p4 = trunc_ln708_287_fu_9718_p1.read().range(15, 9);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_288_fu_9762_p4() {
    trunc_ln708_288_fu_9762_p4 = add_ln1118_15_fu_9756_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_292_fu_10063_p4() {
    trunc_ln708_292_fu_10063_p4 = add_ln1118_16_fu_10057_p2.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_295_fu_10124_p4() {
    trunc_ln708_295_fu_10124_p4 = sub_ln1118_74_fu_10118_p2.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_296_fu_10156_p4() {
    trunc_ln708_296_fu_10156_p4 = sub_ln1118_85_fu_10150_p2.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_300_fu_10185_p1() {
    trunc_ln708_300_fu_10185_p1 = ap_port_reg_data_24_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_302_fu_10447_p1() {
    trunc_ln708_302_fu_10447_p1 =  (sc_lv<21>) (grp_fu_840_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_302_fu_10447_p4() {
    trunc_ln708_302_fu_10447_p4 = trunc_ln708_302_fu_10447_p1.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_306_fu_10883_p4() {
    trunc_ln708_306_fu_10883_p4 = sub_ln1118_76_fu_10877_p2.read().range(20, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_310_fu_10548_p1() {
    trunc_ln708_310_fu_10548_p1 =  (sc_lv<23>) (grp_fu_833_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_310_fu_10548_p4() {
    trunc_ln708_310_fu_10548_p4 = trunc_ln708_310_fu_10548_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_320_fu_10997_p4() {
    trunc_ln708_320_fu_10997_p4 = add_ln1118_19_fu_10991_p2.read().range(19, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_323_fu_11040_p1() {
    trunc_ln708_323_fu_11040_p1 = ap_port_reg_data_29_V_read.read();
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_323_fu_11040_p4() {
    trunc_ln708_323_fu_11040_p4 = trunc_ln708_323_fu_11040_p1.read().range(15, 7);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_324_fu_11134_p4() {
    trunc_ln708_324_fu_11134_p4 = add_ln1118_20_fu_11128_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_328_fu_11497_p1() {
    trunc_ln708_328_fu_11497_p1 =  (sc_lv<23>) (grp_fu_841_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_328_fu_11497_p4() {
    trunc_ln708_328_fu_11497_p4 = trunc_ln708_328_fu_11497_p1.read().range(22, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_331_fu_11567_p4() {
    trunc_ln708_331_fu_11567_p4 = sub_ln1118_81_fu_11561_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_332_fu_11611_p4() {
    trunc_ln708_332_fu_11611_p4 = add_ln1118_21_fu_11605_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_334_fu_11650_p1() {
    trunc_ln708_334_fu_11650_p1 =  (sc_lv<24>) (grp_fu_835_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_334_fu_11650_p4() {
    trunc_ln708_334_fu_11650_p4 = trunc_ln708_334_fu_11650_p1.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_337_fu_11672_p1() {
    trunc_ln708_337_fu_11672_p1 =  (sc_lv<22>) (grp_fu_826_p2.read());
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_337_fu_11672_p4() {
    trunc_ln708_337_fu_11672_p4 = trunc_ln708_337_fu_11672_p1.read().range(21, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_338_fu_11927_p4() {
    trunc_ln708_338_fu_11927_p4 = add_ln1118_22_fu_11921_p2.read().range(24, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_trunc_ln708_349_fu_12089_p4() {
    trunc_ln708_349_fu_12089_p4 = add_ln1118_23_fu_12083_p2.read().range(23, 10);
}

void dense_latency_ap_fixed_ap_fixed_config5_mult_0_0_0_0_0_0_0_0_0::thread_zext_ln703_fu_10760_p1() {
    zext_ln703_fu_10760_p1 = esl_zext<13,11>(add_ln703_564_fu_10754_p2.read());
}

}

