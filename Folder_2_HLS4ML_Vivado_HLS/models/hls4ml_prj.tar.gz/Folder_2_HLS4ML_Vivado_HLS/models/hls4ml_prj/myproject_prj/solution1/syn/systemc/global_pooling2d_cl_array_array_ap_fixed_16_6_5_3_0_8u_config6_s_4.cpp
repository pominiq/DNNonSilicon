#include "global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op6877() {
    io_acc_block_signal_op6877 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op6895() {
    io_acc_block_signal_op6895 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op6913() {
    io_acc_block_signal_op6913 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op6931() {
    io_acc_block_signal_op6931 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op6949() {
    io_acc_block_signal_op6949 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op6967() {
    io_acc_block_signal_op6967 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op6985() {
    io_acc_block_signal_op6985 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7003() {
    io_acc_block_signal_op7003 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7021() {
    io_acc_block_signal_op7021 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op703() {
    io_acc_block_signal_op703 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7039() {
    io_acc_block_signal_op7039 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7057() {
    io_acc_block_signal_op7057 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7075() {
    io_acc_block_signal_op7075 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7093() {
    io_acc_block_signal_op7093 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7111() {
    io_acc_block_signal_op7111 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7129() {
    io_acc_block_signal_op7129 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7147() {
    io_acc_block_signal_op7147 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7165() {
    io_acc_block_signal_op7165 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7183() {
    io_acc_block_signal_op7183 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7201() {
    io_acc_block_signal_op7201 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op721() {
    io_acc_block_signal_op721 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7219() {
    io_acc_block_signal_op7219 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7237() {
    io_acc_block_signal_op7237 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7255() {
    io_acc_block_signal_op7255 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7273() {
    io_acc_block_signal_op7273 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7291() {
    io_acc_block_signal_op7291 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7309() {
    io_acc_block_signal_op7309 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7327() {
    io_acc_block_signal_op7327 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7345() {
    io_acc_block_signal_op7345 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7363() {
    io_acc_block_signal_op7363 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7381() {
    io_acc_block_signal_op7381 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op739() {
    io_acc_block_signal_op739 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7399() {
    io_acc_block_signal_op7399 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7417() {
    io_acc_block_signal_op7417 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7435() {
    io_acc_block_signal_op7435 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7453() {
    io_acc_block_signal_op7453 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7471() {
    io_acc_block_signal_op7471 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7489() {
    io_acc_block_signal_op7489 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7507() {
    io_acc_block_signal_op7507 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7525() {
    io_acc_block_signal_op7525 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7543() {
    io_acc_block_signal_op7543 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7561() {
    io_acc_block_signal_op7561 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op757() {
    io_acc_block_signal_op757 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7579() {
    io_acc_block_signal_op7579 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7597() {
    io_acc_block_signal_op7597 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7615() {
    io_acc_block_signal_op7615 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7633() {
    io_acc_block_signal_op7633 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7651() {
    io_acc_block_signal_op7651 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7669() {
    io_acc_block_signal_op7669 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7687() {
    io_acc_block_signal_op7687 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7705() {
    io_acc_block_signal_op7705 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7723() {
    io_acc_block_signal_op7723 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7741() {
    io_acc_block_signal_op7741 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op775() {
    io_acc_block_signal_op775 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7759() {
    io_acc_block_signal_op7759 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7777() {
    io_acc_block_signal_op7777 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7795() {
    io_acc_block_signal_op7795 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7813() {
    io_acc_block_signal_op7813 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7831() {
    io_acc_block_signal_op7831 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7849() {
    io_acc_block_signal_op7849 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7867() {
    io_acc_block_signal_op7867 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7885() {
    io_acc_block_signal_op7885 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7903() {
    io_acc_block_signal_op7903 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7921() {
    io_acc_block_signal_op7921 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op793() {
    io_acc_block_signal_op793 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7939() {
    io_acc_block_signal_op7939 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7957() {
    io_acc_block_signal_op7957 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7975() {
    io_acc_block_signal_op7975 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op7993() {
    io_acc_block_signal_op7993 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8011() {
    io_acc_block_signal_op8011 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8029() {
    io_acc_block_signal_op8029 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8047() {
    io_acc_block_signal_op8047 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8065() {
    io_acc_block_signal_op8065 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8083() {
    io_acc_block_signal_op8083 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8101() {
    io_acc_block_signal_op8101 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op811() {
    io_acc_block_signal_op811 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8119() {
    io_acc_block_signal_op8119 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8137() {
    io_acc_block_signal_op8137 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8155() {
    io_acc_block_signal_op8155 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8173() {
    io_acc_block_signal_op8173 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8191() {
    io_acc_block_signal_op8191 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8209() {
    io_acc_block_signal_op8209 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8227() {
    io_acc_block_signal_op8227 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8245() {
    io_acc_block_signal_op8245 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8263() {
    io_acc_block_signal_op8263 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8281() {
    io_acc_block_signal_op8281 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op829() {
    io_acc_block_signal_op829 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8299() {
    io_acc_block_signal_op8299 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8317() {
    io_acc_block_signal_op8317 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8335() {
    io_acc_block_signal_op8335 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8353() {
    io_acc_block_signal_op8353 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8371() {
    io_acc_block_signal_op8371 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8389() {
    io_acc_block_signal_op8389 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8407() {
    io_acc_block_signal_op8407 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8425() {
    io_acc_block_signal_op8425 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8443() {
    io_acc_block_signal_op8443 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8461() {
    io_acc_block_signal_op8461 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op847() {
    io_acc_block_signal_op847 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8479() {
    io_acc_block_signal_op8479 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8497() {
    io_acc_block_signal_op8497 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8515() {
    io_acc_block_signal_op8515 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8533() {
    io_acc_block_signal_op8533 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8551() {
    io_acc_block_signal_op8551 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8569() {
    io_acc_block_signal_op8569 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8587() {
    io_acc_block_signal_op8587 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8605() {
    io_acc_block_signal_op8605 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8623() {
    io_acc_block_signal_op8623 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8641() {
    io_acc_block_signal_op8641 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op865() {
    io_acc_block_signal_op865 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8659() {
    io_acc_block_signal_op8659 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8677() {
    io_acc_block_signal_op8677 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8695() {
    io_acc_block_signal_op8695 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8713() {
    io_acc_block_signal_op8713 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8731() {
    io_acc_block_signal_op8731 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8749() {
    io_acc_block_signal_op8749 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8767() {
    io_acc_block_signal_op8767 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8785() {
    io_acc_block_signal_op8785 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8803() {
    io_acc_block_signal_op8803 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8821() {
    io_acc_block_signal_op8821 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op883() {
    io_acc_block_signal_op883 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8839() {
    io_acc_block_signal_op8839 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8857() {
    io_acc_block_signal_op8857 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8875() {
    io_acc_block_signal_op8875 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8893() {
    io_acc_block_signal_op8893 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8911() {
    io_acc_block_signal_op8911 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8929() {
    io_acc_block_signal_op8929 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8947() {
    io_acc_block_signal_op8947 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8965() {
    io_acc_block_signal_op8965 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op8983() {
    io_acc_block_signal_op8983 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9001() {
    io_acc_block_signal_op9001 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op901() {
    io_acc_block_signal_op901 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9019() {
    io_acc_block_signal_op9019 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9037() {
    io_acc_block_signal_op9037 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9055() {
    io_acc_block_signal_op9055 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9073() {
    io_acc_block_signal_op9073 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9091() {
    io_acc_block_signal_op9091 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9109() {
    io_acc_block_signal_op9109 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9127() {
    io_acc_block_signal_op9127 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9145() {
    io_acc_block_signal_op9145 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9163() {
    io_acc_block_signal_op9163 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9181() {
    io_acc_block_signal_op9181 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op919() {
    io_acc_block_signal_op919 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9199() {
    io_acc_block_signal_op9199 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9217() {
    io_acc_block_signal_op9217 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9235() {
    io_acc_block_signal_op9235 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9253() {
    io_acc_block_signal_op9253 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9271() {
    io_acc_block_signal_op9271 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9289() {
    io_acc_block_signal_op9289 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9307() {
    io_acc_block_signal_op9307 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9325() {
    io_acc_block_signal_op9325 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9343() {
    io_acc_block_signal_op9343 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9361() {
    io_acc_block_signal_op9361 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op937() {
    io_acc_block_signal_op937 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9379() {
    io_acc_block_signal_op9379 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9397() {
    io_acc_block_signal_op9397 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9415() {
    io_acc_block_signal_op9415 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9433() {
    io_acc_block_signal_op9433 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9451() {
    io_acc_block_signal_op9451 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9469() {
    io_acc_block_signal_op9469 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9487() {
    io_acc_block_signal_op9487 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9505() {
    io_acc_block_signal_op9505 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9523() {
    io_acc_block_signal_op9523 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9541() {
    io_acc_block_signal_op9541 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op955() {
    io_acc_block_signal_op955 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9559() {
    io_acc_block_signal_op9559 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9577() {
    io_acc_block_signal_op9577 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9595() {
    io_acc_block_signal_op9595 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9613() {
    io_acc_block_signal_op9613 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9631() {
    io_acc_block_signal_op9631 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9649() {
    io_acc_block_signal_op9649 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9667() {
    io_acc_block_signal_op9667 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9685() {
    io_acc_block_signal_op9685 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9703() {
    io_acc_block_signal_op9703 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9721() {
    io_acc_block_signal_op9721 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op973() {
    io_acc_block_signal_op973 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9739() {
    io_acc_block_signal_op9739 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9757() {
    io_acc_block_signal_op9757 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9775() {
    io_acc_block_signal_op9775 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9793() {
    io_acc_block_signal_op9793 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9811() {
    io_acc_block_signal_op9811 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9829() {
    io_acc_block_signal_op9829 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9847() {
    io_acc_block_signal_op9847 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9865() {
    io_acc_block_signal_op9865 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9883() {
    io_acc_block_signal_op9883 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9901() {
    io_acc_block_signal_op9901 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op991() {
    io_acc_block_signal_op991 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9919() {
    io_acc_block_signal_op9919 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9937() {
    io_acc_block_signal_op9937 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9955() {
    io_acc_block_signal_op9955 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9973() {
    io_acc_block_signal_op9973 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_io_acc_block_signal_op9991() {
    io_acc_block_signal_op9991 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_1_fu_673_p0() {
    mul_ln1148_1_fu_673_p0 =  (sc_lv<16>) (mul_ln1148_1_fu_673_p00.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_1_fu_673_p00() {
    mul_ln1148_1_fu_673_p00 = esl_zext<34,16>(grp_compute_global_pool_array_array_ap_fixed_16_6_5_3_0_8u_config6_s_fu_314_ap_return_1.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_1_fu_673_p1() {
    mul_ln1148_1_fu_673_p1 =  (sc_lv<18>) (ap_const_lv34_1C71D);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_2_fu_680_p0() {
    mul_ln1148_2_fu_680_p0 =  (sc_lv<16>) (mul_ln1148_2_fu_680_p00.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_2_fu_680_p00() {
    mul_ln1148_2_fu_680_p00 = esl_zext<34,16>(grp_compute_global_pool_array_array_ap_fixed_16_6_5_3_0_8u_config6_s_fu_314_ap_return_2.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_2_fu_680_p1() {
    mul_ln1148_2_fu_680_p1 =  (sc_lv<18>) (ap_const_lv34_1C71D);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_3_fu_687_p0() {
    mul_ln1148_3_fu_687_p0 =  (sc_lv<16>) (mul_ln1148_3_fu_687_p00.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_3_fu_687_p00() {
    mul_ln1148_3_fu_687_p00 = esl_zext<34,16>(grp_compute_global_pool_array_array_ap_fixed_16_6_5_3_0_8u_config6_s_fu_314_ap_return_3.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_3_fu_687_p1() {
    mul_ln1148_3_fu_687_p1 =  (sc_lv<18>) (ap_const_lv34_1C71D);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_4_fu_694_p0() {
    mul_ln1148_4_fu_694_p0 =  (sc_lv<16>) (mul_ln1148_4_fu_694_p00.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_4_fu_694_p00() {
    mul_ln1148_4_fu_694_p00 = esl_zext<34,16>(grp_compute_global_pool_array_array_ap_fixed_16_6_5_3_0_8u_config6_s_fu_314_ap_return_4.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_4_fu_694_p1() {
    mul_ln1148_4_fu_694_p1 =  (sc_lv<18>) (ap_const_lv34_1C71D);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_5_fu_701_p0() {
    mul_ln1148_5_fu_701_p0 =  (sc_lv<16>) (mul_ln1148_5_fu_701_p00.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_5_fu_701_p00() {
    mul_ln1148_5_fu_701_p00 = esl_zext<34,16>(grp_compute_global_pool_array_array_ap_fixed_16_6_5_3_0_8u_config6_s_fu_314_ap_return_5.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_5_fu_701_p1() {
    mul_ln1148_5_fu_701_p1 =  (sc_lv<18>) (ap_const_lv34_1C71D);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_6_fu_708_p0() {
    mul_ln1148_6_fu_708_p0 =  (sc_lv<16>) (mul_ln1148_6_fu_708_p00.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_6_fu_708_p00() {
    mul_ln1148_6_fu_708_p00 = esl_zext<34,16>(grp_compute_global_pool_array_array_ap_fixed_16_6_5_3_0_8u_config6_s_fu_314_ap_return_6.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_6_fu_708_p1() {
    mul_ln1148_6_fu_708_p1 =  (sc_lv<18>) (ap_const_lv34_1C71D);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_7_fu_715_p0() {
    mul_ln1148_7_fu_715_p0 =  (sc_lv<16>) (mul_ln1148_7_fu_715_p00.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_7_fu_715_p00() {
    mul_ln1148_7_fu_715_p00 = esl_zext<34,16>(grp_compute_global_pool_array_array_ap_fixed_16_6_5_3_0_8u_config6_s_fu_314_ap_return_7.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_7_fu_715_p1() {
    mul_ln1148_7_fu_715_p1 =  (sc_lv<18>) (ap_const_lv34_1C71D);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_fu_666_p0() {
    mul_ln1148_fu_666_p0 =  (sc_lv<16>) (mul_ln1148_fu_666_p00.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_fu_666_p00() {
    mul_ln1148_fu_666_p00 = esl_zext<34,16>(grp_compute_global_pool_array_array_ap_fixed_16_6_5_3_0_8u_config6_s_fu_314_ap_return_0.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_mul_ln1148_fu_666_p1() {
    mul_ln1148_fu_666_p1 =  (sc_lv<18>) (ap_const_lv34_1C71D);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_real_start() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, start_full_n.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, start_once_reg.read()))) {
        real_start = ap_const_logic_0;
    } else {
        real_start = ap_start.read();
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_0_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read())) {
        res_V_data_0_V_blk_n = res_V_data_0_V_full_n.read();
    } else {
        res_V_data_0_V_blk_n = ap_const_logic_1;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_0_V_din() {
    res_V_data_0_V_din = esl_sext<16,8>(tmp_46_fu_526_p4.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_0_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10943.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10996.read())))) {
        res_V_data_0_V_write = ap_const_logic_1;
    } else {
        res_V_data_0_V_write = ap_const_logic_0;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_1_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read())) {
        res_V_data_1_V_blk_n = res_V_data_1_V_full_n.read();
    } else {
        res_V_data_1_V_blk_n = ap_const_logic_1;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_1_V_din() {
    res_V_data_1_V_din = esl_sext<16,8>(tmp_47_fu_544_p4.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_1_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10943.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10996.read())))) {
        res_V_data_1_V_write = ap_const_logic_1;
    } else {
        res_V_data_1_V_write = ap_const_logic_0;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_2_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read())) {
        res_V_data_2_V_blk_n = res_V_data_2_V_full_n.read();
    } else {
        res_V_data_2_V_blk_n = ap_const_logic_1;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_2_V_din() {
    res_V_data_2_V_din = esl_sext<16,8>(tmp_48_fu_562_p4.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_2_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10943.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10996.read())))) {
        res_V_data_2_V_write = ap_const_logic_1;
    } else {
        res_V_data_2_V_write = ap_const_logic_0;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_3_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read())) {
        res_V_data_3_V_blk_n = res_V_data_3_V_full_n.read();
    } else {
        res_V_data_3_V_blk_n = ap_const_logic_1;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_3_V_din() {
    res_V_data_3_V_din = esl_sext<16,8>(tmp_49_fu_580_p4.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_3_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10943.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10996.read())))) {
        res_V_data_3_V_write = ap_const_logic_1;
    } else {
        res_V_data_3_V_write = ap_const_logic_0;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_4_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read())) {
        res_V_data_4_V_blk_n = res_V_data_4_V_full_n.read();
    } else {
        res_V_data_4_V_blk_n = ap_const_logic_1;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_4_V_din() {
    res_V_data_4_V_din = esl_sext<16,8>(tmp_50_fu_598_p4.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_4_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10943.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10996.read())))) {
        res_V_data_4_V_write = ap_const_logic_1;
    } else {
        res_V_data_4_V_write = ap_const_logic_0;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_5_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read())) {
        res_V_data_5_V_blk_n = res_V_data_5_V_full_n.read();
    } else {
        res_V_data_5_V_blk_n = ap_const_logic_1;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_5_V_din() {
    res_V_data_5_V_din = esl_sext<16,8>(tmp_51_fu_616_p4.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_5_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10943.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10996.read())))) {
        res_V_data_5_V_write = ap_const_logic_1;
    } else {
        res_V_data_5_V_write = ap_const_logic_0;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_6_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read())) {
        res_V_data_6_V_blk_n = res_V_data_6_V_full_n.read();
    } else {
        res_V_data_6_V_blk_n = ap_const_logic_1;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_6_V_din() {
    res_V_data_6_V_din = esl_sext<16,8>(tmp_52_fu_634_p4.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_6_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10943.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10996.read())))) {
        res_V_data_6_V_write = ap_const_logic_1;
    } else {
        res_V_data_6_V_write = ap_const_logic_0;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_7_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read())) {
        res_V_data_7_V_blk_n = res_V_data_7_V_full_n.read();
    } else {
        res_V_data_7_V_blk_n = ap_const_logic_1;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_7_V_din() {
    res_V_data_7_V_din = esl_sext<16,8>(tmp_53_fu_652_p4.read());
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_res_V_data_7_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state576.read()) && 
         !(esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10943.read()) || esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op10996.read())))) {
        res_V_data_7_V_write = ap_const_logic_1;
    } else {
        res_V_data_7_V_write = ap_const_logic_0;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_start_out() {
    start_out = real_start.read();
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_start_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, start_once_reg.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, real_start.read()))) {
        start_write = ap_const_logic_1;
    } else {
        start_write = ap_const_logic_0;
    }
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_tmp_46_fu_526_p4() {
    tmp_46_fu_526_p4 = mul_ln1148_fu_666_p2.read().range(33, 26);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_tmp_47_fu_544_p4() {
    tmp_47_fu_544_p4 = mul_ln1148_1_fu_673_p2.read().range(33, 26);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_tmp_48_fu_562_p4() {
    tmp_48_fu_562_p4 = mul_ln1148_2_fu_680_p2.read().range(33, 26);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_tmp_49_fu_580_p4() {
    tmp_49_fu_580_p4 = mul_ln1148_3_fu_687_p2.read().range(33, 26);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_tmp_50_fu_598_p4() {
    tmp_50_fu_598_p4 = mul_ln1148_4_fu_694_p2.read().range(33, 26);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_tmp_51_fu_616_p4() {
    tmp_51_fu_616_p4 = mul_ln1148_5_fu_701_p2.read().range(33, 26);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_tmp_52_fu_634_p4() {
    tmp_52_fu_634_p4 = mul_ln1148_6_fu_708_p2.read().range(33, 26);
}

void global_pooling2d_cl_array_array_ap_fixed_16_6_5_3_0_8u_config6_s::thread_tmp_53_fu_652_p4() {
    tmp_53_fu_652_p4 = mul_ln1148_7_fu_715_p2.read().range(33, 26);
}

}

