//Numpy array shape [10]
//Min -0.183959960938
//Max 0.130371093750
//Number of zeros 0

#ifndef B15_H_
#define B15_H_

#ifndef __SYNTHESIS__
model_default_t b15[10];
#else
model_default_t b15[10] = {-0.1839599609, -0.0519409180, -0.1088867188, 0.1074218750, 0.1069335938, 0.0813598633, -0.0397949219, 0.0676269531, -0.1035156250, 0.1303710938};
#endif

#endif
