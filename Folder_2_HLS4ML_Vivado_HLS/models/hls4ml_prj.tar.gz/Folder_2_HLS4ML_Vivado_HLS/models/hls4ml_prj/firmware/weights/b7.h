//Numpy array shape [10]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 10

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
bias7_t b7[10];
#else
bias7_t b7[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#endif

#endif
