//Numpy array shape [10]
//Min -0.489990234375
//Max 0.247436523438
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
model_default_t b9[10];
#else
model_default_t b9[10] = {-0.3259277344, 0.2474365234, -0.0243225098, -0.2558593750, -0.4565429688, -0.2315673828, -0.0404052734, -0.4233398438, 0.0487976074, -0.4899902344};
#endif

#endif
