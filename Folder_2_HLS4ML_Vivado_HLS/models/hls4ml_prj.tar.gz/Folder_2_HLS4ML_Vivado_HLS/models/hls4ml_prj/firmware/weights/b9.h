//Numpy array shape [10]
//Min -1.604492187500
//Max 2.087890625000
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
model_default_t b9[10];
#else
model_default_t b9[10] = {0.1923828125, 0.7875976562, -0.0818481445, 2.0878906250, -1.2812500000, 0.5727539062, 0.4177246094, 0.6157226562, -1.6044921875, -0.8022460938};
#endif

#endif
