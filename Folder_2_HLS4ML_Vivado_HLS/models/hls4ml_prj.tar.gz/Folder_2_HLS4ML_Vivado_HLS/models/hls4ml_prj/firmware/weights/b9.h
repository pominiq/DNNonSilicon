//Numpy array shape [10]
//Min -0.524414062500
//Max 0.403320312500
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
model_default_t b9[10];
#else
model_default_t b9[10] = {-0.1904296875, 0.4033203125, -0.4404296875, -0.1444091797, -0.2788085938, 0.0420532227, 0.0363769531, -0.3691406250, 0.1083374023, -0.5244140625};
#endif

#endif
