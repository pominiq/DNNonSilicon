//Numpy array shape [4]
//Min -0.583984375000
//Max 0.620605468750
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {-0.5839843750, 0.6206054688, -0.0029010773, -0.0614013672};
#endif

#endif
