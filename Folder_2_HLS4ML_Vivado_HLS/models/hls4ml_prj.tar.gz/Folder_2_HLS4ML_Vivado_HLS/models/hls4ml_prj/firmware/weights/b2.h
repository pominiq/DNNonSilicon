//Numpy array shape [4]
//Min -0.847656250000
//Max 0.069885253906
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {0.0698852539, -0.8476562500, -0.0030899048, -0.0061149597};
#endif

#endif
