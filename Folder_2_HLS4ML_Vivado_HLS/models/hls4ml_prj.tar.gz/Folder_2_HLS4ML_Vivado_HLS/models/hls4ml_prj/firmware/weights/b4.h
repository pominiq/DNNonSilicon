//Numpy array shape [8]
//Min -0.536132812500
//Max 3.285156250000
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[8];
#else
model_default_t b4[8] = {-0.0805053711, 0.2895507812, -0.0044975281, 3.1582031250, 3.2851562500, -0.0580444336, -0.0018386841, -0.5361328125};
#endif

#endif
