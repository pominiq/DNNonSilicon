//Numpy array shape [3]
//Min -0.012802124023
//Max 0.017089843750
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[3];
#else
model_default_t b4[3] = {-0.0120315552, 0.0170898438, -0.0128021240};
#endif

#endif
