//Numpy array shape [3]
//Min -0.111755371094
//Max 0.137329101562
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
model_default_t b4[3];
#else
model_default_t b4[3] = {-0.0731201172, 0.1373291016, -0.1117553711};
#endif

#endif
