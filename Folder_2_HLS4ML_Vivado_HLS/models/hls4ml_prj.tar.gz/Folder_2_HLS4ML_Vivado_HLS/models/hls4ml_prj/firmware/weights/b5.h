//Numpy array shape [8]
//Min -0.705078125000
//Max 1.508789062500
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {-0.3471679688, -0.1158447266, -0.2465820312, 1.5087890625, -0.6352539062, -0.7050781250, 0.2462158203, 0.8750000000};
#endif

#endif
