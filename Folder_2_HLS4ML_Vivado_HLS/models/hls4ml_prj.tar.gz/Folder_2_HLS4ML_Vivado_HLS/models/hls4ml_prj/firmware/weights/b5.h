//Numpy array shape [8]
//Min -1.824218750000
//Max 2.111328125000
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {2.1113281250, -1.8242187500, 0.1150512695, 1.0781250000, -1.1943359375, 0.1849365234, 0.8227539062, 0.7666015625};
#endif

#endif
