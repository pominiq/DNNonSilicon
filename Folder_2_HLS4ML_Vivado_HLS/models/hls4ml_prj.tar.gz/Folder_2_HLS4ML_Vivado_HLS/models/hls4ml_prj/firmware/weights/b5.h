//Numpy array shape [8]
//Min -0.788085937500
//Max 0.902832031250
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {0.0866088867, 0.0892944336, 0.6889648438, -0.0512390137, -0.7880859375, 0.1058959961, 0.9028320312, 0.0710449219};
#endif

#endif
