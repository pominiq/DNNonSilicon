//Numpy array shape [4]
//Min -0.617675781250
//Max 0.002828598022
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {-0.6176757812, -0.3759765625, -0.0002515316, 0.0028285980};
#endif

#endif
