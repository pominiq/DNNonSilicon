//Numpy array shape [10]
//Min -0.327392578125
//Max -0.009872436523
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
dense_bias_t b9[10];
#else
dense_bias_t b9[10] = {-0.0620727539, -0.0791625977, -0.2004394531, -0.0174407959, -0.3273925781, -0.0098724365, -0.0669555664, -0.0724487305, -0.0128631592, -0.1575927734};
#endif

#endif
