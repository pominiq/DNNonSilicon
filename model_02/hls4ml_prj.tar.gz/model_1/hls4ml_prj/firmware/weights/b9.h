//Numpy array shape [10]
//Min -0.286865234375
//Max 0.459960937500
//Number of zeros 0

#ifndef B9_H_
#define B9_H_

#ifndef __SYNTHESIS__
dense_bias_t b9[10];
#else
dense_bias_t b9[10] = {0.1894531250, 0.4599609375, 0.0291595459, 0.0213775635, -0.0272521973, -0.1505126953, 0.1970214844, 0.0694580078, -0.2868652344, -0.2122802734};
#endif

#endif
